"""Exact, schematic system figures; no implied physical floorplans."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT=Path(__file__).resolve().parent/'figures';ROOT.mkdir(exist_ok=True)
NAVY='#162B3E';TEAL='#006C70';RUST='#C9553A';GRAY='#EDF3F5';INK='#22313E';BLUE='#DDEBF1'
from matplotlib import font_manager
for name in ['NotoSansSC-Regular.ttf','NotoSansSC-Bold.ttf']:
    font_manager.fontManager.addfont(str(Path(__file__).resolve().parent/name))
plt.rcParams.update({'font.family':'Noto Sans SC','font.size':12})
def base(title,sub):
    f,a=plt.subplots(figsize=(13.2,8.1));f.patch.set_facecolor('white')
    a.set(xlim=(0,13.2),ylim=(0,8.1));a.axis('off');f.subplots_adjust(0,0,1,1)
    a.text(.45,7.7,title,color=NAVY,size=22,weight='bold',va='top')
    a.text(.45,7.14,sub,color='#586B78',size=11,va='top')
    return f,a
def box(a,x,y,w,h,title,body='',color=TEAL,fill=GRAY,fs=12):
    a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=0.10',edgecolor=color,facecolor=fill,linewidth=1.5,zorder=3))
    a.text(x+w/2,y+h-.20,title,color=color,size=fs+1,weight='bold',ha='center',va='top',zorder=4)
    if body:a.text(x+w/2,y+h/2-.10,body,color=INK,size=fs,ha='center',va='center',linespacing=1.45,zorder=4)
def arrow(a,p,q,label='',color=TEAL,bidir=True,offset=(0,0)):
    a.add_patch(FancyArrowPatch(p,q,arrowstyle='<->' if bidir else '-|>',mutation_scale=13,color=color,linewidth=1.7,zorder=2))
    if label:a.text((p[0]+q[0])/2+offset[0],(p[1]+q[1])/2+offset[1],label,ha='center',va='center',size=10,color=INK,bbox=dict(facecolor='white',edgecolor='none',pad=2),zorder=5)
def finish(f,a,name,source):
    a.text(.45,.19,source,color='#586B78',size=9,va='bottom')
    f.savefig(ROOT/(name+'.png'),dpi=190,facecolor='white');f.savefig(ROOT/(name+'.svg'),facecolor='white');plt.close(f)

f,a=base('2017—2020  |  CPU 主机与独立 GPU 内存','代表性 EPYC＋Instinct 模式；可选 GPU 对等互连随代际变化')
box(a,.45,5.7,12.25,.8,'应用 · ROCm / HIP · CPU 软件库',color=NAVY,fill=BLUE)
box(a,.65,3.45,4.2,1.45,'EPYC 主机','Naples → Rome\n本地 DDR4；通用执行')
box(a,7.5,3.45,4.9,1.45,'Instinct 加速器','MI25 → MI100\nHBM 独立于主机 DDR',color=RUST)
arrow(a,(4.85,4.15),(7.5,4.15),'PCIe 3 → PCIe 4')
box(a,7.5,1.45,4.9,1.1,'MI100 对等域','四 GPU；每 GPU 三条 IF 对等链路',color=RUST)
arrow(a,(9.95,3.45),(9.95,2.55))
box(a,.65,1.45,4.2,1.1,'合作伙伴网络','集群、前端及存储流量',color=NAVY)
arrow(a,(2.75,3.45),(2.75,2.55),'主机 I/O',offset=(.6,0))
a.text(.7,.76,'系统边界：OEM 服务器／节点',size=12,color=NAVY,weight='bold')
finish(f,a,'era_1','来源：A2、A8、D1、D5、D6。拓扑为示意，不规定 GPU 或 NIC 必须采用的数量。')

f,a=base('2021—2022  |  Frontier 将多个封装组合成节点','一颗定制 EPYC＋四个 MI250X 模块＝八个逻辑 GPU 设备')
box(a,.45,5.85,12.25,.7,'应用 · ROCm · 感知拓扑的任务及数据放置',color=NAVY,fill=BLUE)
box(a,.6,3.6,2.7,1.4,'定制 EPYC','CPU 核心＋DDR4')
for j,(x,y) in enumerate([(4.2,4.15),(8.65,4.15),(4.2,2.15),(8.65,2.15)],1):
    box(a,x,y,3.9,1.2,f'MI250X 模块 {j}','两颗 GCD／逻辑 GPU\n每模块 128 GB HBM2e',color=RUST,fs=10.5)
arrow(a,(3.3,4.3),(4.2,4.3),'IF',offset=(0,.25))
arrow(a,(8.1,4.7),(8.65,4.7))
arrow(a,(8.1,2.7),(8.65,2.7))
arrow(a,(6.15,4.15),(6.15,3.35),'节点 IF')
arrow(a,(10.6,4.15),(10.6,3.35),'节点 IF')
box(a,.6,.65,11.95,.95,'合作伙伴横向扩展：HPE Slingshot','每节点 4 × 200 Gb/s 接口＝每方向合计 100 GB/s',color=NAVY,fs=11)
arrow(a,(6.15,2.15),(6.15,1.60))
arrow(a,(10.6,2.15),(10.6,1.60))
a.text(.66,2.75,'直接液冷\n节点链路为抽象示意；',color=INK,size=11,linespacing=1.6)
a.text(.66,2.03,'不是逐条链路的\n布线图。',color=INK,size=11,linespacing=1.6)
finish(f,a,'era_2','来源：D7、D8、F8。HBM 及网络总量按图示分别以物理模块或节点计。')

f,a=base('2023—2025  |  两种不同的集成选择','八 GPU 独立加速器基板与一致性 CPU–GPU APU，共享集成技术源流')
box(a,.45,5.9,12.25,.7,'应用 · ROCm / HIP · 软件库 · RCCL',color=NAVY,fill=BLUE)
box(a,.55,4.45,6.5,.85,'外部 EPYC 主机＋DDR5',color=TEAL)
box(a,.55,2.50,6.5,1.25,'八 GPU 通用基板','MI300X / MI325X / MI350X / MI355X\n每 GPU 独立 HBM；IF 直接全互连（七对等节点）',color=RUST,fs=11)
arrow(a,(3.8,4.45),(3.8,3.75),'PCIe 5',offset=(.7,0))
box(a,.55,.72,3.05,1.0,'后端网络','Pollara 400 或合作伙伴 NIC',color=NAVY,fs=10.5)
box(a,4,.72,3.05,1.0,'前端服务','可选 Pensando DPU',color=TEAL,fs=10.5)
arrow(a,(2.1,2.5),(2.1,1.72),'RDMA')
arrow(a,(5.5,2.5),(5.5,1.72),'服务路径')
box(a,8.05,2.5,4.6,2.8,'MI300A／El Capitan 方案','每封装：\n24 Zen 4 核心＋CDNA 3 GPU\n128 GB 一致性共享 HBM\n\n每节点四 APU',color=RUST,fs=11)
box(a,8.05,.72,4.6,1,'HPE Slingshot','每节点 4 × 200 Gb/s 接口',color=NAVY,fs=10.5)
arrow(a,(10.35,2.5),(10.35,1.72),'横向扩展')
a.plot([7.55,7.55],[.75,5.35],color='#B8C8D0',ls='--',lw=1)
finish(f,a,'era_3','来源：E1、E3、E7、E10、I1、I2、H6。机架容纳更多基板，不会自动扩大八 GPU 基板互连域。')

f,a=base('2026  |  Helios 区分三种通信角色','已公布参考：18 Venice CPU＋72 MI455X GPU；已披露发布/生产，客户部署进度各异')
box(a,.45,5.95,12.25,.65,'ROCm / RCCL · Fabric Manager / Fabric OS · 平台管理',color=NAVY,fill=BLUE)
box(a,.55,3.8,3.25,1.3,'前端／存储','Salina DPU\n服务、安全、保留状态',color=TEAL,fs=11)
box(a,4.65,3.8,7.9,1.3,'十八计算托盘：每托盘 1 Venice＋4 MI455X','每 GPU：432 GB HBM4 · 本地内存 23.3 TB/s\nCPU–GPU 链路：每方向 128 GB/s',color=RUST,fs=11)
arrow(a,(3.8,4.45),(4.65,4.45),'服务',offset=(0,.32))
box(a,.55,1.55,5.55,1.3,'纵向扩展：UALoE','七十二 GPU 域 · 十二交换机／六托盘\n每 GPU 每方向 1.8 TB/s',color=RUST,fs=11)
box(a,6.95,1.55,5.6,1.3,'横向扩展：Vulcano＋合作伙伴以太网','每 GPU 两颗或三颗 800G NIC\n每 GPU 每方向 200 或 300 GB/s',color=NAVY,fs=11)
arrow(a,(6.1,3.8),(3.3,2.85),'GPU 对等流量')
arrow(a,(10.3,3.8),(10.3,2.85),'系统间流量',offset=(1.1,0))
a.text(.65,.85,'机架层：液冷 · 供电 · 可维护性 · 符合 OCP 方向的设计',color=NAVY,size=12,weight='bold')
a.text(.65,.52,'交换芯片、光互连及制造包含合作伙伴组件。机架 HBM 是分布式内存，并非均匀本地存储。',color=INK,size=10.5)
finish(f,a,'era_4','来源：C8、E17、I4、I5、K2、K3、N14、N15。适用时，带宽由厂商双向合计值换算为单方向。')
print('Created',len(list(ROOT.glob('*.png'))),'figures')

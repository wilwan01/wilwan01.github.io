from pathlib import Path
import json, re

ROOT = Path(__file__).resolve().parent
prose_map, cell_map = {}, {}
for path in sorted((ROOT / 'translations').glob('*.tsv')):
    mapping = cell_map if path.name.startswith('cells') else prose_map
    for line in path.read_text().splitlines():
        if not line.strip():
            continue
        key, value = line.split('\t', 1)
        key = int(key)
        if key in mapping:
            raise ValueError(f'Duplicate translation {path.name}: {key}')
        mapping[key] = value

prose = json.loads((ROOT / 'prose.json').read_text())
cells = json.loads((ROOT / 'cells.json').read_text())
missing = [p for p in prose if p['id'] not in prose_map and not p['text'].startswith('- **')]
assert not missing, missing
line_map = {p['line']: prose_map.get(p['id'], p['text']) for p in prose}
cell_translations = {text: cell_map.get(i, text) for i, text in enumerate(cells)}
source = (ROOT / 'source' / 'AMD_AI_Infrastructure_2015-2026.md').read_text()
output = []
for index, line in enumerate(source.splitlines()):
    if index in line_map:
        output.append(line_map[index])
    elif line.startswith('|'):
        row = [c.strip() for c in line.strip('|').split('|')]
        output.append('| ' + ' | '.join(cell_translations.get(c, c) for c in row) + ' |')
    else:
        output.append(line)
target = '\n'.join(output) + '\n'
(ROOT.parent / 'AMD_AI_Infrastructure_2015-2026_ZH.md').write_text(target)
(ROOT / 'cell_translations.json').write_text(json.dumps(cell_translations, ensure_ascii=False, indent=2))

def structure(text):
    lines = text.splitlines()
    return {
        'chapters': sum(l.startswith('# ') for l in lines),
        'headings': sum(l.startswith('#') for l in lines),
        'table_rows': sum(l.startswith('|') for l in lines),
        'table_cells': sum(len(l.strip('|').split('|')) for l in lines if l.startswith('|')),
        'figures': sum(l.startswith('![') for l in lines),
        'references': sum(bool(re.match(r'- \*\*[A-Z]\d+\.', l)) for l in lines),
        'web_links': re.findall(r'\]\((https?://[^\s]+)\)', text),
    }
assert structure(source) == structure(target), 'Structural or link mismatch'
report = structure(target)
report['web_links'] = len(report['web_links'])
report['chinese_characters'] = len(re.findall('[\u4e00-\u9fff]', target))
report['translated_prose_blocks'] = len(prose_map)
report['translated_unique_cells'] = len(cell_map)
(ROOT / 'translation_validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(report)

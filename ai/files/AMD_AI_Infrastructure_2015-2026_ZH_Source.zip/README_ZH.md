# AMD AI 基础设施十年架构演进 中文版源文件包

本包对应 68 页中文版报告，研究截止日期为 2026 年 9 月 27 日。内容按英文修订版完整翻译；产品名、技术缩写、会议论文题名及参考文献书目信息保留原文，方便检索。

## 内容

- 根目录 Markdown：可编辑的完整中文报告。
- `amd_cn/figures/`：四个时期的中文系统图，含 PNG 和 SVG。
- `amd_cn/translations/`：正文及表格单元格的中英对应翻译。
- `amd_cn/source/`、`prose.json`、`cells.json`：生成流程所需的英文原稿及结构化输入。
- `amd_cn/build_text.py`、`figures.py`、`build_pdf.py`：Markdown、图示及 PDF 的生成脚本。
- `amd_framework/data/`：原研究的 CSV/JSON、来源台账、参考文献及来源访问记录，保留英文数据字段和原有来源编号。
- `amd_cn/translation_validation.json`：章节、表格、图示和链接的结构核对结果。
- `amd_cn/qa_final/validation.json`：最终 PDF 页面与文本边界检查记录。

PDF 另行提供下载。请完整解压本包，保持目录结构，Markdown 中的相对图片路径才能正常工作。

## 重新生成

需要 Python 3、Matplotlib、ReportLab 和 Pillow。在解压后的根目录依次执行：

```bash
python3 amd_cn/build_text.py
python3 amd_cn/figures.py
python3 amd_cn/build_pdf.py
```

随包包含供排版使用的 Noto Sans SC Regular/Bold 字体实例，源字体来自 Google Fonts，授权全文见 `amd_cn/OFL.txt`。

原始研究的来源访问记录与布局 QA 是交付时快照，不由上述三个命令重新执行。n/d 表示在原研究审阅资料中未确认，n/a 表示不适用。算力及链路方向的统一口径见正文。

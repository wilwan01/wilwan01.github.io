from pathlib import Path
import re,json,sys
import reference_tables
from data import TABLES,META,LEDGER,ROOT,write_data

OUT=ROOT.parent/'AMD_AI_Infrastructure_2015-2026.md'
original=(ROOT/'source'/OUT.name).read_text()
parts=re.split(r'(?=^## \d+\.\d+ )',original,flags=re.M)
sections={re.match(r'## (\d+\.\d+)',x).group(1):x.split('\n# ')[0].strip() for x in parts if re.match(r'## \d+\.\d+',x)}

def sec(old,new=None):
    s=sections[old]
    if new:s=re.sub(r'^## '+re.escape(old)+r' ', '## '+new+' ',s)
    return s
def mdtable(name):
    t=TABLES[name]
    return '\n'.join(['| '+' | '.join(t['headers'])+' |','|'+'|'.join(['---']*len(t['headers']))+'|']+['| '+' | '.join(str(x).replace('|','/') for x in r)+' |' for r in t['rows']])
def subset_table(name,idx):
    t=TABLES[name]
    rows=[[r[i] for i in idx] for r in [t['headers']]+t['rows']]
    return '\n'.join(['| '+' | '.join(rows[0])+' |','|'+'|'.join(['---']*len(idx))+'|']+['| '+' | '.join(r)+' |' for r in rows[1:]])
def sources(keys):return '\n\n*Source map: '+keys+'. Full references appear in the bibliography; numerical cells are indexed in the companion claims ledger.*\n'

intro="""# AMD AI Infrastructure: A Decade of Architectural Evolution

EPYC, Instinct, interconnect, Pensando, adaptive computing, systems and software

Research cutoff: **27 September 2026**. Conference record through Hot Chips 2026, ISSCC 2026 and Advancing AI 2026; ROCm announcement coverage through August 2026. ISSCC 2027 has not yet occurred.

**Families and weights:** deep coverage of EPYC and Instinct; full generation-level coverage of scale-up links, Pensando DPUs and AI NICs; proportional coverage of adaptive products, systems, software and client derivatives.
**Start year:** 2015, with earlier silicon only where it explains the first covered generation.
**Cutoff:** 27 September 2026; product status and roadmap dates are frozen to this date.
**Audience and focus:** experienced CPU and datacenter architects; architectural changes, physical implementation and their system consequences.
**Boundaries:** include acquired ancestry; AMD has no separately established merchant datacenter switch-ASIC or optical-transceiver line in this reviewed portfolio, so partner switches and optics appear at the system layer. This is a product-focused disclosure survey, not a census of every AMD-affiliated paper or SKU.

# Executive synthesis

AMD's server history is a sequence of changes to the boundary of a processor. Naples assembled four complete CPU SoCs. Rome moved memory and I/O into a central die and replicated smaller compute chiplets. Milan enlarged the cache-sharing domain; V-Cache added capacity vertically. Genoa and Turin then offered different combinations of core density, cache and memory bandwidth around related platforms. Venice extends the platform toward sixteen memory channels and a much larger accelerator-host role.

Instinct followed a parallel but distinct path: graphics-derived compute, a dedicated CDNA matrix architecture, two GPU dies, stacked compute chiplets, and finally a switched rack-scale accelerator domain. The relevant unit of comparison changed along the way. MI250X is one package containing two logical GPU devices. MI300X can expose eight XCDs as one GPU. Helios connects seventy-two GPUs, but its quoted rack HBM remains distributed memory rather than one uniformly local store.

Pensando fills two different requirements. DPUs place networking, security and storage services outside tenant CPU execution. AI NICs move accelerator traffic across a scale-out network. Pollara and Vulcano complement the GPU scale-up fabric; Salina addresses infrastructure services, including access to retained inference state. Xilinx adds programmable spatial processing and networking, while system design and ROCm turn component capabilities into deployable platforms.

The headline figures show that more arithmetic does not automatically create a balanced machine:

| Era / flagship pairing | CPU maximum cores; DRAM GB/s/socket | GPU dense BF16 / FP8 TFLOP/s | GPU memory capacity; TB/s | Scale-up domain |
|---|---|---|---|---|
| 2017: Naples / MI25 | 32; 170.7 | n/a / n/a | 16 GB HBM2; 0.484 | PCIe system-dependent |
| 2019–2020: Rome / MI100 | 64; 204.8 | 92.3 / n/a | 32 GB HBM2; 1.229 | 4-GPU IF hive |
| 2021–2022: Milan / MI250X | 64; 204.8 | 383 / n/a per package | 128 GB HBM2e; 3.2 | Frontier: 4 packages, 8 GPU devices |
| 2023: Genoa / MI300X | 96; 460.8 | 1307.4 / 2614.9 | 192 GB HBM3; 5.3 | 8 GPUs |
| 2024: Turin / MI325X | 128 or 192; 614.4 current | 1307.4 / 2614.9 | 256 GB HBM3e; 6.0 | 8 GPUs |
| 2025: Turin / MI355X | 128 or 192; 614.4 current | 2517 / 5033 | 288 GB HBM3e; 8.0 | 8 GPUs per baseboard |
| 2026: Venice / MI455X | 256; 1024 RDIMM / 1638.4 MRDIMM | 5033 / 20133 | 432 GB HBM4; 23.3 | 72 GPUs in Helios |

These are era pairings and representative maxima, not mandatory node bills of materials. MI455X and Venice have launch and production disclosures; broad general availability is not established by those disclosures alone. The 2026 rows describe the published platform while customer rollout proceeds. Older rows describe historically available products, without asserting that every legacy card remains orderable.

Three resource balances are particularly revealing. At current DDR5-6400 specifications, Turin offers 4.8 GB/s per core at 128 cores and 3.2 GB/s per core at 192 cores. MI355X offers roughly 0.00318 HBM bytes per dense BF16 FLOP, compared with 0.00405 for MI300X. MI455X reverses that BF16 trend to about 0.00463, but its much larger FP8 rate gives only about 0.00116 HBM bytes per FP8 FLOP. Reuse, layout and precision selection therefore remain central even after a large HBM upgrade.

The other decisive change is specialization. MI455X's published FP64 peak is 5 TFLOP/s, compared with 78.6 TFLOP/s for MI355X; the separate MI430X branch is announced for HPC in 2027. Meanwhile MI350P places CDNA 4 in a conventional PCIe card, and the dense EPYC branches choose different cache and memory resources per core. A useful comparison must follow the workload and deployment branch, not only the generation number.

The engineering direction is clear: reusable compute dies, increasingly specialized infrastructure dies, deeper integration near memory, and a wider system boundary. The costs are equally concrete: additional locality boundaries, more complex partitioning, greater package and thermal demands, and a stronger dependency on communication software. The 2027–2030 roadmap extends this direction, but its names and intended dates should not be mistaken for completed implementations.

## How to read the comparisons

All compute rates are vendor peak **dense** rates unless marked otherwise. A multiply-add follows the vendor's two-operation convention. Per-package, per-card and per-rack quantities are identified. FP8 and microscaling formats are named; sparse figures are not substituted for dense figures. These rates are not application benchmarks.

Link figures use decimal GB/s and state direction. Gb/s is divided by eight; a quoted bidirectional total is divided by two before comparison with a per-direction figure. HBM bandwidth is compared with one direction of the link. PCIe encoding ceilings exclude transaction overhead, while Ethernet line rates exclude protocol overhead. TDP, cTDP, TBP and the newer default CPU-power terminology retain their vendor definitions.

“n/d” means not established in the reviewed primary disclosure, rather than proof that no document exists; “n/a” means not applicable. The fixed schemas are preserved in the wide comparison tables and companion CSVs. Their rows distinguish shipping, limited availability, announced, roadmap and repositioned products. A separate chronology records first material disclosure and commercial availability. Material document conflicts are called out once, beside the affected product.
"""

cpu='\n\n'.join(sec(f'1.{i}') for i in range(1,12))
cpu=cpu.replace('now at rates up to DDR5-6000.', 'listed at DDR5-6000 in the April 2025 architecture guide and now at DDR5-6400 on the current 9755 and 9965 product pages. The current comparison therefore uses 614.4 GB/s per socket; the older 576 GB/s figure describes the earlier published configuration.')
cpu=cpu.replace('576 GB/s of nominal DDR5 bandwidth divided among 192 cores is 3.0 GB/s per core. The same memory interface divided among 128 cores is 4.5 GB/s per core.', '614.4 GB/s of nominal DDR5 bandwidth divided among 192 cores is 3.2 GB/s per core. The same memory interface divided among 128 cores is 4.8 GB/s per core.')
cpu=cpu.replace('| Turin, Zen 5 | 12 × DDR5-6000 | 576.0 | 128 | 4.50 |','| Turin, Zen 5 | 12 × DDR5-6400, current | 614.4 | 128 | 4.80 |')
cpu=cpu.replace('| Turin, Zen 5c | 12 × DDR5-6000 | 576.0 | 192 | 3.00 |','| Turin, Zen 5c | 12 × DDR5-6400, current | 614.4 | 192 | 3.20 |')
cpu=cpu.replace('The family uses Zen 6 and Zen 6c and expands into SP7 and SP8 platforms.', 'The family uses Zen 6 and Zen 6c and expands into SP7 and SP8 platforms. Production ramp and partner validation are documented, but a portfolio-wide GA date is not; this report classifies the new generation as limited availability at the cutoff.')
cpu=cpu.replace('Its deployment focus includes telecommunications, edge services and storage.', 'The 84-core 8635P has 384 MB L3, arranged as twelve CCDs with seven enabled cores and 32 MB L3 per CCD; the guide specifies 1 MB L2 per core and up to 48 lanes of CXL 2.0. Its deployment focus includes telecommunications, edge services and storage.')
cpu += """

## 1.12 Core implementation: feeding wider execution

The change from Zen to Zen 5 is more than an ISA progression. Zen established SMT, an op cache, out-of-order execution and a private-cache hierarchy that could be replicated in a CCX. Zen 2 widened floating-point execution to 256 bits. Zen 3 enlarged the execution window and load/store capacity while joining eight cores behind one L3. Zen 4 added a larger private L2 and AVX-512 instructions without making the entire floating-point path 512 bits wide.

Zen 5 makes the front-end and data-path expansion explicit. Its two fetch/decode paths feed eight-wide dispatch, while a larger reorder window lets the core find more independent work. The Hot Chips slides disclose a 448-entry retire/ROB capacity in single-thread mode and 224 entries per thread in two-thread mode. Six ALUs and four AGUs provide more execution opportunity, but sustained utilization still requires predictable branches, independent operations and data delivery.

The server implementation's 48 KB L1 data cache retains a four-cycle load-to-use target. The core can handle four memory addresses per cycle, with a maximum of two 512-bit loads or one 512-bit store through the vector-width paths. The published two-load/one-store capacities should not be read as all independent maxima occurring simultaneously without resource constraints. Wider L2-to-core paths and a new two-dimensional stride prefetcher address the feeding problem. L3 retains a victim relationship to L2, with duplicated L2 tags used for probe filtering.

"""+mdtable('Core_detail')+"""

Zen 4c and Zen 5c share an ISA foundation with their larger counterparts, but physical design and cache sharing change the system balance. Hot Chips reports about 35% less core-plus-L2 area for Zen 4c than Zen 4. That is a disclosed implementation comparison, not a universal area or performance multiplier. Dense products make sense when aggregate throughput and energy at the intended operating point outweigh lower per-core cache capacity or frequency.

## 1.13 Fabric, memory configuration and the accelerator-host role

The I/O die makes the socket easier to scale, but it is also a shared traffic junction. A core miss crosses a CCD link before reaching a memory controller; a remote-socket access adds xGMI. NPS settings describe how memory-controller locality is exposed, while the CCX describes a cache-sharing domain. These are different partitions. Increasing the number of NUMA nodes can help locality-sensitive software and complicate placement at the same time.

SP5 systems can allocate high-speed links between PCIe and socket connectivity. The common single-socket maximum is 128 PCIe lanes; a two-socket configuration does not simply double that number because socket links consume resources. The Turin guide gives a 160-lane system configuration with three xGMI links. CXL-capable lanes are a subset of the I/O budget, not extra lanes added to the headline total. A CXL memory device also has a different latency and bandwidth path from local DDR.

An AI host therefore needs to be selected using the actual board topology: which CPU owns each GPU or NIC, how PCIe switches are arranged, whether peer DMA is supported on that route, and how host memory is populated. A processor with more cores can be a worse fit for a GPU host if it leaves insufficient I/O or memory bandwidth for the required traffic. Conversely, CPU inference and preprocessing may benefit from AVX-512, BF16/VNNI, cache capacity and frequency even when no discrete GPU is present.

Security and RAS evolve alongside performance. Naples introduced the EPYC SEV lineage; later implementations added protection of guest execution state, and Milan introduced SEV-SNP's stronger integrity model. The current Infinity Guard and SEV documentation must be read with platform firmware and hypervisor requirements. Memory ECC, error containment and server validation belong to the usable system, not merely the core microarchitecture.

CPU power ratings do not specify one sustained frequency for every workload. Core population, instruction mix, memory traffic, thermal conditions and configured power limits determine the operating point. High-frequency, cache-rich, dense-core and low-power SKUs deliberately sit at different points on that curve. The family tables report maxima; selecting a concrete system requires its exact OPN and memory configuration.

## 1.14 Implementation limits in the public record

The Sorano architecture guide contains conflicting 4 nm and 5 nm statements and inconsistent memory-capacity wording relative to the data sheet. Its topology and cache capacity are independently corroborated by the product specifications; its process node is left unresolved here. The guide's single-socket product context also takes precedence over generic socket-link language copied into the document.

For Venice, the reviewed record establishes the N2 compute direction, EFB packaging and published socket resources. It does not yet support a full Zen 6 pipeline, private-cache, coherence-directory or die-to-die energy reconstruction. This is a specific disclosure gap, not a reason to infer those structures from Zen 5 or from the 1,024 MB package-cache total.
"""+sources('A1–A10; B1–B15; C1–C12; G1, G4, G13, G18; N1–N4, N20, N22, N23, N30–N33, N39, N45–N48, N50')

gpu='\n\n'.join(sec(f'2.{i}') for i in range(1,11))
gpu=gpu.replace('They are not included as completed product generations in the comparisons here.', 'They appear as announced or roadmap rows in the comparisons, with undisclosed fields left empty of inferred specifications.')
gpu=gpu.replace("AMD's July 2026 Advancing AI event introduced MI400 and Helios as launched products.", "AMD's July 2026 Advancing AI event launched MI400 and Helios and described production activity. Partner validation and scheduled customer deployments show that launch, production and broad availability are distinct milestones; the new platform is classified as limited availability here.")
gpu=gpu.replace('It addresses installations that need an accelerator within conventional server infrastructure rather than the highest-power multi-GPU module platform.', 'It addresses conventional PCIe servers with up to 600 W board power and a configurable 450 W point. AMD published a detailed deployment discussion on 7 May 2026, before featuring the product again at Advancing AI in July. A dedicated peer-fabric configuration is not specified for the card in the reviewed brief, so an eight-card PCIe server should not be assumed to have the UBB\'s all-to-all Infinity Fabric.')
gpu += """

## 2.11 Matrix engines, local storage and numerical formats

MI100's matrix engine is the first useful baseline for the dedicated compute line, but its BF16 and FP16 rates differ: the published BF16 peak is 92.3 TFLOP/s, while FP16 reaches 184.6 TFLOP/s. Treating these as interchangeable would distort the transition to MI250X's 383 TFLOP/s BF16. CDNA 2 also adds matrix FP64, making the distinction between vector and matrix double precision essential.

CDNA 3 adds FP8 formats and stronger matrix throughput, while retaining a Wave64 execution model. Its 4 MB L2 per XCD and package-level Infinity Cache sit between CU-local storage and HBM. The partition is deliberately hierarchical: a large package cache total does not imply that all operand traffic sees the same path or latency.

CDNA 4 enlarges LDS from 64 KB to 160 KB per CU and supports direct loading into LDS, reducing the need to stage data through vector registers. This helps kernels retain tiles and overlap movement with computation. It adds OCP microscaling formats, including MXFP8, MXFP6 and MXFP4, whose block scales and representation affect numerical behavior as well as storage. Native TF32 hardware support is replaced by a software path based on BF16 operations; software compatibility therefore does not imply identical execution hardware.

"""+mdtable('GPU_local_memory')+"""

MI350X and MI355X deliberately use different frequency/power points. The latter's dense BF16 peak rises to 2,517 TFLOP/s from 2,307, while rated TBP rises from 1,000 W to 1,400 W. The higher-power device does not increase HBM capacity or bandwidth. This is a throughput-density choice that must be assessed with rack limits and measured workload efficiency, not only peak arithmetic.

CDNA 5 changes the execution unit to a Wave32 WGP organization. Tensor Data Mover transfers can feed LDS asynchronously, L2 multicast can reuse a transfer across cooperating work, and named barriers support finer coordination. These mechanisms address data movement and synchronization around matrix computation. A count of 256 WGPs cannot be equated to the 256 CUs of CDNA 4.

The precision trade becomes unusually explicit in MI455X. Its dense BF16 peak is 5,033 TFLOP/s, OCP FP8/MXFP8 reaches 20,133, MXFP6 is 20,133, and MXFP4 is 40,265. Published vector and matrix FP64 are each 5 TFLOP/s. This is an AI-oriented balance, with the announced MI430X HPC branch targeting up to 288 TFLOP/s hardware FP64 in 2027. No unpublished MI430X memory or packaging specifications are inferred from MI455X.

## 2.12 Physical partitions, logical devices and isolation

MI250X's two logical GPUs each own their local HBM and L2. The package totals of 128 GB and about 3.2 TB/s require work and traffic to be considered across both GCDs. The bridge and internal fabric create a fast connection; they do not erase locality. In Frontier, node-level CPU and network connections further constrain how traffic can be scheduled.

MI300X and MI350 can expose a larger logical GPU across multiple compute chiplets or divide resources using supported compute and memory partition modes. MI350's two I/O dies support NPS1 and NPS2 memory organizations. In the documented NPS2/DPX arrangement, a logical partition groups four XCDs with 144 GB of HBM. SPX, DPX, QPX and CPX describe compute partition choices; they are not interchangeable names for memory partitioning.

A resource partition is also not automatically a security guarantee. Runtime support, virtualization mode, address translation, firmware and the particular product determine isolation behavior. Capacity planning should use the usable partition and supported software configuration rather than the whole-package number. The companion software chronology separates hardware introduction from release-specific enablement.

The packaging progression serves different needs at each step. MI250X uses EFB to join two large compute dies. MI300 stacks compute over four active I/O dies, enabling both a CPU–GPU APU and a GPU-only product. MI350 reduces that infrastructure to two I/O dies while increasing matrix resources and HBM performance. MI455X separates fabric/cache and external-I/O functions. These are changes in the partition of the machine, not simply successive shrinks of one block diagram.

## 2.13 Regional products and the forward roadmap

AMD's Q2 2026 filing identifies MI308 as a license-dependent regional product and reports resumed licensed shipments at the end of fiscal 2025. It also discusses MI325 licenses for some customers. The reviewed filing does not provide a technical MI308 specification table, so this report records the branch and its availability constraint without inventing compute, memory or interconnect limits. Export-control conditions explain why the branch exists; they do not establish a particular architectural cap absent a primary specification.

The July 2026 roadmap names MI500/Helios 500 for 2027 and MI600/Helios 600 for 2028. The corresponding host and networking codenames are recorded in the crosswalk. Those entries carry their disclosure date and remain roadmap items. Full-stack diagrams for 2026 use the published MI455X configuration; they do not silently incorporate features promised for the following generations.

Remaining material gaps include the final MI455X board-power envelope, detailed per-die node assignment, some HBM stack heights, and per-physical-link UALoE bandwidth. Package-level rates are published, but dividing them into a presumed lane topology would create unsupported precision. ISSCC 2026 provides a MI350 implementation record; a comparable MI400 ISSCC implementation paper is not established in this review.
"""+sources('D1–D10; E1–E20; F2, F8, F9; K3; N5–N16, N24–N29, N35–N37, N40, N41')

interconnect="""# 3. Scale-up interconnect and memory semantics

## 3.1 One brand, several physical and logical interfaces

Infinity Fabric names a family of connections, not one fixed wire speed or coherence contract. CPU CCD-to-IOD links, CPU socket-to-socket xGMI, GPU die-to-die links, GPU peer links and coherent CPU–GPU connections must be compared at their own endpoints. A rate measured across one of these boundaries is not a substitute for another.

Naples used the fabric to join complete SoCs inside a socket and to connect two sockets. Rome changed the on-package topology by introducing a central I/O die. Genoa and Turin increase external signaling and retain configurable socket/I/O allocations. Their NUMA behavior follows where memory controllers and cache domains sit, even when software sees one socket.

In Instinct, Vega 20 introduced direct peer connectivity and MI100 supported a four-GPU hive. MI200 added package-interior connectivity between two GCDs and node-level configurations with CPU and GPU links. MI300X and MI350 use a direct eight-GPU all-to-all baseboard: each GPU has seven peer connections. This provides one-hop peer paths within the baseboard but does not create an arbitrary-size domain by adding more identical boards.

## 3.2 Normalize the link before reasoning about the system

MI300X's seven peer links each provide 64 GB/s in one direction, giving 448 GB/s per GPU per direction. The familiar 896 GB/s number adds transmit and receive. MI350 increases each peer link to 76.8 GB/s, giving 537.6 GB/s in one direction or 1,075.2 GB/s bidirectionally. Both remain eight-GPU baseboard domains.

MI250X requires a different accounting boundary. Its internal GCD connection is quoted at 400 GB/s bidirectionally, or 200 GB/s in each direction between the two compute dies. Its external IF links are separate connections, each 50 GB/s per direction. Summing those ports describes interface capacity, not all-to-all bisection or bandwidth available to one collective. CPU attachment and node routing also consume or constrain connections.

For CPU xGMI, multiplying lane count by signaling rate yields an electrical ceiling. A sixteen-lane link at 32 Gb/s per lane gives 64 GB/s per direction before protocol effects. The table labels this as raw arithmetic rather than a sustained cache-coherent payload result. Likewise, a PCIe 5 x16 encoding ceiling near 63 GB/s is not a measured DMA throughput guarantee.

## 3.3 Helios: a switched seventy-two-GPU domain

Helios moves scale-up outside the eight-GPU direct mesh. AMD describes UALink over Ethernet, or UALoE, using a single-hop, multiplane fabric with twelve switches in six trays. The seventy-two GPUs are distributed across eighteen four-GPU compute trays with eighteen Venice CPUs. The published 3.6 TB/s per-GPU scale-up number is bidirectional: the normalized value is 1.8 TB/s per direction.

The switch makes the domain larger without requiring one dedicated direct cable to every peer. Its cost is a switching, buffering, congestion and operational layer. Reach, physical cabling and failure domains become rack-design questions. The reviewed final blueprint does not establish every switch radix, per-lane electrical rate or reduction-offload feature, so this report does not fill those fields from a generic UALink standard or another vendor's switch.

GPU memory semantics do not imply that all rack memory has local-HBM latency or full CPU cache coherence. Remote accesses still traverse endpoint and network resources. RCCL and application partitioning must organize collective and point-to-point traffic around those constraints. Fabric Manager, Fabric OS and vPods add provisioning and operational boundaries above the physical fabric.

## 3.4 Open standards and the remaining integration work

UALink addresses scale-up accelerator communication; UEC addresses Ethernet-based scale-out; CXL addresses coherent host/device and memory attachment; OCP addresses system interfaces and designs. They operate at different layers. AMD's participation and adoption do not make their names interchangeable, nor does an “UEC-ready” NIC statement prove certification of every protocol feature.

Helios uses partner switching and physical-network components. No standalone AMD merchant datacenter switch ASIC, optical-module family or CPO product is established in the reviewed portfolio. Switches and optics are therefore explicit ecosystem components in the stack figures. This still leaves AMD responsible for a much larger integration surface than the GPU package alone.
"""+sources('A2, A4, A9, B11, C3, D3, D5, D7, D8, E1, E3, E10, E15–E18, K2–K4; N14, N15, N24–N27')

network='\n\n'.join([sec(f'3.{i}',f'4.{i}') for i in range(1,7)]+[sec(f'4.{i}',f'4.{i+5}') for i in range(2,6)])
network=network.replace('Up to 2 × 400 Gb/s; PCIe 5.0 ×16', '2 × 400 Gb/s port capability; card service rating 400G; PCIe 5.0 ×16')
network=network.replace('Salina raises the published network configuration to two 400 Gb/s ports.', 'Salina lists two 400 Gb/s port configurations, while the same brief rates the card and service data path at 400G. The port list should therefore not be converted into an asserted 800G service-throughput result.')
network += """

## 4.11 Card resources and public disclosure gaps

SN1022 and U45N both combine an UltraScale+ FPGA with sixteen discrete Cortex-A72 cores, 12 GB total DDR4 and a 75 W board limit. Their host interfaces differ: SN1022 lists Gen4 x8 or Gen3 x16; U45N lists Gen3 x16 or two Gen4 x8 interfaces. AMD supports existing SN1022 users while directing new designs to U45N.

X3522 is a turnkey FPGA-based low-latency NIC; X3522PV exposes the programmable branch. The brief lists four 10/25G ports, 8 GB DDR4 and 35 W in NIC mode, versus 75 W for PV. Solarflare X4 uses a custom ASIC: X4522 has two ports up to 50G; X4542 has two up to 100G or four lower-rate ports. Its PCIe 5 x8 design is rated below 25 W.

The Hot Chips 2022 adaptive SmartNIC SoC separately discloses sixteen Cortex-A78AE application cores, four Cortex-R52 real-time cores, programmable logic, DDR5/LPDDR5 controllers and PCIe 5/CXL 2.0. No reviewed primary source maps it directly to a Pensando retail generation.

Newer Pensando briefs disclose external interfaces and services more fully than internal pipeline stages, table capacities, embedded cores or power envelopes. Those missing fields remain n/d. Programmable routing, selective retransmission and out-of-order placement still require evaluation under the intended topology and traffic pattern.
"""+sources('H1–H14; I1–I10; E9, E13; K2, K3; N34, N44, N49')

adaptive='\n\n'.join([sec('5.2','5.1'),sec('5.3','5.2'),sec('5.6','5.3')])+sources('J1–J13; G5, G7, G16, G17; K8')

systems="""# 6. Systems: nodes, baseboards and racks

## 6.1 The node is a separate architectural unit

Frontier combines one custom EPYC with four MI250X modules and four 200 Gb/s Slingshot network interfaces. There are eight logical GPU devices because each module contains two GCDs. Dividing node network bandwidth by four physical modules yields 25 GB/s per module per direction; dividing by eight logical GPUs produces a different number. Both calculations need their denominator stated.

El Capitan replaces the separate host-plus-GPU pattern with four MI300A packages. Each integrates twenty-four CPU cores and coherent package HBM. The node therefore has ninety-six CPU cores, four GPU/APU packages and 512 GB of memory distributed across those packages, with four 200 Gb/s Slingshot interfaces. CPU/GPU locality improves inside each APU; communication between APUs remains a system-level path.

The MI300X and MI350 universal-baseboard model uses eight discrete GPU modules with external CPU hosts. OEMs choose CPU count, PCIe switching, NIC ratios, chassis and cooling. A rack containing sixty-four or 128 GPUs does not thereby become one scale-up domain: the direct baseboard domain remains eight unless another fabric is explicitly provided. GPU count per rack, GPU count per node and tightly coupled domain size must be recorded separately.

EPYC also hosts competing accelerators. NVIDIA's DGX A100, introduced at GTC 2020, used two EPYC 7742 CPUs. That is an AMD CPU deployment in a NVIDIA system, not an AMD GPU architecture disclosure. Hyperscaler instance launches similarly establish one service configuration rather than the full capability of a merchant CPU family.

## 6.2 System-design ownership and ecosystem boundaries

"""+mdtable('Acquisitions')+"""

The ZT transactions expanded AMD's system-design capability while leaving manufacturing with a partner. This matters to the scope of Helios: architecture, validation and customer integration are part of AMD's product effort, but not every rack component or manufacturing operation becomes an AMD silicon product. The same distinction applies to HPE, Cisco, Broadcom and other networking partners.

"""+sec('5.4','6.3')+"""

## 6.4 Power and cooling at the correct boundary

Eight MI350X modules sum to 8 kW of rated GPU board power; eight MI355X modules sum to 11.2 kW. CPUs, NICs, switches, fans or pumps, conversion losses and other components add to those figures. They are neither wall-power measurements nor complete rack ratings. Air versus liquid is a platform design choice tied to heat flux, coolant conditions, rack density and serviceability, rather than a label that determines efficiency by itself.

The reviewed final Helios blueprint establishes a liquid-cooled design and its compute/network population, but does not supply a complete rack-power specification suitable for this comparison. The table leaves that field n/d instead of back-solving it from an assumed GPU wattage. Facility planning requires the OEM's final power, cooling and redundancy envelope.
"""+sources('D8, E3, E7, E8, E13, E17, F8, F9, G6, G14, H12, H13, K3, K4; N14, N15, N21, N41–N44')

software=sec('5.5','7.1')+"""

## 7.2 Align software versions with hardware capabilities

The release timeline in the fixed comparison tables distinguishes product announcements from software release evidence. ROCm 6 accompanied MI300's launch in December 2023. MI350 enablement appears in the 6.4.x transition and subsequent compatibility records. ROCm 7 was previewed at Advancing AI 2025, while AMD's release article is dated 16 September. ROCm 10 and its developer-workflow additions were announced on 27 August 2026.

AMD also expanded the software organization through acquisitions: Nod.ai closed in October 2023, adding open-source compiler and deployment expertise; the Silo AI acquisition completed in August 2024, strengthening model development and deployment on AMD hardware. These are engineering capabilities around the platform, not additional processor architectures.

A datatype being present in the ISA is only the first step. The compiler must expose it, libraries must implement useful operations, frameworks must select those operations, and model accuracy must tolerate the numerical format. The same is true of partitioning: supported hardware modes can differ from the combinations accepted by a particular driver, runtime, virtualization stack or collective library. The versioned compatibility matrix remains the authority for a deployment.

RCCL performance depends on both the GPU topology and the network plugin/transport path. More NIC bandwidth cannot hide arbitrary host copies, synchronization or poor collective scheduling. HIP portability can preserve a programming interface while still requiring target-specific kernels, layouts, occupancy choices and communication tuning. The ASPLOS work on compute/collective overlap is useful research context here, but it is not evidence that its proposed hardware exists in a current Instinct product.

The accompanying tools have different compilation targets. Pensando uses P4 for fast-path services and C/C++ on its embedded CPU complex. Vitis and Vivado produce adaptive hardware and AI Engine programs; XRT manages supported accelerator execution. Onload accelerates host networking through a separate driver and user-space stack. A complete AMD installation can use all of these without having one universal compiler or runtime for the entire rack.
"""+sources('K5–K9; H7, H8; F10; N17–N19, N24, N28, N36, N51, N52')

comparisons="""# 8. Fixed-schema comparison tables

These tables preserve the common schemas for use alongside reports on other vendors. The downloadable CSVs contain the same cells without page-width constraints. “Max” refers to the stated family maximum or named reference SKU. A combination of column maxima is not a claim that every SKU exposes all of them simultaneously.

First disclosure and GA are separate in Section 8.7. Historical shipping rows record an established commercial generation; they do not assert continued orderability. Newly launched products with no established broad GA remain limited availability. Roadmap entries have no inferred specifications.
"""
for i,(name,title) in enumerate([('CPU','Host CPUs'),('Accelerator','AI and HPC accelerators'),('Network','DPUs, AI NICs and network adapters'),('Interconnect','Scale-up interconnect'),('System','Systems'),('Software','Software chronology'),('Availability','Disclosure and availability chronology')],1):
    comparisons+=f'\n\n## 8.{i} {title}\n\n'+mdtable(name)
comparisons+="""

Per-row primary-source keys, disclosure dates and normalization notes are in row_sources.json and the claims ledger. Accelerator matrix throughput is TFLOP/s throughout; package HBM capacity and bandwidth follow final product specifications. MI250X bandwidth is the vendor-rounded 3.2 TB/s package value. Its detailed interface arithmetic can produce 3.2768 TB/s; derived ratios here consistently use 3.2 rather than mixing the two.
"""

stack="""# 9. Integrated AI-infrastructure stack

## 9.1 Four eras of integration

The figures show representative architectural patterns, not mandatory bills of materials. Partner components are labeled as such. The bandwidth table preserves the endpoint and direction of each connection; a blank disclosure cannot be repaired by borrowing a number from an adjacent layer.

![2017–2020 stack: discrete accelerator and CPU, with optional GPU peer fabric](amd_framework/figures/era_1.png)

In the first era, EPYC supplies general compute, host memory and PCIe attachment. MI25 and later MI100 supply their own HBM. Partner NICs handle cluster traffic; a four-GPU IF hive is available in the MI100 generation. CPU memory, accelerator memory and the network remain separate resources.

![2021–2022 stack: Frontier node with four dual-GCD MI250X modules](amd_framework/figures/era_2.png)

Frontier combines coherent node integration with a two-GCD accelerator. ROCm and application placement must account for eight logical GPUs across four physical packages. The Slingshot fabric is the scale-out network; it is not another name for the package-interior link.

![2023–2025 stack: eight-GPU UBB and the MI300A shared-HBM alternative](amd_framework/figures/era_3.png)

MI300 splits into two system patterns. MI300A puts CPU and GPU access inside one coherent HBM package. MI300X, MI325X and MI350 use external hosts and a direct eight-GPU baseboard. Pollara can provide the back-end network, while a Pensando DPU can service the front end. These choices are complementary rather than one unavoidable component sequence.

![2026 stack: Helios rack with distinct scale-up, scale-out and front-end paths](amd_framework/figures/era_4.png)

Helios combines eighteen Venice CPUs, seventy-two MI455X GPUs, a switched UALoE scale-up domain, and Vulcano scale-out attachment. The maximum published scale-out configuration uses three 800G NICs per GPU, or 300 GB/s per direction; two-NIC configurations provide 200 GB/s. Salina occupies the infrastructure-service path. Rack management, liquid cooling and ROCm/fabric software complete the design.

## 9.2 Bandwidth hierarchy by era

"""+mdtable('Bandwidth_hierarchy')+"""

The hierarchy shows why bulk memory movement cannot be modeled with one “system bandwidth.” MI355X's 8 TB/s HBM rate is about fifteen times its one-direction scale-up total and 160 times a configured 400G NIC. MI455X's larger switched fabric improves the remote path substantially, yet local HBM is still about thirteen times the one-direction scale-up total and about seventy-eight times maximum scale-out. These are peak-rate ratios, not latency or collective-performance predictions.

## 9.3 Technology reuse across the stack

"""+sec('8.1','9.3.1')+'\n\n'+sec('8.2','9.3.2')+"""

The reuse extends to integration techniques: EFB appears in MI250X and Venice disclosures; hybrid bonding supports stacked cache and GPU compute-over-I/O designs; mature-node infrastructure dies preserve expensive leading-edge area for compute. Reuse does not imply identical implementations. V-Cache's vertical interface, MI300's compute-to-IOD links and a rack-scale UALoE connection solve different distance, power and bandwidth problems.
"""+sources('A1–A9, B2–B14, C1–C7, D2–D10, E1–E19, G14, H6, I1–I5, J1–J13, K2–K9; N14, N15, N24–N31')

trends='\n\n'.join(sec(f'9.{i}',f'10.{i}') for i in range(1,7))
trends += """

## 10.7 Quantitative balance across generations

"""+mdtable('Derived_ratios')+"""

HBM bytes per FLOP is bandwidth divided by dense arithmetic throughput: for GB/s and TFLOP/s, divide the numerical bandwidth by 1,000 times the numerical compute rate. It is not memory capacity divided by FLOPs. DRAM bandwidth per core uses populated channel count and maximum transfer rate. Cache per core is an average capacity ratio, not a promise of an equal private allocation.

The scale-up/HBM ratio uses one direction of total accelerator link bandwidth. For MI250X, its external-port sum is a capacity bound with node-specific allocation, not an eight-peer all-to-all guarantee. Scale-out values for MI300X, MI325X and MI350 are explicit one-400G-NIC-per-GPU examples; they are not fixed silicon specifications. Frontier and El Capitan values divide their documented node network by physical accelerator packages.

Peak BF16 divided by rated watts is a deliberately narrow ratio. It gives approximately 2.31 TFLOP/s/W for MI350X and 1.80 for MI355X. This does not establish measured energy efficiency: the devices use different operating points, power may include different stated boundaries, and workload utilization determines useful output. MI455X is left n/d because a comparable final board-power figure is not established here.

## 10.8 The costs behind the architectural choices

**Chiplets and stacking.** Smaller reusable compute dies and heterogeneous nodes can improve manufacturing economics and product coverage, but add links, package complexity, test requirements and locality. Hybrid bonding supplies dense vertical connectivity; it also couples floorplanning, thermal design and assembly yield. The V-Cache latency increment is a concrete example of capacity gained at a nonzero access cost.

**Precision and reuse.** Arithmetic has grown faster than the ability to stream unique operands from HBM. Low-precision formats increase peak operations per byte and can reduce model storage, but require scaling metadata, numerical validation and tuned kernels. The bytes-per-FLOP trend argues for more reuse and overlap, not for assuming every format will deliver its headline rate on every model.

**Scale-up and switching.** The direct eight-GPU mesh offers simple one-hop peer connectivity within a small domain. Helios increases the domain to seventy-two through switches, adding congestion, failure handling and fabric-management responsibilities. Wider links help only if the communication pattern and collective implementation can use the available paths.

**CPU as execution and memory tier.** EPYC remains a CPU-compute product while also hosting GPUs, feeding data and running orchestration. Venice's memory-channel growth and Verano's LPDDR roadmap highlight host-memory capacity, bandwidth and power as system-design variables. Offloading inactive inference state to host or storage tiers saves HBM only when retrieval latency and bandwidth remain acceptable.

**Power and supply.** Higher GPU density makes liquid cooling and rack power delivery part of performance engineering. HBM stacks and advanced packaging also become production dependencies. Public product sources establish the component requirements, but do not quantify AMD's allocation, packaging yields or future supply headroom; those are not estimated here. The architectural risk is exposure to those dependencies, not a asserted production shortage.

**Software and standards.** Open interfaces can widen the partner ecosystem, while integration and optimization work remains substantial. A standards-compatible port does not by itself provide a stable collective stack, fleet management or efficient kernels. The useful outcome is an application that runs reliably at the intended scale; that requires the software chronology to be read alongside the hardware tables.
"""+sources('A7, A10, B4, C3, C8, D5, D7, D8, E1, E3, E10, E15, F1, F2, F8–F12, K2–K9; N1, N2, N5–N19, N22–N31')

conference='\n\n'.join(sec(f'6.{i}',f'11.{i}') for i in range(1,6))+'\n\n'+sec('7.1','11.6')+'\n\n'+sec('7.2','11.7')+"""

## 11.8 Indexed disclosures and events

The index links product architecture, implementation and deployment evidence. A paper's presence is not evidence that all of its proposed mechanisms shipped. Industry-product papers are distinguished from related research, and the IEEE Micro journal is distinct from the MICRO conference. Some archive entries group several talks or years; these are discovery guides rather than claims of a single paper with that title.

For paywalled records, this report uses the accessible abstract, program, author manuscript or vendor slides named in the bibliography. It does not claim to have reconstructed a circuit from a title alone. In particular, the ISSCC 2026 program establishes the MI350 paper and die-node pairing; the detailed architecture here comes from the available CDNA 4 documentation and product material.

"""+mdtable('Conference_index')+"""

## 11.9 Venue coverage and limits

The strongest direct architectural record is at Hot Chips; ISSCC and VLSI supply complementary implementation and integration evidence. ISCA provides several direct industrial accounts and the exascale retrospective. MICRO, HPCA and ASPLOS add research, modeling and hardware/software studies whose relationship to products must be stated explicitly.

Company events establish launches and roadmaps. Computex and CES connect server technology to client and local AI. OCP addresses rack integration; MWC emphasizes telco and edge constraints. re:Invent, Ignite, Build and Google Cloud Next establish cloud offerings. GTC belongs here through EPYC host deployments such as DGX A100. A product announced near one of these events is not automatically presented there, and an AMD-sponsored session is not automatically a new architecture disclosure.

The 2026 academic check also identifies AMD participation in ISCA work on the next SPEC CPU suite, cluster power management and thermal coupling, plus an AMD resilience keynote at HPCA. These index entries are program-level research context; no undisclosed Turin, MI350 or MI455X mechanism is inferred from their titles.

The survey covers the material product disclosures found in these venues, with selected neighboring work at NSDI, ISPASS, SCA/HPCAsia, IEDM and DAC/DATE. It does not assert an exhaustive search of every PACT, ICS, HPDC, CGO, PPoPP, ICCAD, ECTC, FPGA, FCCM, FPL, FPT, SIGCOMM or OFC proceeding. Those remain relevant venues for follow-up on specific compiler, packaging, transport or adaptive-design questions.
"""+sources('A1–A10, B1, B2, B4, B5, B7–B10, C1, C2, C11, D2, D8, D10, E2–E5, E8, E11, E12, E18, F1–F15, G1–G18, H2, H3, H10–H14, I2, I6, J5–J7; N53, N54')

crosswalk="""# 12. Codename crosswalk

The crosswalk separates die names, architecture names, product numbers and systems. Future names carry the roadmap disclosed by July 2026; their listed role does not establish unpublished specifications. gfx targets are software ISA identities rather than marketing generations.

"""+mdtable('Codename_crosswalk')+sources('A2, A4, A8, A9, B3, B6, B8, B11–B14, C3, C8, C9, D1–D3, D5, D7, E1, E10, E15–E19, H2, H4–H6, I1–I10, J2, J5, J6, J8; N1, N2, N22, N23, N30, N31, N39, N45, N49, N50')

refs=json.loads((ROOT/'references_original.json').read_text())
for r in refs.values():
    r['text']=r['text'].replace('https://www.amd.com/content/dam/amd/en/documents/epyc-technical-docs/tuning-guides/amd-epyc-7002-tg-hpc-56827.pdf','https://docs.amd.com/v/u/en-US/amd-epyc-7002-tg-hpc-56827')
    r['text']=r['text'].replace('https://www.hpe.com/psnow/doc/a50010559enw','https://www.hpe.com/psnow/doc/a00118627enw')
refs['H12']['text']='HPE, Pensando in distributed switch services. [Secure interconnect architecture](https://arubanetworking.hpe.com/techdocs/VSG/docs/040-dc-design/esp-dc-design-022-secure-dci/). Current switch QuickSpecs are listed under N34.'
for r in refs.values():r['urls']=re.findall(r'\]\((https?://[^\s]+)\)',r['text'])
extra=json.loads((ROOT/'references_extra.json').read_text())
for r in extra:refs[r['key']]={'key':r['key'],'text':f"{r['title']}. {r['date']}. [Primary source]({r['url']}).",'group':r['group'],'urls':[r['url']]}
groups={name:[] for name in ['Conference papers, by venue and year','Conference talks, slides and recordings','Vendor technical documentation','Company-event keynotes and sessions','Partner disclosures','Related research','Independent measurements']}
paperkeys=set('A3 A4 A6 A7 B2 B4 B9 B10 C2 C11 D10 E2 E4 E12 F8 F9 F15 H10 J6'.split())
talkkeys=set('A1 A2 A5 B1 B5 B8 C1 D2 D8 E3 E11 E18 G15 G16 G17 H2 I2 I6 J5 J7'.split())
researchkeys=set('F1 F2 F3 F4 F5 F6 F7 F10 F12 F13 F14'.split())
indkeys={'A10','F11'}
eventkeys=set('A8 B7 B12 B13 B14 C4 C7 C8 C9 D1 D3 D4 D6 D9 E6 E9 E13 G1 G2 G3 G4 G5 G6 G7 H1 I3 J4 J12 J13 K1'.split())
partnerkeys=set('C12 E7 E8 G8 G9 G10 G11 G12 G13 G14 H11 H12 H13 H14 K4'.split())
for k,r in refs.items():
    if k in paperkeys:g='Conference papers, by venue and year'
    elif k in talkkeys:g='Conference talks, slides and recordings'
    elif k in researchkeys or r.get('group')=='research':g='Related research'
    elif k in indkeys:g='Independent measurements'
    elif k in eventkeys or r.get('group')=='event':g='Company-event keynotes and sessions'
    elif k in partnerkeys or r.get('group')=='partner':g='Partner disclosures'
    else:g='Vendor technical documentation'
    groups[g].append((k,r))
venueorder={'ISSCC':0,'ISCA':1,'VLSI':2,'IEDM':3,'NSDI':4,'SCA':5}
def sortpaper(item):
    txt=item[1]['text'];v=next((x for x in venueorder if x in txt),'z');ys=re.findall(r'20\d\d',txt)
    return venueorder.get(v,9),int(ys[0]) if ys else 9999,item[0]
groups['Conference papers, by venue and year'].sort(key=sortpaper)
bib="""# 13. Bibliography and source-use guide

References are grouped by evidence type. The conference index and chapter source maps connect these entries to the narrative; the companion ledger maps numerical cells to source keys and disclosure dates. Original source identifiers are retained so the revised report remains traceable to its earlier edition.

Public technical documents and author copies were used where available. Some IEEE/ACM pages restrict full-text access and some conference archives reject automated downloads; the bibliography identifies the accessible program, abstract, author manuscript or vendor-slide version where one is used. The research-data archive includes link-check results and access limitations. A DOI or program entry is not presented as evidence that the full paper was read.

Current product pages were checked at the cutoff. Material revisions include MI325X's 288 GB preview becoming 256 GB at launch, Turin's current DDR5-6400 specification versus the earlier 6000 MT/s guide, and the unresolved process-node wording in the EPYC 8005 guide. The chronology and tables use the final product or latest consistent primary specification.
"""
for i,(name,rows) in enumerate(groups.items(),1):
    bib+=f'\n\n## 13.{i} {name}\n\n'
    bib+='\n'.join(f'- **{k}.** {r["text"]}' for k,r in rows)
bib+="""

## 13.8 Source navigation for current specification checks

The N-series supplements the conference record with current CPU and GPU specification pages, ROCm release and compatibility material, the final MI455X/Helios brochures, corporate transaction records, and card-specific network documents. N1–N4 support the CPU baseline and current Turin comparison; N5–N15 support accelerator and rack tables; N16 identifies regional shipments; N17–N20 support software and security; N21–N23 and N41–N44 establish transaction, production and deployment timing; N24–N29 give accelerator programming and format context; N30–N37 support portfolio, specification and chronology checks; N39–N40 and N45–N50 support the Sorano, MI350P, AM5 and network-card corrections. N51–N52 document software acquisitions; N53–N54 check the 2026 academic program record. N38 was discarded because its proposed product URL did not resolve to a verified document.

H3 and E5 are IEEE Micro journal articles, not MICRO conference papers. K1 duplicates the Advancing AI 2026 event recorded under C8 and is retained for compatibility with the original report. Bibliography links that point to an author's publication index are explicitly discovery/record links; only the technical detail established in the reviewed materials is used.
"""

document='\n\n'.join([intro,'# 1. EPYC products and technology evolution',cpu,'# 2. Instinct products and technology evolution',gpu,interconnect,'# 4. Networking: DPUs, AI NICs and related adapters',network,'# 5. Adaptive and adjacent accelerators',adaptive,systems,'# 7. Software and hardware enablement',software,comparisons,stack,'# 10. Engineering trends and trade-offs',trends,'# 11. Conference record and research context',conference,crosswalk,bib])
document=document.replace('not a asserted','not an asserted')
document=document.replace('mapped in Section 6','mapped in this chapter')
document=document.replace('Sections 1 and 2','Chapters 1 and 2')
# Normalize subheading labels inherited inside the shared-technology section.
document=document.replace('## 9.3.1 ','### CPU reuse: ').replace('## 9.3.2 ','### GPU reuse: ')
OUT.write_text(document+'\n')

# Record every narrative-table cell in the same ledger. Fixed-schema tables already
# have row-specific records; compact narrative tables use their chapter source map.
chapter='Front matter';lines=document.splitlines();i=0;ti=0
chapter_sources={
'Executive':'CPU Accelerator Interconnect System Derived_ratios tables',
'1':'A1 A2 A3 A4 A5 A6 A7 A8 A9 B2 B3 B4 B6 B8 B9 B10 B11 C1 C2 C3 C9 C10 N1 N2 N30 N31 N39 N45',
'2':'D1 D2 D3 D5 D7 E1 E3 E10 E15 E19 N5 N6 N7 N8 N9 N10 N11 N12 N13 N14',
'4':'H2 H4 H5 H6 H10 H11 H12 H13 I1 I2 I4 I6 I7 I8 I9 I10 N49',
'5':'J1 J2 J3 J4 J5 J6 J7 J8 J9 J10 J11 J12',
'6':'E17 K3 K4 N15 N21 N43',
'7':'K5 K6 K7 K8 K9 H7 H8 N17 N18 N19',
'9':'A1 B2 B8 C1 D2 D5 G16 G17 J12 K3',
'11':'A1 A2 A3 A4 A5 A6 A7 B1 B2 B4 B5 B8 B9 B10 C1 C2 D8 D10 E2 E3 E11 E12 E18 F1 F2 F3 F4 F5 F6 F7 F8 F9 F10 F11 F12 H2 H10 I2 I6 J5 J6 G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13 G14 G15 G16 G17',
}
fixed_headers={tuple(t['headers']) for t in TABLES.values()}
while i<len(lines):
    if lines[i].startswith('# '):chapter=lines[i][2:]
    if not lines[i].startswith('|'):i+=1;continue
    rows=[]
    while i<len(lines) and lines[i].startswith('|'):
        row=[c.strip() for c in lines[i].strip('|').split('|')]
        if not all(re.fullmatch(r':?-+:?',c) for c in row):rows.append(row)
        i+=1
    if tuple(rows[0]) in fixed_headers:continue
    ti+=1;ch=chapter.split('.')[0] if chapter[0].isdigit() else 'Executive'
    for ri,row in enumerate(rows[1:],1):
        for h,v in zip(rows[0],row):
            LEDGER.append({'claim':f'Narrative-{ti:02d}-{ri:02d}: {chapter} / {row[0]} / {h}','value':v,'basis':'Scope and units are stated in table or adjacent prose; chapter-level source map','source':chapter_sources.get(ch,'See chapter source map'),'disclosure date':'through 2026-09-27','status':'Synthesis from product disclosures; interpretation where labeled'})

(ROOT/'data'/'bibliography.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2))
write_data()
print('Report words:',len(document.split()),'references:',len(refs),'narrative tables:',ti)

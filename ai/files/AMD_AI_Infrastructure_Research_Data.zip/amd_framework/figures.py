"""Exact, schematic system figures; no implied physical floorplans."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT=Path(__file__).resolve().parent/'figures';ROOT.mkdir(exist_ok=True)
NAVY='#162B3E';TEAL='#006C70';RUST='#C9553A';GRAY='#EDF3F5';INK='#22313E';BLUE='#DDEBF1'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12})
def base(title,sub):
    f,a=plt.subplots(figsize=(13.2,8.1));f.patch.set_facecolor('white')
    a.set(xlim=(0,13.2),ylim=(0,8.1));a.axis('off');f.subplots_adjust(0,0,1,1)
    a.text(.45,7.7,title,color=NAVY,size=22,weight='bold',va='top')
    a.text(.45,7.14,sub,color='#586B78',size=11,va='top')
    return f,a
def box(a,x,y,w,h,title,body='',color=TEAL,fill=GRAY,fs=12):
    a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=0.10',edgecolor=color,facecolor=fill,linewidth=1.5,zorder=3))
    a.text(x+w/2,y+h-.20,title,color=color,size=fs+1,weight='bold',ha='center',va='top',zorder=4)
    if body:a.text(x+w/2,y+h/2-.10,body,color=INK,size=fs,ha='center',va='center',linespacing=1.45,zorder=4)
def arrow(a,p,q,label='',color=TEAL,bidir=True,offset=(0,0)):
    a.add_patch(FancyArrowPatch(p,q,arrowstyle='<->' if bidir else '-|>',mutation_scale=13,color=color,linewidth=1.7,zorder=2))
    if label:a.text((p[0]+q[0])/2+offset[0],(p[1]+q[1])/2+offset[1],label,ha='center',va='center',size=10,color=INK,bbox=dict(facecolor='white',edgecolor='none',pad=2),zorder=5)
def finish(f,a,name,source):
    a.text(.45,.19,source,color='#586B78',size=9,va='bottom')
    f.savefig(ROOT/(name+'.png'),dpi=190,facecolor='white');f.savefig(ROOT/(name+'.svg'),facecolor='white');plt.close(f)

f,a=base('2017–2020  |  A CPU host and discrete GPU memory','Representative EPYC + Instinct pattern; optional peer fabric depends on GPU generation')
box(a,.45,5.7,12.25,.8,'Applications · ROCm / HIP · CPU libraries',color=NAVY,fill=BLUE)
box(a,.65,3.45,4.2,1.45,'EPYC host','Naples → Rome\nLocal DDR4; general-purpose execution')
box(a,7.5,3.45,4.9,1.45,'Instinct accelerators','MI25 → MI100\nHBM is separate from host DDR',color=RUST)
arrow(a,(4.85,4.15),(7.5,4.15),'PCIe 3 → PCIe 4')
box(a,7.5,1.45,4.9,1.1,'MI100 peer domain','4 GPUs; 3 IF peer links per GPU',color=RUST)
arrow(a,(9.95,3.45),(9.95,2.55))
box(a,.65,1.45,4.2,1.1,'Partner network','Cluster, front-end and storage traffic',color=NAVY)
arrow(a,(2.75,3.45),(2.75,2.55),'Host I/O',offset=(.6,0))
a.text(.7,.76,'System boundary: OEM server / node',size=12,color=NAVY,weight='bold')
finish(f,a,'era_1','Sources: A2, A8, D1, D5, D6. Topology is schematic; no mandatory GPU or NIC population is implied.')

f,a=base('2021–2022  |  Frontier combines packages into a node','1 custom EPYC + 4 MI250X modules = 8 logical GPU devices')
box(a,.45,5.85,12.25,.7,'Applications · ROCm · topology-aware work and data placement',color=NAVY,fill=BLUE)
box(a,.6,3.6,2.7,1.4,'Custom EPYC','CPU cores + DDR4')
for j,(x,y) in enumerate([(4.2,4.15),(8.65,4.15),(4.2,2.15),(8.65,2.15)],1):
    box(a,x,y,3.9,1.2,f'MI250X module {j}','2 GCDs / logical GPUs\n128 GB HBM2e per module',color=RUST,fs=10.5)
arrow(a,(3.3,4.3),(4.2,4.3),'IF',offset=(0,.25))
arrow(a,(8.1,4.7),(8.65,4.7))
arrow(a,(8.1,2.7),(8.65,2.7))
arrow(a,(6.15,4.15),(6.15,3.35),'Node IF')
arrow(a,(10.6,4.15),(10.6,3.35),'Node IF')
box(a,.6,.65,11.95,.95,'Partner scale-out: HPE Slingshot','4 × 200 Gb/s interfaces per node = 100 GB/s per direction in aggregate',color=NAVY,fs=11)
arrow(a,(6.15,2.15),(6.15,1.60))
arrow(a,(10.6,2.15),(10.6,1.60))
a.text(.66,2.75,'Direct liquid cooling\nNode links abstracted;',color=INK,size=11,linespacing=1.6)
a.text(.66,2.03,'not a link-by-link\nwiring diagram.',color=INK,size=11,linespacing=1.6)
finish(f,a,'era_2','Sources: D7, D8, F8. HBM and network totals are per physical module or node, as labeled.')

f,a=base('2023–2025  |  Two different integration choices','Discrete eight-GPU baseboards and coherent CPU–GPU APUs share an integration lineage')
box(a,.45,5.9,12.25,.7,'Applications · ROCm / HIP · libraries · RCCL',color=NAVY,fill=BLUE)
box(a,.55,4.45,6.5,.85,'External EPYC host + DDR5',color=TEAL)
box(a,.55,2.50,6.5,1.25,'Eight-GPU universal baseboard','MI300X / MI325X / MI350X / MI355X\nHBM per GPU; direct all-to-all IF (7 peers/GPU)',color=RUST,fs=11)
arrow(a,(3.8,4.45),(3.8,3.75),'PCIe 5',offset=(.7,0))
box(a,.55,.72,3.05,1.0,'Back-end network','Pollara 400 or partner NIC',color=NAVY,fs=10.5)
box(a,4,.72,3.05,1.0,'Front-end services','Pensando DPU, optional',color=TEAL,fs=10.5)
arrow(a,(2.1,2.5),(2.1,1.72),'RDMA')
arrow(a,(5.5,2.5),(5.5,1.72),'Service path')
box(a,8.05,2.5,4.6,2.8,'MI300A / El Capitan alternative','Per package:\n24 Zen 4 cores + CDNA 3 GPU\n128 GB coherent shared HBM\n\n4 APUs per node',color=RUST,fs=11)
box(a,8.05,.72,4.6,1,'HPE Slingshot','4 × 200 Gb/s interfaces per node',color=NAVY,fs=10.5)
arrow(a,(10.35,2.5),(10.35,1.72),'Scale-out')
a.plot([7.55,7.55],[.75,5.35],color='#B8C8D0',ls='--',lw=1)
finish(f,a,'era_3','Sources: E1, E3, E7, E10, I1, I2, H6. An eight-GPU baseboard domain does not expand just because more boards occupy a rack.')

f,a=base('2026  |  Helios separates three communication roles','Published reference: 18 Venice CPUs + 72 MI455X GPUs; launch/production disclosed, customer rollout varies')
box(a,.45,5.95,12.25,.65,'ROCm / RCCL · Fabric Manager / Fabric OS · platform management',color=NAVY,fill=BLUE)
box(a,.55,3.8,3.25,1.3,'Front end / storage','Salina DPU\nServices, security, retained state',color=TEAL,fs=11)
box(a,4.65,3.8,7.9,1.3,'18 compute trays: 1 Venice + 4 MI455X each','Per GPU: 432 GB HBM4 · 23.3 TB/s local memory\nCPU–GPU link: 128 GB/s per direction',color=RUST,fs=11)
arrow(a,(3.8,4.45),(4.65,4.45),'Services',offset=(0,.32))
box(a,.55,1.55,5.55,1.3,'Scale-up: UALoE','72-GPU domain · 12 switches / 6 trays\n1.8 TB/s per GPU per direction',color=RUST,fs=11)
box(a,6.95,1.55,5.6,1.3,'Scale-out: Vulcano + partner Ethernet','2 or 3 × 800G NICs per GPU\n200 or 300 GB/s per GPU per direction',color=NAVY,fs=11)
arrow(a,(6.1,3.8),(3.3,2.85),'GPU peer traffic')
arrow(a,(10.3,3.8),(10.3,2.85),'Inter-system traffic',offset=(1.1,0))
a.text(.65,.85,'Rack layer: liquid cooling · power delivery · serviceability · OCP-aligned design',color=NAVY,size=12,weight='bold')
a.text(.65,.52,'Switch silicon, optics and manufacturing include partner components. Rack HBM is distributed, not uniformly local.',color=INK,size=10.5)
finish(f,a,'era_4','Sources: C8, E17, I4, I5, K2, K3, N14, N15. Rates are normalized from vendor bidirectional totals where applicable.')
print('Created',len(list(ROOT.glob('*.png'))),'figures')

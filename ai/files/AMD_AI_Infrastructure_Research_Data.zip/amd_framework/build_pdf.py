from pathlib import Path
import re, html, json
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    PageBreak, Table, TableStyle, KeepTogether,
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.platypus import NextPageTemplate, Image
from reportlab.lib.pagesizes import A3, landscape

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'AMD_AI_Infrastructure_2015-2026.md'
OUT = ROOT / 'AMD_AI_Infrastructure_2015-2026.pdf'
FONT = Path('/usr/share/fonts/truetype/dejavu')
pdfmetrics.registerFont(TTFont('DejaVu', str(FONT/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DejaVu-Bold', str(FONT/'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DejaVuSerif', str(FONT/'DejaVuSerif.ttf')))
pdfmetrics.registerFont(TTFont('DejaVuSerif-Bold', str(FONT/'DejaVuSerif-Bold.ttf')))
pdfmetrics.registerFontFamily('DejaVu', normal='DejaVu', bold='DejaVu-Bold', italic='DejaVu', boldItalic='DejaVu-Bold')
pdfmetrics.registerFontFamily('DejaVuSerif', normal='DejaVuSerif', bold='DejaVuSerif-Bold', italic='DejaVuSerif', boldItalic='DejaVuSerif-Bold')

NAVY=colors.HexColor('#162B3E')
TEAL=colors.HexColor('#006C70')
RUST=colors.HexColor('#C9553A')
INK=colors.HexColor('#22313E')
MUTED=colors.HexColor('#5E6C76')
PALE=colors.HexColor('#EDF3F5')
LINE=colors.HexColor('#D3DEE3')
PAGE_W,PAGE_H=A4
MARGIN=45
WIDTH=PAGE_W-2*MARGIN

styles={
    'body':ParagraphStyle('Body',fontName='DejaVu',fontSize=9.5,leading=14.1,textColor=INK,spaceAfter=8.3,allowWidows=0,allowOrphans=0),
    'h1':ParagraphStyle('Chapter',fontName='DejaVu-Bold',fontSize=21,leading=27,textColor=NAVY,spaceBefore=0,spaceAfter=16,keepWithNext=True),
    'h2':ParagraphStyle('Section',fontName='DejaVu-Bold',fontSize=13.2,leading=18,textColor=TEAL,spaceBefore=17,spaceAfter=9,keepWithNext=True),
    'cell':ParagraphStyle('Cell',fontName='DejaVu',fontSize=8.15,leading=11.6,textColor=INK),
    'th':ParagraphStyle('TH',fontName='DejaVu-Bold',fontSize=8.05,leading=11.3,textColor=colors.white),
    'ref':ParagraphStyle('Reference',fontName='DejaVu',fontSize=8.4,leading=12.4,textColor=INK,spaceAfter=7.5,allowWidows=0,allowOrphans=0),
    'bullet':ParagraphStyle('Bullet',fontName='DejaVu',fontSize=9.5,leading=14.1,textColor=INK,spaceAfter=8,leftIndent=11,firstLineIndent=-10,allowWidows=0,allowOrphans=0),
    'small':ParagraphStyle('Small',fontName='DejaVu',fontSize=9,leading=13.5,textColor=MUTED,spaceAfter=9),
    'toc':ParagraphStyle('TOC',fontName='DejaVu',fontSize=9.6,leading=14.5,textColor=NAVY,leftIndent=0,firstLineIndent=0,spaceBefore=7),
}

def inline(s):
    s=html.escape(s.strip())
    s=re.sub(r'\[([^\]]+)\]\((https?://\S+)\)',lambda m:f'<link href="{m.group(2)}" color="#006C70">{m.group(1)}</link>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'(?<!\*)\*([^*]+)\*(?!\*)',r'<i>\1</i>',s)
    return s

def footer(c,doc):
    if doc.page==1:
        draw_cover(c)
        return
    c.saveState()
    c.setStrokeColor(LINE)
    pw,ph=c._pagesize
    c.line(MARGIN,ph-35,pw-MARGIN,ph-35)
    c.setFont('DejaVu-Bold',7.4)
    c.setFillColor(MUTED)
    c.drawString(MARGIN,ph-25,'AMD AI INFRASTRUCTURE  /  2015–2026')
    c.setFont('DejaVu',7.3)
    c.drawString(MARGIN,25,'Research cutoff: 27 September 2026')
    c.drawRightString(pw-MARGIN,25,f'{doc.page:02d}')
    c.restoreState()

def cover_par(c,text,y,font='DejaVu',size=11,color=INK,leading=17,width=WIDTH):
    st=ParagraphStyle('CoverText',fontName=font,fontSize=size,leading=leading,textColor=color)
    p=Paragraph(inline(text),st)
    w,h=p.wrap(width,500)
    p.drawOn(c,MARGIN,y-h)
    return y-h

def draw_cover(c):
    c.saveState()
    c.setFillColor(NAVY)
    c.rect(0,PAGE_H-405,PAGE_W,405,fill=1,stroke=0)
    c.setFillColor(RUST)
    c.rect(MARGIN,PAGE_H-82,55,5,fill=1,stroke=0)
    c.setFillColor(colors.HexColor('#BBD3DE'))
    c.setFont('DejaVu-Bold',10)
    c.drawString(MARGIN,PAGE_H-110,'ARCHITECTURE RESEARCH REPORT')
    c.setFont('DejaVu-Bold',34)
    c.setFillColor(colors.white)
    c.drawString(MARGIN,PAGE_H-172,'AMD AI')
    c.setFont('DejaVu-Bold',29)
    c.drawString(MARGIN,PAGE_H-215,'INFRASTRUCTURE')
    cover_par(c,'A decade of architectural evolution',PAGE_H-245,'DejaVu',19,colors.white,26)
    cover_par(c,'EPYC • Instinct • Pensando • Adaptive computing',PAGE_H-307,'DejaVu',12,colors.HexColor('#BBD3DE'),19)
    c.setFillColor(TEAL)
    c.rect(MARGIN,PAGE_H-387,120,24,fill=1,stroke=0)
    c.setFillColor(colors.white)
    c.setFont('DejaVu-Bold',10)
    c.drawString(MARGIN+11,PAGE_H-380,'2015–2026')
    y=PAGE_H-446
    y=cover_par(c,'From CPU and GPU generations to programmable networking and complete AI systems.',y,'DejaVu-Bold',14,NAVY,21)
    y-=21
    y=cover_par(c,'Product histories for EPYC, Instinct, Pensando DPUs and AI NICs, with adaptive accelerators, rack platforms and software. Built from Hot Chips, ISSCC, ISCA, MICRO, HPCA, ASPLOS and networking research.',y,'DejaVu',10.7,INK,17)
    y-=22
    y=cover_par(c,'Framework edition: normalized comparisons, a claims ledger, four system-era diagrams, conference index and codename crosswalk.',y,'DejaVu',10.7,INK,17)
    c.setStrokeColor(LINE)
    c.line(MARGIN,104,PAGE_W-MARGIN,104)
    c.setFont('DejaVu',9)
    c.setFillColor(MUTED)
    c.drawString(MARGIN,81,'Coverage and research cutoff: 27 September 2026')
    c.drawString(MARGIN,64,'Product generations first • Sources collected at the end')
    c.restoreState()

class Report(BaseDocTemplate):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw)
        self.headings=[]
    def beforeDocument(self):
        self.headings=[]
    def afterFlowable(self,f):
        if isinstance(f,Paragraph) and hasattr(f,'bookmark'):
            title=f.getPlainText()
            self.canv.bookmarkPage(f.bookmark)
            self.canv.addOutlineEntry(title,f.bookmark,f.level,closed=(f.level==0))
            self.headings.append({'title':title,'page':self.page,'level':f.level})
            if f.level==0:
                self.notify('TOCEntry',(0,title,self.page,f.bookmark))

def widths_for(rows):
    headers=' '.join(rows[0])
    n=len(rows[0])
    if 'Calculated GB/s' in headers: weights=[1.35,1.55,1.05,.5,1.05]
    elif 'DPU generation' in headers: weights=[.95,1.2,1.4,1.65]
    elif 'AI NIC configuration' in headers: weights=[1.1,1.2,1.2,1.4]
    elif 'Product branch' in headers: weights=[.95,1.1,1.25,1.4]
    elif 'Infrastructure function' in headers: weights=[1.1,1.45,1.8]
    elif 'Software or platform' in headers: weights=[1.3,1.15,1.75]
    elif 'Introduction' in headers and n==5: weights=[1.1,.8,.8,1.35,1.65]
    elif 'Introduction' in headers: weights=[1.2,.75,1.35,1.8]
    elif 'Full compute-die' in headers: weights=[1.1,1.85,1.3,.8]
    elif 'Product or technology' in headers: weights=[1.1,1.9,1.9]
    elif 'Venue group' in headers: weights=[1.05,1.65,2.1]
    elif 'Verified AMD' in headers: weights=[1.15,2.1,1.2]
    elif 'Core generation' in headers: weights=[.8,1.45,2.4]
    elif 'Venue and year' in headers: weights=[.8,2.0,1.7]
    else: weights=[1]*n
    return [WIDTH*v/sum(weights) for v in weights]

def make_table(rows):
    data=[[Paragraph(inline(cell),styles['th' if ri==0 else 'cell']) for cell in row] for ri,row in enumerate(rows)]
    tab=Table(data,colWidths=widths_for(rows),repeatRows=1,hAlign='LEFT')
    tab.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
        ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),
        ('LINEBELOW',(0,0),(-1,0),.6,TEAL),
        ('LINEBELOW',(0,1),(-1,-1),.25,LINE),
    ]))
    return tab

# Wide, schema-preserving tables use larger landscape sheets.
styles['widecell']=ParagraphStyle('WideCell',parent=styles['cell'],fontSize=8.2,leading=11.1)
styles['wideth']=ParagraphStyle('WideHeader',parent=styles['th'],fontSize=8.0,leading=10.8)
styles['caption']=ParagraphStyle('Caption',parent=styles['small'],fontSize=8.6,leading=12.2,spaceAfter=5)
styles['h3']=ParagraphStyle('H3',parent=styles['h2'],fontSize=11.3,leading=16)
styles['sourcemap']=ParagraphStyle('SourceMap',parent=styles['small'],fontSize=7.5,leading=11,spaceBefore=5)
styles['body'].leading=13.7
styles['body'].spaceAfter=7.5
styles['ref'].leading=12
styles['ref'].spaceAfter=6.5
styles['small'].fontSize=8.5
styles['small'].leading=12
styles['small'].spaceAfter=6
styles['toc'].fontSize=9.3
styles['toc'].leading=13
styles['toc'].spaceBefore=4
SIZES={'main':A4,'land':landscape(A4),'wide':landscape(A3)}
current='main'
heading_id=0
story=[Spacer(1,700),NextPageTemplate('main'),PageBreak()]

def switch(mode,force=False):
    global current
    if mode!=current:
        story.extend([NextPageTemplate(mode),PageBreak()]);current=mode
    elif force:story.append(PageBreak())
def heading(text,level=0,style=None):
    global heading_id
    heading_id+=1
    p=Paragraph(inline(text),styles[style or ('h1' if level==0 else 'h2')]);p.level=level;p.bookmark=f'section_{heading_id}'
    return p

def table_mode(rows):
    h=rows[0];n=len(h)
    if h[0] in ('Core','Architecture'):return 'main'
    if n>=9 or h[0] in ('Venue','Era / configuration','Configuration') and n>=7:return 'wide'
    if n>=6 or h[:2]==['Product','First material disclosure']:return 'land'
    return 'main'

def table_widths(rows,mode):
    width=SIZES[mode][0]-2*MARGIN;n=len(rows[0]);h=rows[0]
    if n==15:w=[1.05,.70,.9,.95,.72,.75,1.05,1.3,.62,1.3,1.7,1.25,1.15,.85,1.1]
    elif n==17:w=[1.05,.92,.93,1.0,.85,1.45,.72,.65,.85,.88,.86,1.5,1.0,1.75,1.05,1.1,.65]
    elif n==14:w=[1.05,.85,.9,.8,1.25,.75,1.15,1.25,.95,1.15,1.15,1.2,1.25,.85]
    elif h[0]=='Venue':w=[.9,.55,2.55,1.55,1.55,1.2,.65]
    elif h[0]=='Era / configuration':w=[1.1,1.7,1.0,1.4,1.55,1.45,.7]
    elif h[0]=='Core':w=[.65,1.4,1.5,1.65,1.6,.6]
    elif h[0]=='Architecture':w=[.85,2.1,.6,.6,1.5,.7]
    elif n==9:w=[1.1,.6,1.15,1.0,1.15,1.0,1.45,1.1,1.65]
    elif n==8:w=[1.35,.85,.75,1.1,1.1,1.1,1.25,1.2]
    elif n==7:w=[1.1,.6,1.5,1.3,1.5,1.0,1.0]
    elif h[:2]==['Product','First material disclosure']:w=[1.15,1.55,1.9,1.1,.55]
    elif h[0]=='Codename':w=[1.0,1.45,1.8,.6]
    elif n==5:w=[1.2,1.25,1.3,1.2,1.1]
    elif n==4:w=[1.05,1.35,1.9,.8] if h[-1]=='Sources' else [1.1,1.3,1.5,1.5]
    elif n==3:w=[1.05,1.8,2.1]
    else:w=[1]*n
    assert len(w)==n,(n,w)
    return [width*x/sum(w) for x in w]

def make_table(rows,mode='main'):
    cellstyle=styles['widecell'] if mode=='wide' else styles['cell']
    headstyle=styles['wideth'] if mode=='wide' else styles['th']
    data=[[Paragraph(inline(cell),headstyle if ri==0 else cellstyle) for cell in row] for ri,row in enumerate(rows)]
    tab=Table(data,colWidths=table_widths(rows,mode),repeatRows=1,hAlign='LEFT')
    tab.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),5 if mode=='wide' else 6),('RIGHTPADDING',(0,0),(-1,-1),5 if mode=='wide' else 6),
        ('TOPPADDING',(0,0),(-1,-1),5.5),('BOTTOMPADDING',(0,0),(-1,-1),5.5),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),
        ('LINEBELOW',(0,0),(-1,0),.6,TEAL),('LINEBELOW',(0,1),(-1,-1),.25,LINE),
    ]))
    return tab

def read_table(lines,i):
    rows=[]
    while i<len(lines) and lines[i].strip().startswith('|'):
        row=[c.strip() for c in lines[i].strip().strip('|').split('|')]
        if not all(re.fullmatch(r':?-+:?',c) for c in row):rows.append(row)
        i+=1
    return rows,i

raw=SRC.read_text();front,body=raw.split('# Executive synthesis',1)
story.append(Paragraph('Reading guide',styles['h1']))
story.append(Paragraph('Chapters 1–7 follow the product families. Chapter 8 preserves the fixed comparison schemas; Chapters 9–10 connect the stack and its engineering trade-offs. Chapters 11–13 provide the conference index, codename crosswalk and sources.',styles['body']))
toc=TableOfContents();toc.levelStyles=[styles['toc']];story.append(toc)
story.append(Spacer(1,15))
story.append(Paragraph('Scope',styles['h2']))
for line in front.splitlines():
    if line.startswith('**') or line.startswith('Research cutoff:'):story.append(Paragraph(inline(line),styles['small']))


lines=('# Executive synthesis'+body).splitlines();i=0;refs=False;last_heading=''
first_stack_figure=False
while i<len(lines):
    line=lines[i].strip()
    if not line:i+=1;continue
    if line.startswith('# '):
        title=line[2:];refs=title.startswith('13.')
        mode='wide' if title.startswith('8.') else 'land' if title.startswith('9.') else 'main'
        switch(mode,force=True)
        first_stack_figure=title.startswith('9.')
        story.append(heading(title));last_heading=title;i+=1;continue
    if line.startswith(('## ','### ')):
        is3=line.startswith('### ');title=line[4:] if is3 else line[3:]
        if title.startswith('9.1 '):
            i+=1
            while i<len(lines) and not lines[i].startswith('!['):i+=1
            continue
        j=i+1
        while j<len(lines) and not lines[j].strip():j+=1
        if j<len(lines) and lines[j].startswith('|'):
            rows,_=read_table(lines,j);mode=table_mode(rows)
            switch(mode,force=mode!='main' and current==mode and not title.startswith('8.1 '))
        elif title.startswith('11.8 '):switch('wide')
        elif current!='main':switch('main')
        story.append(heading(title,1,'h3' if is3 else None));last_heading=title;i+=1;continue
    if line.startswith('|'):
        rows,i=read_table(lines,i);mode=table_mode(rows)
        changed=mode!=current;switch(mode)
        if changed:story.append(Paragraph(inline(last_heading+' — comparison'),styles['h2']))
        chunk=8 if len(rows[0]) in (15,17) else 25 if rows[0][0]=='Venue' else 11 if rows[0][:2]==['Product','First material disclosure'] else None
        if chunk and len(rows)-1>chunk:
            for start in range(1,len(rows),chunk):
                if start>1:story.append(PageBreak())
                story.append(make_table([rows[0]]+rows[start:start+chunk],mode))
        else:story.append(make_table(rows,mode))
        story.append(Spacer(1,10));continue
    if line.startswith('!['):
        m=re.match(r'!\[([^\]]+)\]\(([^)]+)\)',line);alt,path=m.groups();switch('land',force=current=='land' and not first_stack_figure)
        image_path=ROOT/path
        im=Image(str(image_path));ratio=im.imageHeight/im.imageWidth
        image_width=660 if first_stack_figure else 710
        first_stack_figure=False
        im.drawWidth=image_width;im.drawHeight=image_width*ratio
        story.append(im);i+=1
        while i<len(lines) and not lines[i].strip():i+=1
        para=[]
        while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','![','- ')):
            para.append(lines[i].strip());i+=1
        if para:story.append(Paragraph(inline(' '.join(para)),styles['caption']))
        continue
    if line.startswith('- '):
        st=styles['ref' if refs else 'bullet'];txt=line[2:] if refs else '• '+line[2:]
        story.append(Paragraph(inline(txt),st));i+=1;continue
    para=[line];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','- ','![')):
        para.append(lines[i].strip());i+=1
    text=' '.join(para)
    st=styles['sourcemap'] if text.startswith('*Source map:') else styles['body']
    story.append(Paragraph(inline(text),st))

doc=Report(str(OUT),pagesize=A4,rightMargin=MARGIN,leftMargin=MARGIN,topMargin=53,bottomMargin=46,
           title='AMD AI Infrastructure: Architecture, Implementation and System Evolution, 2015–2026',
           author='Architecture Research',subject='EPYC, Instinct, scale-up fabric, Pensando, adaptive computing, systems and software; framework revision',pageCompression=1)
for name,(pw,ph) in SIZES.items():
    doc.addPageTemplates(PageTemplate(id=name,pagesize=(pw,ph),frames=[Frame(MARGIN,46,pw-2*MARGIN,ph-99,id=name+'body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=footer))
doc.multiBuild(story)
(ROOT/'amd_framework'/'report_headings.json').write_text(json.dumps(doc.headings,indent=2))
print(OUT,'Pages:',doc.page)

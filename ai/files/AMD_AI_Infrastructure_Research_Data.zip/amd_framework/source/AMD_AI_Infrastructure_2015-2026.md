# AMD AI Infrastructure: A Decade of Architectural Evolution

## EPYC, Instinct, Pensando, adaptive computing, and the conference record

Research coverage: 2015–27 September 2026  
Prepared 27 September 2026

This report follows AMD's AI infrastructure portfolio through its product generations: EPYC CPUs, Instinct GPUs, Pensando DPUs and AI NICs, adaptive accelerators, network adapters, rack platforms and software. It connects Hot Chips architecture, ISSCC implementation, research at ISCA, MICRO, HPCA, ASPLOS and NSDI, and industry deployment announcements. Desktop, workstation and embedded products connect the data-center story to local and physical AI.

The emphasis is on material architectural disclosures rather than an inventory of every AMD-affiliated paper, sponsored session or product SKU. Specifications describe representative products or stated family maxima; a family maximum need not be available on every member. Announced future products are identified separately. References are grouped at the end to keep the narrative readable.

## The central finding

AMD's server evolution is a story about changing the boundaries of a processor. EPYC first combined several complete CPU dies in one package, then separated compute from memory and I/O, then varied core density and cache capacity around a reusable platform. Instinct progressed from graphics-derived compute devices to a dedicated compute architecture, then to multiple GPU dies, vertically stacked compute and infrastructure chiplets, and finally a rack-scale accelerator system.

The two product lines increasingly share an engineering method: use an advanced process where transistor density and switching performance matter most, preserve other functions on a more appropriate process, and invest in the interconnect and packaging needed to make the pieces useful together. MI300A is the clearest point of convergence because it combines Zen CPU chiplets, CDNA GPU chiplets and HBM in one coherent processor.

Seven changes explain most of the decade:

- **Naples to Rome:** moving the memory controllers from four complete CPU dies into a central I/O die made it possible to scale compute chiplets while retaining a coherent server platform.
- **Rome to Milan and Milan-X:** enlarging the local cache-sharing domain and then stacking more cache improved data access without increasing the maximum core count or external memory channels.
- **Genoa, Bergamo and Siena:** AMD began offering distinct balances of frequency, core density, cache, memory channels and platform cost within one architectural generation.
- **MI100 to MI300:** dedicated matrix execution, multiple GPU dies and heterogeneous 3D integration changed both compute throughput and the software-visible organization of memory.
- **MI350 to MI400/Helios:** numerical formats, data movement and communication across many accelerators became central product features. The rack joined the package as a principal unit of design.
- **Capri to Salina, and Pollara to Vulcano:** programmable network processing expanded from cloud infrastructure services into GPU communication and AI memory movement. DPUs and AI NICs address different parts of the system.
- **Xilinx to the broader AMD portfolio:** FPGA fabric, Versal AI Engines, Alveo cards and embedded modules added adaptable data paths, specialized inference and edge processing alongside the CPU/GPU families.

Pensando adds a complementary engineering approach: execute packet and protocol operations in a programmable data path, with general-purpose processors and dedicated engines supporting infrastructure services. The Xilinx-derived portfolio adds another form of programmability: hardware data paths and, in selected devices, arrays of AI Engines. These are distinct architectures within one infrastructure portfolio.

The conference record is especially valuable because each venue answers a different question. Hot Chips explains the machine's organization. ISSCC explains how the organization becomes physical silicon. Product papers at ISCA explain design choices and their history. MICRO, HPCA and ASPLOS reveal the interconnect, memory, translation and software problems that determine whether nominal hardware resources become useful performance. For networking, NSDI adds the operational evidence: where services run, how their state is maintained, and how the design behaves in a cloud deployment.

# 1. EPYC products and technology evolution

## 1.1 The product sequence

| Product family | Introduction | Core architecture and maximum cores | Principal change |
|---|---|---|---|
| EPYC 7001, Naples | 2017 | Zen; 32 | Four reusable Zeppelin SoCs in one server package |
| EPYC 7002, Rome | 2019 | Zen 2; 64 | Up to eight compute chiplets around a central I/O die |
| EPYC 7003, Milan | 2021 | Zen 3; 64 | Eight cores share one 32 MB L3 within each compute chiplet |
| EPYC 7003X, Milan-X | 2022 | Zen 3; 64 | 3D V-Cache raises maximum package L3 to 768 MB |
| EPYC 9004, Genoa | 2022 | Zen 4; 96 | SP5, DDR5, PCIe 5.0, CXL and AVX-512 |
| EPYC 9004X, Genoa-X | 2023 | Zen 4; 96 | Up to 1,152 MB L3 for technical computing |
| EPYC 97x4, Bergamo | 2023 | Zen 4c; 128 | Denser cores and cache organization for cloud throughput |
| EPYC 8004, Siena | 2023 | Zen 4c; 64 | Smaller SP6 platform for edge, telco and constrained servers |
| EPYC 9005, Turin | 2024 | Zen 5; 128, or Zen 5c; 192 | Wider execution, denser compute options and faster DDR5 |
| EPYC 4004 / 4005 | 2024 / 2025 | Zen 4 / Zen 5; up to 16 | AM5 entry server branch with close desktop ancestry |
| EPYC 8005, Sorano | 2026 | Zen 5; 84 | SP6 edge and telco branch with six DDR5-6400 channels |
| EPYC 9006, Venice | 2026 | Zen 6 / Zen 6c; up to 256 | New SP7/SP8 portfolio; flagship SP7 adds 16 memory channels and PCIe 6.0 |

The main server lineage is Naples → Rome → Milan → Genoa → Turin → Venice. X variants, dense-core variants and smaller-platform variants are branches of that lineage. The numbering does not imply that every product with a later launch date introduces a new CPU core.

## 1.2 Naples: EPYC 7001, 2017

Naples brought AMD back into mainstream high-performance x86 servers with up to 32 cores, eight DDR4 channels and 128 PCIe 3.0 lanes. The package contained four 14 nm Zeppelin dies. Each die was a complete SoC with eight Zen cores, memory controllers, I/O and Infinity Fabric connectivity.

This was a product-family strategy from the beginning. Zeppelin could serve desktop Ryzen, high-end desktop Threadripper and EPYC by changing how many dies were packaged and how their interfaces were configured. Sharing a substantial silicon building block spread development cost across markets and avoided making a single very large server-only die.

The cost of this reuse appeared in the memory topology. Each die owned two memory channels. A core accessing another die's memory crossed the on-package fabric, so one socket contained meaningful locality boundaries. Operating-system placement, memory allocation and thread affinity mattered even before a workload crossed into a second socket. Naples should therefore be understood as a coherent multi-die server, rather than a monolithic 32-core processor with eight equally local channels.

The Zeppelin ISSCC presentation makes the difference concrete: in its illustrated configuration, local memory access was approximately 90 ns, another die's memory within the socket approximately 145 ns, and a single-hop access to the other socket approximately 200 ns. These are measurements for that configuration, but they expose the architectural cost of crossing each boundary.

Within a Zeppelin die, two four-core complexes each shared an 8 MB L3. The local cache-sharing unit was therefore smaller than the eight-core die. Distinguishing the core complex, die and socket is essential to understanding the changes that followed.

**What the conferences add.** Michael Clark's Zen presentation at Hot Chips 2016 introduced the core architecture. Kevin Lepak's EPYC presentation at Hot Chips 2017 explained the enterprise package and system organization. ISSCC 2017 covered the Zen implementation; ISSCC 2018's Zeppelin paper explained how one SoC supported several markets. Together, these sources show that scalability was designed into the die's interfaces and physical implementation, not added only at the packaging stage.

The important inheritance was the combination of a reusable core complex, coherent die-to-die links and a product strategy built around multiple dies. Rome retained that method while changing what belonged on each die.

## 1.3 Rome: EPYC 7002, 2019

Rome doubled the maximum core count to 64 and made the decisive architectural separation between compute and infrastructure. Up to eight 7 nm core complex dies, or CCDs, connected to a central 14 nm I/O die. The I/O die contained the memory controllers and external interfaces. The platform retained eight memory channels, advanced to DDR4-3200 and PCIe 4.0, and continued on the SP3 socket family.

Each eight-core CCD still contained two four-core complexes. Each complex now had 16 MB L3, giving a full CCD 32 MB and a fully populated 64-core package 256 MB. A large package-level cache total did not mean that every core had one equally local 256 MB cache.

Separating the I/O die solved several problems together. The new process could be devoted to replicated CPU logic. Memory and external I/O no longer had to be reproduced inside every compute die. AMD could vary the number of CCDs without changing the basic memory-controller organization. The desktop Ryzen 3000 family reused the Zen 2 compute-chiplet approach with a different I/O die and fewer chiplets.

Centralizing memory access made Rome's topology more regular than Naples, but did not eliminate locality. A load still traversed a CCD-to-I/O connection, and the I/O die had internal organization. NUMA Nodes Per Socket, or NPS, settings and workload placement remained relevant. Independent memory characterization at ISPASS subsequently measured the practical consequences of this hierarchy.

**What the conferences add.** Hot Chips 2019's Zen 2 disclosure supplies the core changes, including a larger micro-op cache and wider floating-point execution than the original Zen design. ISSCC 2020 presented both the Zen 2 core and the server/desktop chiplet architecture. ISCA 2021's industrial product paper, *Pioneering Chiplet Technology and Design for the AMD EPYC and Ryzen Processor Families*, explains the manufacturing and reuse rationale across Naples and Rome.

The combined lesson is that Rome's scaling was not simply the result of smaller transistors. It depended on choosing a new boundary between compute, memory control and I/O, then making that boundary economical through package and interconnect design.

## 1.4 Milan and Milan-X: EPYC 7003, 2021–2022

Milan retained the broad Rome platform: up to 64 cores, eight DDR4 channels, PCIe 4.0 and separate compute and I/O dies. Its defining change was inside the CCD. Zen 3 replaced the two four-core complexes with one eight-core complex sharing 32 MB L3.

This enlarged the domain in which threads could share data through the local L3. It also doubled the directly accessible L3 capacity for a core relative to a Zen 2 four-core complex, while leaving the maximum package L3 at 256 MB. The distinction explains why applications could improve substantially even though the headline core count and total cache capacity stayed unchanged.

Zen 3 also expanded execution resources and improved branch prediction and load/store throughput. Hot Chips 2021 explains those architectural changes. ISSCC 2022 connects them to an eight-slice L3 implementation using a bidirectional ring, denser SRAM choices, physical-design work and power management. This is a useful example of implementation enabling architecture: a larger sharing domain needs a practical interconnect, not just more cache bits.

Milan-X added a 64 MB SRAM die above each CCD's existing 32 MB L3. A fully populated package therefore provided 96 MB per CCD and 768 MB total L3. The added cache was part of the CPU's cache hierarchy; software did not manage it as a separate memory device.

The ISSCC 2022 3D V-Cache paper describes hybrid bonding and the high-bandwidth vertical interface. The base CCD was designed to support stacking, with cache control retained on the base die and the stacked die optimized for storage density. Hot Chips 2021's packaging tutorial places that implementation in AMD's broader integration strategy. Computex 2021 had already demonstrated the technology on a Ryzen prototype, linking the server product to the later Ryzen 7 5800X3D.

The implementation paper reports a 41 mm², 7 nm cache die, a 9 micrometre minimum TSV pitch and more than 2 TB/s of L3 bandwidth. It also reports a four-cycle latency increment. The engineering trade is therefore explicit: much more local capacity through a dense vertical interface, with an access-latency cost, rather than a free enlargement of the original cache.

The benefit is strongest when additional L3 captures a workload's reused data and avoids more expensive memory accesses. This is why engineering simulation and other technical-computing workloads were central to Milan-X's positioning. Additional cache cannot substitute for DRAM bandwidth when a workload mostly streams through data with little reuse.

Milan also introduced SEV-SNP in AMD's confidential-computing progression. Memory protection, virtualization support and platform compatibility are part of the server generation even though they are less visible in core-count comparisons.

## 1.5 Genoa: EPYC 9004, 2022

Genoa was a new platform as well as a new core. It increased the maximum to 96 Zen 4 cores across twelve eight-core CCDs, used 5 nm compute dies with a 6 nm I/O die, and moved to SP5. Twelve DDR5 channels replaced eight DDR4 channels. PCIe 5.0 and CXL extended the platform's connectivity.

The memory change is particularly significant. At the nominal maximum rates used here, eight DDR4-3200 channels provide 204.8 GB/s of theoretical payload bandwidth, while twelve DDR5-4800 channels provide 460.8 GB/s. The bandwidth increase exceeded the increase from 64 to 96 cores, improving the platform's nominal bandwidth per core.

Zen 4 kept the eight-core, 32 MB L3 complex and doubled private L2 from 512 KB to 1 MB per core. It added AVX-512 instructions using 256-bit execution resources. Software gained the instruction set, but an AVX-512 operation did not imply that every relevant execution datapath was physically 512 bits wide. Turin would change that implementation balance again.

Hot Chips 2023 brings the core and EPYC 9004 platform together. ISSCC 2023's Zen 4 paper supplies the circuit and physical-design view. Its high-frequency result belongs to the demonstrated core implementation and client operating points; it should not be read as a 96-core server's all-core frequency. This is a recurring reason to combine conference disclosures with final product specifications.

Genoa's desktop relative is Ryzen 7000. The common Zen 4 foundation makes client papers useful for understanding the core, but server memory channels, I/O, package power and chiplet count must be taken from EPYC-specific material.

## 1.6 Genoa-X, Bergamo and Siena: three different optimizations, 2023

**Genoa-X** extended the V-Cache approach to Zen 4. Twelve CCDs with 96 MB L3 each yielded up to 1,152 MB of package L3. Its purpose was to increase the amount of reusable working data retained near the cores while preserving the SP5 platform. Like Milan-X, it is best understood through the interaction of workload locality, cache capacity and memory traffic.

**Bergamo** optimized for cloud throughput and density. It used Zen 4c cores and reached 128 cores with eight sixteen-core CCDs. A Bergamo CCD contained two eight-core complexes with 16 MB L3 each. Thus, its 128-core package had 256 MB L3, compared with Genoa's 384 MB at 96 cores.

Zen 4c preserved the Zen 4 instruction-set and software foundation while optimizing the implementation for area and a different frequency/power range. ISSCC 2024 explains this distinction at the physical-design level. Dense cores are not simply ordinary cores placed closer together, nor should the shared ISA be interpreted as identical performance under every workload. Cache capacity, clock frequency, memory contention and placement all influence the resulting behavior.

**Siena**, sold as EPYC 8004, brought Zen 4c to a smaller single-socket SP6 platform with up to 64 cores, six DDR5 channels and 96 PCIe 5.0 lanes. It targeted edge, telecommunications and deployments constrained by power, physical size or platform cost. Reducing the surrounding platform was as important as changing the core implementation.

AMD's June 2023 Data Center and AI Technology Premiere introduced Bergamo and Genoa-X; Siena followed in September. Hot Chips 2023 supplies the architectural framework for understanding this family. MWC presentations then show why Siena's attributes matter in telecommunications systems.

These products mark a change in how to read the EPYC roadmap: the question becomes which balance of resources fits the workload. Maximum core count, maximum cache capacity and the smallest practical system are three different objectives.

## 1.7 Turin: EPYC 9005, 2024

Turin extended SP5 with two major compute options: up to 128 Zen 5 cores using sixteen eight-core CCDs, or up to 192 Zen 5c cores using twelve sixteen-core CCDs. The mainstream Zen 5 implementation uses 4 nm compute technology; the dense implementation uses 3 nm. Both connect to the server I/O infrastructure and support twelve DDR5 channels, now at rates up to DDR5-6000.

The maximum cache organizations differ. An eight-core Zen 5 CCD has 32 MB L3, yielding 512 MB across sixteen CCDs. The sixteen-core Zen 5c CCD also has 32 MB L3, yielding 384 MB across twelve CCDs. Unlike Bergamo's two-complex CCD, the EPYC 9005 architecture overview describes one complex per CCD for both Turin variants. This changes the local sharing domain and is an important detail that core-count summaries omit.

Hot Chips 2024 describes Zen 5's expanded front end, execution resources and memory subsystem. The 48 KB L1 data cache, larger execution capacity and increased data bandwidth support more work per core. In the server implementation, full-width 512-bit floating-point execution strengthens vector capability. The ISSCC 2025 paper complements this with the 4 nm core-complex implementation and explains why configurations across product segments need to be distinguished.

The EPYC-specific architecture guide adds a less prominent but valuable detail: selected “wide” products connect each CCD to two GMI links rather than one, increasing the bandwidth between the compute chiplet and I/O die. Package DRAM bandwidth alone therefore does not fully describe the resources available to a particular core population.

Turin launched at Advancing AI in October 2024. Google Cloud Next 2025 connected the generation to C4D and H4D virtual machines. Those cloud disclosures add workload and deployment context; the core and package organization still come from Hot Chips, ISSCC and the EPYC technical documents.

At maximum dense-core count, memory remains a key balance: 576 GB/s of nominal DDR5 bandwidth divided among 192 cores is 3.0 GB/s per core. The same memory interface divided among 128 cores is 4.5 GB/s per core. The dense version can deliver more aggregate work when the workload supports that tradeoff, but more cores do not guarantee proportionally more memory throughput.

## 1.8 Venice: EPYC 9006, 2026

By the report cutoff, Venice had moved beyond roadmap previews. AMD launched the sixth-generation EPYC portfolio at Advancing AI on 23 July 2026 and published EPYC 9006 product specifications. The family uses Zen 6 and Zen 6c and expands into SP7 and SP8 platforms.

The flagship EPYC 9996 specification provides a concrete reference point: 256 cores, 512 threads, 1,024 MB L3, sixteen memory channels and PCIe 6.0 x96 on SP7. AMD lists DDR5 RDIMM rates up to 8,000 MT/s and MRDIMM rates up to 12,800 MT/s, corresponding to approximately 1.024 TB/s and 1.638 TB/s per socket. Its stated default CPU power is 600 W with a 400–600 W range.

The platform change matters more than the core-count increment alone. Relative to SP5, the flagship adds memory channels and a new I/O generation. AMD's Taiwan ecosystem announcement also identifies 2.5D Elevated Fanout Bridge packaging for Venice, extending advanced-package methods into this CPU generation.

AMD presents SP8 for enterprise and general-purpose systems, alongside SP7's larger platform. Its portfolio page also identifies 9006X and an AI-host-oriented 9006 LP branch. Detailed availability and specifications should be read by individual product rather than assumed to be identical across the entire family.

Venice also serves a system role in Helios, whose announced configuration combines eighteen EPYC CPUs with seventy-two Instinct MI455X GPUs. The CPU is responsible for host-side execution and data movement in a much larger accelerator system.

The 2026 public sources reviewed here provide a firmer basis for describing the platform than for reconstructing every Zen 6 internal structure. The Hot Chips 2026 program contains AMD's MI400 architecture and system talks, but does not establish an equivalent Zen 6 CPU disclosure. This report therefore does not assign unverified pipeline or cache-topology details to Venice.

## 1.9 Smaller servers, edge systems and a custom HBM branch

EPYC 4004 and 4005 extend the server brand into AM5 systems with up to sixteen cores. The former uses Zen 4 and the latter Zen 5. Their close relationship to the desktop platform is useful for understanding their economics and core technology, while server validation and the intended deployment distinguish the products. They do not offer the memory-channel and I/O scale of SP5 EPYC.

EPYC 8005, introduced in 2026 and codenamed Sorano in AMD's architecture guide, advances the SP6 branch to up to 84 Zen 5 cores. AMD specifies six DDR5-6400 channels, 96 PCIe 5.0 lanes and a 70–225 W product range. Its deployment focus includes telecommunications, edge services and storage. This is a continuation of platform specialization, rather than a replacement for the larger EPYC line.

A particularly instructive branch is the custom EPYC implementation behind Microsoft's Azure HBv5. The SCA/HPCAsia 2026 paper describes CPU and cloud co-design for memory-bandwidth-bound HPC, using HBM with a Genoa-based design. Microsoft's current VM documentation lists 368 usable CPU cores, 432 GB of memory and 6.7 TB/s of memory bandwidth for the largest HBv5 configuration. These are VM-level resources, not specifications for a retail single-socket EPYC.

HBv5 demonstrates that the technology shared by EPYC and Instinct extends beyond CPU core IP: advanced packaging and HBM can also support a CPU-centric cloud system. Its architecture belongs in the EPYC story, but should not be conflated with MI300A or a generally available socketed Genoa SKU.

## 1.10 What changed in memory bandwidth per core?

The following arithmetic isolates one resource balance. It uses nominal maximum memory rates, fully populated channels and the representative maximum core counts shown. Bandwidth is theoretical payload bandwidth before protocol, access-pattern and software effects; these are not benchmark results.

| Configuration | Channels and data rate | Calculated GB/s per socket | Cores | Calculated GB/s per core |
|---|---|---:|---:|---:|
| Naples | 8 × DDR4-2667 | 170.7 | 32 | 5.33 |
| Rome / Milan | 8 × DDR4-3200 | 204.8 | 64 | 3.20 |
| Genoa | 12 × DDR5-4800 | 460.8 | 96 | 4.80 |
| Bergamo | 12 × DDR5-4800 | 460.8 | 128 | 3.60 |
| Siena | 6 × DDR5-4800 | 230.4 | 64 | 3.60 |
| Turin, Zen 5 | 12 × DDR5-6000 | 576.0 | 128 | 4.50 |
| Turin, Zen 5c | 12 × DDR5-6000 | 576.0 | 192 | 3.00 |
| Sorano | 6 × DDR5-6400 | 307.2 | 84 | 3.66 |
| Venice 9996, RDIMM | 16 × DDR5-8000 | 1,024.0 | 256 | 4.00 |
| Venice 9996, MRDIMM | 16 × DDR5-12800 | 1,638.4 | 256 | 6.40 |

Calculation: channels × transfers per second × 8 payload bytes per channel. The table shows why cache-rich products, higher-bandwidth memory and fewer-core high-frequency products remain useful even as maximum core count rises. It also shows why a simple ranking by cores misses much of the engineering story.

## 1.11 Cache-sharing domains across EPYC generations

| Product | Full compute-die organization | L3 within one sharing domain | Maximum package L3 |
|---|---|---|---:|
| Naples | 2 complexes × 4 cores per Zeppelin SoC | 8 MB / 4 cores | 64 MB |
| Rome | 2 complexes × 4 cores per CCD | 16 MB / 4 cores | 256 MB |
| Milan | 1 complex × 8 cores per CCD | 32 MB / 8 cores | 256 MB |
| Milan-X | 1 complex × 8 cores, with stacked cache | 96 MB / 8 cores | 768 MB |
| Genoa | 1 complex × 8 cores per CCD | 32 MB / 8 cores | 384 MB |
| Genoa-X | 1 complex × 8 cores, with stacked cache | 96 MB / 8 cores | 1,152 MB |
| Bergamo | 2 complexes × 8 cores per CCD | 16 MB / 8 cores | 256 MB |
| Turin, Zen 5 | 1 complex × 8 cores per CCD | 32 MB / 8 cores | 512 MB |
| Turin, Zen 5c | 1 complex × 16 cores per CCD | 32 MB / 16 cores | 384 MB |

The table describes full architectural complexes; individual SKUs may disable cores or populate fewer chiplets. Package cache totals are sums of distributed L3 resources. The progression is not monotonic in cache per core: the cloud-density branches intentionally make different choices. Milan and Turin Zen 5c also show why the number of cores sharing one L3 must be tracked independently from the total cores on a die.

# 2. Instinct products and technology evolution

## 2.1 The product sequence

| Product | Introduction | Architecture | Representative memory | Principal change |
|---|---|---|---|---|
| Radeon Instinct MI6 / MI8 / MI25 | Announced 2016; 2017 generation | Polaris / Fiji / Vega | 16 GB GDDR5 / 4 GB HBM / 16 GB HBM2 | Compute portfolio assembled from graphics-derived architectures |
| Radeon Instinct MI50 / MI60 | 2018 | Vega 20 | MI60: 32 GB HBM2, about 1 TB/s | 7 nm, stronger FP64 and GPU-to-GPU fabric |
| Instinct MI100 | 2020 | CDNA | 32 GB HBM2, 1.23 TB/s | Dedicated compute architecture and matrix execution |
| Instinct MI250 / MI250X | 2021 | CDNA 2 | 128 GB HBM2e, 3.2 TB/s per package | Two GPU compute dies and exascale node integration |
| Instinct MI210 | 2022 | CDNA 2 | 64 GB HBM2e, 1.6 TB/s | Single-die PCIe branch |
| Instinct MI300A | 2023 | Zen 4 + CDNA 3 | 128 GB shared HBM3, 5.3 TB/s | CPU and GPU chiplets share coherent physical memory |
| Instinct MI300X | 2023 | CDNA 3 | 192 GB HBM3, 5.3 TB/s | Eight stacked GPU compute chiplets, optimized for accelerator systems |
| Instinct MI325X | 2024 | CDNA 3 | 256 GB HBM3e, 6.0 TB/s | Memory-capacity and bandwidth refresh |
| Instinct MI350X / MI355X | 2025 | CDNA 4 | 288 GB HBM3e, 8.0 TB/s | Stronger matrix engines, low-precision formats and revised I/O partitioning |
| Instinct MI350P | 2026 | CDNA 4 | 144 GB HBM3e, 4.0 TB/s | PCIe card for conventional server infrastructure |
| Instinct MI455X, MI400 family | 2026 | CDNA 5 | 432 GB HBM4, 23.3 TB/s | New execution organization and rack-scale Helios integration |

Memory bandwidth is per accelerator package or card. MI250X contains two software-visible GPU devices, so its package totals should not be confused with the resources visible to one device. Published memory capacities follow AMD's product naming convention.

## 2.2 The prelude and first Radeon Instinct generation, 2015–2017

The first Radeon Instinct portfolio was announced in December 2016. MI6, MI8 and MI25 drew on Polaris, Fiji and Vega respectively. The product name united devices with materially different memory systems: GDDR5 for MI6, first-generation HBM for MI8 and HBM2 for MI25.

Fiji's earlier use of HBM is important background. Placing wide memory interfaces beside a GPU in an advanced package established a practical route to high bandwidth without relying solely on ever-faster external DRAM interfaces. This packaging and memory lineage continued into Instinct even as the compute architecture changed.

MI25's Vega architecture remains closely connected to Radeon Vega graphics. Hot Chips 2017's Vega presentation explains the programmable compute organization, packed arithmetic and memory-system ideas behind that generation. The server product additionally depended on accelerator packaging, cooling, reliability and software.

At this stage, the story is one of adapting a broad GPU architecture to compute markets. It should not be retroactively described as CDNA. AMD's ROCm software effort was also becoming an essential part of the platform: an accelerator's usefulness depended on compiler, runtime and library support as well as peak arithmetic rates.

## 2.3 MI50 and MI60: Vega 20, 2018

MI50 and MI60 arrived at AMD's Next Horizon event in November 2018. Vega 20 moved the compute product to 7 nm and strengthened the HPC proposition through high-rate FP64 arithmetic, HBM2 bandwidth around 1 TB/s, PCIe 4.0 and direct GPU-to-GPU Infinity Fabric connectivity. MI60 provided 32 GB of HBM2; MI50 existed in more than one memory-capacity configuration.

The important change was broader than process scaling. Scientific workloads needed double-precision arithmetic and reliable movement of large data sets, while multi-accelerator applications needed communication paths that avoided unnecessary host-mediated transfers. MI50/MI60 addressed those requirements while retaining Vega ancestry.

Radeon VII used related Vega 20 technology in a desktop product. That connection is useful for tracing silicon reuse, but the compute products' validated capabilities and server configuration should be taken from Instinct documentation.

Next Horizon is a particularly informative industry event in this history: it combined the 7 nm GPU announcement with Rome's server direction. Both product lines were beginning to turn leading-edge process technology and fabric connectivity into data-center platforms.

## 2.4 MI100: the first CDNA generation, 2020

MI100 established CDNA as AMD's dedicated data-center compute architecture. It combined 120 compute units with 32 GB of HBM2 and approximately 1.23 TB/s memory bandwidth. Its matrix instructions and execution resources made matrix multiplication a first-class architectural function rather than relying solely on conventional vector instructions.

The separation from RDNA is central. RDNA developed around graphics and gaming priorities; CDNA developed around compute, matrix arithmetic, scientific precision and scaling. Both are GPU architectures, but conclusions about execution width, caches or instruction behavior cannot be transferred from one to the other simply because both carry AMD branding.

The CDNA white paper explains the compute-unit and matrix organization. AMD's November 2020 announcements, aligned with the HPC community's SC season, place MI100 in an EPYC-based system and software context. The generation retained a large single GPU compute die, so it is the last major Instinct step before compute itself was split across dies.

For historical comparisons, MI100 is a useful starting point for the dedicated compute lineage. It is less useful to compare its peak FP64 number directly with a later generation's FP8 or FP4 headline: those measure different arithmetic and often different execution paths.

## 2.5 MI200: CDNA 2, MI250/MI250X and MI210, 2021–2022

MI250 and MI250X moved Instinct to a two-die GPU package. MI250X combined two 6 nm graphics compute dies, or GCDs, with eight HBM2e stacks, 128 GB total memory and 3.2 TB/s aggregate memory bandwidth. The package had 220 active compute units. MI210 brought CDNA 2 to a single-die PCIe card with 64 GB and 1.6 TB/s.

A crucial software detail is that MI250X's two GCDs are exposed as two GPU devices. One physical accelerator module is therefore not automatically one flat GPU programming domain. Work assignment and communication between the two devices remain part of application design.

CDNA 2 strengthened matrix computation, including high-precision work relevant to HPC, and developed coherent CPU/GPU connectivity. Coherence and unified addressing, however, do not make host DDR memory and GPU HBM one physical memory pool. Their location, bandwidth and capacity remain distinct.

Hot Chips 2022 is the key architectural disclosure because it discusses both the MI200 accelerator and node organizations. Frontier's node combines one custom EPYC CPU with four MI250X modules, yielding eight GPU devices. The topology, including accelerator and network connections, is part of how the machine sustains useful scaling.

The VLSI 2023 paper on MI250X's Elevated Fanout Bridge packaging supplies an implementation complement. It explains the packaging technology that allows the two large compute dies and their HBM resources to form a practical accelerator. ISCA 2023's exascale retrospective then explains the path from research alternatives to the delivered Frontier architecture.

Reading these together avoids an incomplete interpretation of Frontier as merely a collection of fast GPUs. CPU/GPU interaction, memory access, node networking, power and application co-design all shaped the final system. Frontier also provided a major software and operational proving ground before the more integrated MI300A design.

## 2.6 MI300A: a CPU–GPU processor with shared HBM, 2023

MI300A combines twenty-four Zen 4 CPU cores with CDNA 3 GPU compute and 128 GB of HBM3 in one package. Its compute layer contains three CPU CCDs and six accelerator complex dies, or XCDs, over four I/O dies. The CPU and GPU share a coherent physical HBM memory system with approximately 5.3 TB/s aggregate bandwidth.

That physical integration changes the programming problem. A CPU phase and GPU phase can operate on shared data without requiring the same explicit host-DRAM-to-device-HBM copy pattern as a conventional discrete accelerator. Synchronization and efficient data access still matter; shared memory is a capability, not an automatic performance guarantee.

The design draws directly on both EPYC and Instinct. The Zen 4 CCDs adapt the CPU chiplet for stacked integration, while the GPU XCDs are designed for the vertical interface. ISCA 2024 explains how AMD accommodated the different chiplet footprints and interfaces on a reusable I/O-die design. It also explains the engineering history: earlier exascale APU concepts were constrained by packaging, manufacturing and thermal practicality, while MI300A could draw on more mature integration techniques.

ISSCC 2024's MI300 package paper supplies the implementation view. The package combines leading-edge compute, infrastructure dies and HBM rather than building everything as one enormous logic die. The same general assembly strategy can support different mixtures of CPU and GPU compute.

El Capitan turns that architectural idea into a system. LLNL documents four MI300A APUs per compute node, giving ninety-six CPU cores and 512 GB of shared-package memory across the node. SC24 marked the system's major public performance milestone. This deployment provides context for why MI300A was designed as a heterogeneous HPC processor, even while the wider MI300 family also pursued AI.

The deepest academic reading sequence for this product is HPCA 2017's exascale APU proposal, ISCA 2023's Frontier retrospective and ISCA 2024's account of realizing the heterogeneous processor. The sequence explains both the continuity of the idea and the changes required to make a commercial implementation possible.

## 2.7 MI300X: CDNA 3 for large accelerator systems, 2023

MI300X uses the MI300 integration platform for a different balance: eight GPU XCDs, four I/O dies and eight HBM3 stacks provide 304 active compute units, 192 GB of memory and approximately 5.3 TB/s bandwidth. The CPU remains external to the accelerator.

This is the key distinction from MI300A. Both products use closely related packaging and compute technology, but only MI300A integrates Zen CPU cores into the shared-HBM processor. MI300X's large HBM does not, by itself, turn the host CPU's memory into a single physical pool with the accelerator.

Hot Chips 2024 explains MI300X at the package and platform levels. In its eight-accelerator baseboard, each GPU has direct connections to the other seven. The presentation's aggregate 896 GB/s per-GPU interconnect figure is bidirectional. It must not be compared without adjustment to a one-direction bandwidth number from another system.

MI300 also changes the relationship between physical chiplets and logical devices. The GPU can be presented as one large device across multiple XCDs, while supported partitioning modes divide resources for other deployment needs. Compute partitioning and memory partitioning are related but distinct configuration choices.

The combination of ISSCC 2024, ISCA 2024 and Hot Chips 2024 provides an unusually complete picture: physical construction, the rationale for the heterogeneous platform, and the organization of the AI-oriented accelerator and baseboard. The later IEEE Micro article on MI300X interconnect design adds detail; it is a journal article, not a paper at the MICRO conference.

MI300X launched at Advancing AI in December 2023. Microsoft Ignite 2023 had announced Azure's preview direction; Microsoft Build 2024 subsequently supplied a deployment and availability milestone for Azure's MI300X virtual machines and services.

## 2.8 MI325X: more memory within CDNA 3, 2024

MI325X retained CDNA 3 while moving to 256 GB of HBM3e and 6 TB/s memory bandwidth. It is a memory and platform refresh rather than a new CDNA generation.

The capacity increase matters to AI serving and training because model weights, runtime state, activations and attention caches compete for HBM. A larger per-GPU memory budget can change how a model is partitioned or how much concurrency fits on a device. The effect depends on the model and execution software, rather than following directly from capacity alone.

AMD previewed MI325X at Computex 2024 and launched it at Advancing AI in October. The final product specification is the appropriate comparison point: the early roadmap figure of 288 GB was superseded by the launched 256 GB configuration.

## 2.9 MI350X and MI355X: CDNA 4, 2025

CDNA 4 substantially reworked the compute and infrastructure balance. MI350-series accelerators use eight 3 nm XCDs above two 6 nm I/O dies, compared with MI300's four I/O dies. Keeping infrastructure on a different process remained part of the strategy, but the infrastructure partition itself changed.

The compute units became more capable while the active count fell to 256 across the package. This is a useful warning against treating CU count as a stable measure of work across architectures. Matrix resources, instruction support, clocking and feeding the execution machinery matter more than the count alone.

CDNA 4 adds low-precision microscaling formats, including MXFP4 and MXFP6, alongside established AI and scientific formats. These formats trade numerical representation against throughput and data movement. They can benefit appropriate AI workloads, but an FP4 rate is not a replacement for an FP64 scientific-computing metric.

Both MI350X and MI355X provide 288 GB HBM3e and 8 TB/s memory bandwidth. AMD positions MI350X as a 1,000 W air-cooled option in an eight-GPU baseboard ecosystem, while MI355X uses direct liquid cooling at a 1,400 W rating. Power delivery and cooling are therefore explicit product choices.

Advancing AI 2025 introduced the products and software direction. Hot Chips 2025's CDNA 4 presentation explains the architecture and platforms. ISSCC 2026 follows with the implementation paper on stacked 3 nm XCDs and 6 nm I/O dies. The year difference is normal: a product launch, architecture presentation and circuit paper need not occur in the same calendar year.

MI350P extends CDNA 4 into a PCIe card in 2026, with 144 GB HBM3e and 4 TB/s. It uses four XCDs, one I/O die and four HBM stacks, with 128 active CUs. It addresses installations that need an accelerator within conventional server infrastructure rather than the highest-power multi-GPU module platform.

## 2.10 MI400 and MI455X: CDNA 5 and Helios, 2026

AMD's July 2026 Advancing AI event introduced MI400 and Helios as launched products. The public specifications identify MI455X as the first CDNA 5 product, with 432 GB HBM4 across twelve stacks and up to 23.3 TB/s memory bandwidth.

The architectural change goes beyond replacing HBM3e with HBM4. AMD describes eight XCDs with 256 work-group processors, or WGPs, and Wave32 execution. It also separates fabric/cache dies from I/O dies: two fabric/cache dies provide the HBM interface and 192 MB global L2, while two I/O dies handle external connectivity. This differs from the MI300 and MI350 infrastructure partitioning.

The published CDNA 5 description also introduces mechanisms aimed at moving data and coordinating work more efficiently, including asynchronous transfers into local data share and cooperation across WGPs. These changes make the programming and scheduling organization as important as the arithmetic peak.

Hot Chips 2026 includes separate talks on MI400's GPU architecture and its system architecture. That pairing reflects the product's scope. Helios combines seventy-two MI455X GPUs and eighteen Venice CPUs, with scale-up communication using UALink over Ethernet and separate scale-out networking. AMD specifies approximately 31 TB of aggregate HBM across the rack. That aggregate capacity remains distributed across accelerators and should not be read as one uniformly accessible local memory.

The rack product also brings power delivery, liquid cooling, serviceability, networking and software into the architectural discussion. OCP 2025 exposed the open-rack design direction before the 2026 launch, connecting AMD's GPU roadmap to Meta's rack-design ecosystem.

MI430X is an announced HPC/sovereign-AI branch with release planned for 2027, and MI500 is a future roadmap generation. Their existence reinforces the need to distinguish family branding from identical enabled features and availability. They are not included as completed product generations in the comparisons here.

# 3. Pensando DPU products and technology evolution

## 3.1 The product sequence and its place in AMD

AMD completed its acquisition of Pensando on 26 May 2022. Capri and Elba therefore began as Pensando designs before becoming part of AMD's portfolio. Their history belongs in this report because it establishes the architecture that AMD subsequently extended through Giglio and Salina.

A Pensando **data processing unit** executes infrastructure services: virtual networking, connection tracking, security, storage protocols and telemetry. A distributed services card, or DSC, is a board containing the DPU and its supporting components. The silicon generation, card bandwidth and software service are different levels of the product.

| DPU generation | Disclosure and product period | Processing and memory | Interfaces and architectural change |
|---|---|---|---|
| Capri, first generation | First silicon in 2018; detailed at Hot Chips 2020 | 16 nm; 112 MPUs; four Cortex-A72 cores; 4–8 GB HBM | Up to 2 × 100 Gb/s; PCIe 4.0 ×16; establishes the programmable services architecture |
| Elba, second generation | First silicon in 2020; deployed commercially by 2022 | 7 nm; 144 MPUs; sixteen Cortex-A72 cores; dual DDR4-3200 interfaces | Up to 2 × 200 Gb/s; 32 PCIe 4.0 lanes; larger service state and host connectivity |
| Giglio, second generation plus | Announced in 2023; detailed product brief in 2024 | Elba-compatible architecture; 144 MPUs; sixteen Cortex-A72 cores; dual DDR5-5600 interfaces | Up to 2 × 200 Gb/s; 16 PCIe 4.0 lanes; optimized power/performance and memory subsystem |
| Salina, third generation | Announced at Advancing AI 2024; 2025–2026 platform generation | 5 nm; programmable P4 services; published card configuration has 64 GB DDR5-6400 with ECC | Up to 2 × 400 Gb/s; PCIe 5.0 ×16 for a single host; AI front-end and storage-service expansion |

The dates distinguish first silicon from later product documentation. The interface figures describe published chip or card capabilities; they do not imply that every board exposes every lane or that all traffic traverses the host interface. In particular, network-to-network processing can operate independently of host PCIe throughput.

## 3.2 Capri: establishing a programmable services processor

Capri's notable implementation choice was to combine a 16 nm packet processor with HBM in a 2.5D assembly. Its on-package memory served packet-processing state and services rather than the large numerical arrays associated with Instinct. The Hot Chips 2020 presentation disclosed Capri alongside its successor, making the memory-system change between the two unusually easy to follow.

The common architecture separates a packet-processing path from a supporting SoC. Parsers construct packet-header vectors; table lookups and match processing units apply actions; deparsers produce outgoing packets. A network-on-chip connects these pipelines with Arm cores, memory, PCIe and offload engines. This puts programmable packet work close to both the network and service state.

The central design objective is to keep common traffic processing in the fast path. General-purpose Arm cores provide software flexibility for control and exceptional cases; they are not the sole source of per-packet throughput. AMD's software description extends P4 beyond header rewriting to timers, asynchronous events, notifications and protocol state machines. That allows services such as connection handling and storage transport to exploit the programmable pipeline.

## 3.3 Elba: more state, more cores and a different memory balance

Elba moved the design to 7 nm and expanded the surrounding SoC. AMD's later product brief specifies 144 MPUs at 2 GHz, sixteen Cortex-A72 cores at 3 GHz, dual DDR4-3200 interfaces supporting 8–64 GB, and 32 PCIe 4.0 lanes. These are later published specifications, distinct from the earlier operating points in the 2020 conference slides.

The move from Capri's HBM to external DDR changes the balance between packaging, memory capacity and service-state storage. The architectural implication is that a DPU needs enough state for connections, mappings and queues, alongside sufficient lookup throughput. HBM is one way to address that problem, but its presence is not the defining property of a DPU.

Elba's dedicated engines accelerate cryptography, compression, checksums, deduplication and erasure coding. Source compatibility with Capri preserves investment in P4 services. PCIe root-complex and endpoint modes, lane partitioning and multihost support allow the same architecture to participate in server cards and network or storage appliances.

VMware's vSphere 8 announcement in August 2022 is an important productization milestone. Pensando DSCs supported the vSphere Distributed Services Engine approach, which moves infrastructure work away from the application's host CPU and separates infrastructure execution from tenant workloads. This is a systems benefit whose value depends on the complete software deployment, not merely DPU core count.

## 3.4 Giglio: an optimized branch rather than a new programming model

AMD describes Giglio as **second generation plus**. It retains the 144-MPU and sixteen-Cortex-A72 organization and source compatibility with Capri and Elba. Its published memory interface moves to DDR5-5600, while the PCIe interface has sixteen Gen4 lanes. It is therefore more accurate to describe Giglio as a revised balance of resources and efficiency than as a uniform doubling of Elba.

The product remains aimed at stateful networking, security and storage services, with deployments ranging from compact server cards to appliances and smart switches. Its significance is continuity: customers can retain the service model and much of the software while changing the implementation underneath it. This is the DPU counterpart to the platform continuity visible across several EPYC generations, although the silicon organizations are very different.

## 3.5 Salina: the AI front end becomes a first-class workload

Salina raises the published network configuration to two 400 Gb/s ports. The card brief specifies PCIe 5.0 ×16 for a single host, support for two-host configurations, and 64 GB DDR5-6400 with ECC. Its services include overlays, stateful security, telemetry, IPsec, storage virtualization and NVMe over TCP or RDMA. The progression is from general cloud infrastructure toward the front end of AI systems, where ingestion, tenant isolation and storage access compete with application work for host resources.

The word “front end” describes a role, not an absolute restriction on the silicon. Salina can implement multiple network and storage services; the architectural distinction is that it manages infrastructure around the accelerators. Pollara and Vulcano concentrate on moving data for accelerator communication.

AMD's 2026 networking disclosures extend Salina's role to DPU-managed NVMe storage for AI key-value cache. This adds a memory tier for retained inference state. It does not turn NVMe into HBM: the software must decide what to retain, place and fetch, and the storage/network path has different latency and bandwidth from local accelerator memory. The useful system question is how much expensive GPU memory can be reserved for active computation without making state retrieval the next bottleneck.

## 3.6 Software and deployment are part of the DPU architecture

Pensando's Software-in-Silicon Development Kit, or SSDK, combines a P4 compiler, Arm toolchain, simulator, libraries, drivers and reference pipelines. P4 targets the fast path; C and C++ target the Arm complex. The environment supports development on x86 systems before deployment to the DPU. Its scope includes data, control and management functions, not just packet filters.

AMD's Policy and Services Manager, or PSM, supplies centralized policy and management for full-stack deployments. Cloud providers can instead integrate their own controllers and service logic. These are alternative software arrangements around the same underlying processing capabilities.

Three deployment forms explain the breadth of the product line:

| Deployment form | Representative implementation | What changes in the system |
|---|---|---|
| Host-attached services | Pensando DSC; vSphere Distributed Services Engine integration | Infrastructure processing gains a separate execution and management location |
| Shared network-function pools | Microsoft and AMD Pensando's Sirius system, NSDI 2023 | Stateful functions can be provisioned independently of each tenant server |
| Services embedded in a switch | HPE Aruba Networking CX 10000; Cisco N9300 Smart Switches | Security and telemetry execute near the network path, with a switch ASIC still handling switching |

The NSDI 2023 paper *Disaggregating Stateful Network Functions* is the most direct academic systems companion to the DPU product history. Its Sirius design uses pools of P4-programmable cards, replicates state between paired devices and moves load across the pool. The paper identifies DSC-200 hardware with substantial external memory and integrated Arm cores. It explains how a DPU can support cloud services without requiring an identical services processor beside every application host.

HPE's CX 10000 and Cisco's N9300 show another boundary choice: integrate Pensando processing into the switch. Cisco's 2025 disclosure pairs its Silicon One E100 with AMD Pensando DPUs. These are partner switch products containing AMD technology; their switching capacity should not be attributed to a standalone AMD switch ASIC.

# 4. AI NICs and related network-adapter products

## 4.1 The product branches

AMD's network portfolio contains several architectures because network workloads differ. Infrastructure services need large state tables and isolation. GPU communication needs efficient RDMA transport, load distribution and loss recovery. Some customers need configurable FPGA logic, while latency-sensitive host applications value a short, predictable software and NIC path.

| Product branch | Generation or representative products | Principal role | Status or positioning at the cutoff |
|---|---|---|---|
| Pensando AI NICs | Pollara 400, then Vulcano 800 | GPU scale-out communication and host networking | Dedicated AI NIC line; detailed below |
| Pensando DPUs | Capri, Elba, Giglio, Salina | Stateful infrastructure, security and storage services | Separate DPU lineage in Section 3 |
| Alveo adaptive SmartNICs | SN1000 / SN1022 | FPGA-customizable network and infrastructure offload | Supported for existing users; AMD directs new designs toward U45N |
| Alveo network accelerators | U45N; earlier U55N-related platforms | Custom datapaths, virtual switching, security and storage offload | U45N is a current FPGA development platform |
| Solarflare / Alveo Ethernet adapters | Solarflare X2, Alveo X3, Solarflare X4 | Low-latency host networking and software acceleration | Adjacent Ethernet family; not the Pensando GPU-fabric line |
| Adaptive SmartNIC SoC disclosure | AMD 400G Adaptive SmartNIC SoC, Hot Chips 2022 | Integrated hardened networking plus programmable logic | Architecture disclosure; kept separate from a claimed retail card launch |

## 4.2 Pollara 400: programmable transport for GPU clusters

Pollara was announced in October 2024 and made available for purchase in April 2025. Its architectural disclosure at Hot Chips 2025 is particularly useful because it explains the processing machinery behind the AI NIC label.

The product provides up to 400 Gb/s Ethernet and PCIe 5.0 ×16, in half-height, half-length PCIe and OCP 3.0 TSFF card formats. Its network interface can be configured as one 400 Gb/s, two 200 Gb/s or four 100 Gb/s ports. Pollara supports conventional host networking as well as GPU scale-out, including RoCEv2 interoperability and an RCCL-oriented data path.

Kevin Chu's Hot Chips presentation separates network-facing P4NET processing from P4DMA engines that bridge packets and memory. Its match processing units execute a domain-specific instruction set; table engines access the state needed by the transport. The talk also discloses address translation for registered memory, atomic state operations and a broadcast invalidate/update mechanism for pipeline caches. These are important differences from a diagram that simply labels a box “programmable Ethernet.” They explain how the NIC handles memory access and shared protocol state while many transfers are active.

The principal transport features address different failure modes. Packet spraying spreads traffic across paths. Out-of-order reception allows those paths to have different delays while preserving correct message delivery. Selective retransmission recovers missing data without resending everything that followed it. Path-aware congestion control adjusts behavior when a route is overloaded. These mechanisms determine useful communication throughput, particularly when synchronized GPUs create bursts or incast traffic.

AMD originally described Pollara as “UEC-ready.” That wording identifies a programmable implementation designed for evolving Ultra Ethernet capabilities; it should not be rewritten as unconditional conformance to every later consortium specification. The deployed transport mode, firmware and network configuration remain part of the system definition.

## 4.3 Vulcano 800: from an adapter to a rack component

Vulcano doubles nominal per-NIC Ethernet bandwidth to 800 Gb/s and appears in AMD's 2026 Helios portfolio. Its current product brief supports RoCEv2, UEC-ready RDMA, Multipath Reliable Connection, or MRC, and custom transports. Programmability allows the operator to choose how much path selection belongs at the NIC or in the switches.

The product has both standard adapter forms and custom multi-NIC boards. The latter are consequential: Helios can allocate two or three Vulcano NICs per GPU. The advertised maximum of 2.4 Tb/s per GPU is therefore a system configuration of three 800 Gb/s NICs. A six-NIC board supplies 4.8 Tb/s in aggregate for two GPUs. These are different quantities from the bandwidth of one NIC or one external connector.

| AI NIC configuration | Ethernet bandwidth | Physical or system form | Main generational implication |
|---|---|---|---|
| Pollara 400 | Up to 400 Gb/s per NIC | PCIe HHHL or OCP 3.0 TSFF | Programmable AI transport reaches a standard server-adapter platform |
| Vulcano 800 adapter | Up to 800 Gb/s per NIC | PCIe HHHL or OCP 3.0 TSFF | Higher-bandwidth scale-out with programmable transport choices |
| Vulcano four-NIC board | 3.2 Tb/s per board; 1.6 Tb/s per GPU | Custom Helios board serving two GPUs | Two NICs per GPU |
| Vulcano six-NIC board | 4.8 Tb/s per board; 2.4 Tb/s per GPU | Custom Helios board serving two GPUs | Three NICs per GPU |

AMD also describes Vulcano's role in scale-across networking, extending communication between clusters or sites. This makes path health, observability and recovery central product concerns. Additional link bandwidth can shorten transfer time, but geographic distance remains a latency constraint; the placement of training and inference work must account for it.

The progression from Pollara to Vulcano therefore has two dimensions: higher per-device bandwidth and a tighter relationship between NIC count, GPU bandwidth demand and rack design. Treating Vulcano only as an “800G card” misses the second change.

## 4.4 Alveo SmartNICs and network accelerators

The Xilinx-derived SN1000 family takes a different route to programmability. The SN1022 combines a 16 nm UltraScale+ FPGA with a sixteen-core Arm Cortex-A72 subsystem. P4, high-level synthesis and RTL can customize offloads; the published design includes network virtualization, security and storage functions. Its brief's 200 Gb/s full-duplex throughput figure combines directions around a 100 Gb/s service rate, so it should not be equated with Pensando's dual-200 Gb/s interface capability.

AMD currently supports existing SN1022 users while directing new designs toward Alveo U45N. U45N exposes two 100 Gb/s network interfaces and an FPGA platform for custom infrastructure processing, with Vivado and an OpenNIC reference design. This branch is useful when the customer wants to implement a data path in programmable logic rather than select or extend a Pensando service pipeline.

Hot Chips 2022's *AMD 400G Adaptive SmartNIC SoC* adds a further architectural disclosure. It integrates hardened networking, a processing subsystem, programmable logic, memory and a network-on-chip. The presentation describes PCIe 5.0/CXL 2.0 connectivity, 2 × 200 Gb/s or 4 × 100 Gb/s networking, DDR5/LPDDR5 controllers and cryptographic protection. It belongs in the technology history, but its conference disclosure should not be relabeled as a Pollara or Salina launch.

## 4.5 Solarflare X2, Alveo X3 and Solarflare X4

The Solarflare-derived adapter line addresses latency-sensitive host applications, supported by Onload and related software. AMD's migration documentation explicitly connects older Solarflare families and X2 to Alveo X3, and subsequently to Solarflare X4. This is a separate ancestry from Pensando.

X4 includes the X4522 and X4542, with PCIe 5.0 ×8, compact passively cooled cards and network configurations extending to dual 100 Gb/s. The ASIC supplies express and enterprise data paths for different application requirements. These products help complete the networking portfolio map, particularly for ingress services and latency-sensitive applications. They should not be presented as replacements for the high-bandwidth GPU collective network.

# 5. Adaptive accelerators, systems and the complete infrastructure stack

## 5.1 Where the product families fit

AMD's infrastructure portfolio is broader than the four major CPU, GPU, DPU and AI NIC lines. Xilinx, acquired in February 2022, brought adaptive silicon, accelerator cards, embedded platforms and their development tools. The resulting portfolio covers the execution of models, the movement and preparation of data, and the systems that host and manage those activities.

| Infrastructure function | AMD product families | Place in an AI deployment |
|---|---|---|
| General-purpose server compute | EPYC; EPYC Embedded for appliances | Model serving, orchestration, preprocessing, storage and security software |
| Large-scale accelerated compute | Instinct CDNA GPUs and CPU–GPU APUs | Training, inference and scientific computation |
| Infrastructure-service processing | Pensando DPUs and DSC platforms | Tenant networking, security, storage protocols and telemetry |
| GPU scale-out networking | Pensando Pollara and Vulcano AI NICs | RDMA and transport between accelerator systems |
| Local and rack scale-up | Infinity Fabric; UALink / UALoE integration | Tightly coupled accelerator communication |
| Adaptable compute and data movement | Alveo U-series and V80; Versal; UltraScale+ | Specialized processing, packet/data transformation, storage and analytics |
| Specialized inference history | Alveo V70; Versal AI Core / AI Edge | AI Engine-based inference; V70 is now discontinued |
| Media processing | Alveo U30 ancestry and MA35D | Video decode, encode, streaming and AI-assisted media processing |
| Other network adapters | Alveo U45N and SN1000; Solarflare X-series | Custom offload and latency-sensitive host networking |
| Local development and inference | Radeon PRO / Radeon AI PRO; Ryzen AI; Threadripper; Ryzen AI Halo | Workstations, compact development systems and local AI |
| Embedded and physical AI | EPYC Embedded; Ryzen Embedded / Ryzen AI Embedded; Versal; Zynq; Kria | Edge servers, industrial systems, sensing and robotics |
| Rack platforms and software | Helios; ROCm; enterprise AI stack; fabric and adaptive-computing tools | Deployment, communication, operations and application enablement |

The map describes product-family coverage rather than a bill of materials for every installation. An AI cluster does not need every accelerator type. The engineering task is to place each function on an appropriate processor and connect the resulting execution domains.

## 5.2 Alveo: several accelerator branches under one card brand

The earlier Alveo U200/U250, U280, U50 and U55C generation established FPGA cards for data-center acceleration. Their resources and memory configurations serve different balances of compute, memory and networking; they are not successive names for one fixed AI architecture. AMD's current general-compute portfolio highlights U50, U55C and V80, while older devices remain relevant to the historical software and deployment record.

**V80, introduced in 2024,** is an instructive comparison with Instinct. It uses a Versal HBM device with 32 GB HBM2e, approximately 810 GB/s peak HBM bandwidth and four 200 Gb/s network connections. Its FPGA fabric supports custom data types and data movement. The supplied Alveo Versal Example Design and Vivado flow target hardware developers. The architectural opportunity is to build a tailored processing pipeline around memory and I/O rather than express all work as GPU kernels. V80's HBM and network ports make it relevant to infrastructure even when it is not doing neural-network matrix multiplication.

**V70, announced at CES 2023,** is a distinct AI Engine inference branch. AMD lists second-generation AIE-ML tiles, a 75 W card and a small form factor. Its internal-memory bandwidth and external-DDR bandwidth refer to different levels of the memory system and cannot be compared directly with Instinct's HBM bandwidth. As of the report cutoff, AMD marks V70 discontinued, with no further updates to its targeted solutions and limited support. It remains important to the architectural history but is not a current purchasing recommendation.

**MA35D, introduced in 2023,** demonstrates that Alveo is not exclusively an FPGA brand. The card uses two purpose-built 5 nm video-processing ASICs with codec engines and AI-assisted video-quality processing. It follows the earlier U30 media line and supports AV1 alongside H.264 and H.265, with the AMD Media Acceleration SDK connecting it to frameworks such as FFmpeg and GStreamer. In a video-oriented AI service, dedicated media processing can prepare or deliver streams around an inference pipeline without consuming the same resources as the model itself.

AMD also maintains Alveo products aimed at specialized low-latency workloads, including X3522PV, UL3422, UL3524 and the VCK5000 development platform. These are adjacent infrastructure tools, particularly when a customer combines streaming data, networking and application-specific inference. They are not additional Instinct generations.

## 5.3 Versal: the silicon architecture behind adaptive acceleration

Versal combines programmable logic, embedded scalar processing, hardened I/O and a programmable network-on-chip. Selected families add AI Engine arrays; the presence and type of AI Engines depend on the series. This distinction matters because a Versal HBM accelerator and a Versal AI Core device need not offer the same execution resources.

Hot Chips 2019's Versal/AI Engine presentation disclosed the VC1902 architecture, including an array of 400 AI Engine tiles with local memories, SIMD execution and intertile communication. The dataflow organization lets neighboring engines exchange intermediate results without routing every operation through external memory. ISSCC 2020's *A Versatile 7nm Adaptive Compute Acceleration Platform Processor* supplies the complementary silicon-implementation disclosure. This is another useful Hot Chips–ISSCC pairing, alongside those for Zen and Instinct.

Hot Chips 2020 covered Versal Premium, and Hot Chips 2021 covered Versal AI Edge. These extend the architecture toward different priorities: connectivity and hardened infrastructure functions on one branch, and efficient embedded AI on another. The resulting family tree should be read by resources and workload role, not as a single sequence of increasingly large neural accelerators.

| Versal branch | Main resource emphasis | Relevance to infrastructure |
|---|---|---|
| Prime / Prime Gen 2 | Programmable logic, embedded processors and connectivity | General embedded acceleration and custom control/data paths |
| AI Core / AI Edge / AI Edge Gen 2 | AI Engine-based processing alongside logic and processors | Inference, signal processing and sensor-oriented AI |
| Premium / Premium Gen 2 | High-speed I/O, hardened protocol and security resources | Networking, storage, memory expansion and high-bandwidth acceleration |
| HBM | Programmable processing with nearby high-bandwidth memory | Memory-intensive acceleration; the basis of Alveo V80 |
| RF | Integrated RF-oriented resources and adaptive processing | Radio and sensing infrastructure at the edge |

Premium Gen 2 adds PCIe 6.0 and CXL 3.1, faster external-memory interfaces and hardened security functions. AMD reported standard devices shipping in June 2026. The separately announced Memory on Package variant integrates up to 32 GB LPDDR5X and 288 GB/s; its schedule calls for sampling at the end of 2026 and production in the second half of 2027. It is a roadmap extension at this cutoff, not an already completed deployment generation.

The portfolio demonstrates three distinct uses of nearby memory: HBM feeds Instinct's parallel numerical execution; HBM or DDR can hold DPU service state; and Versal's local memories, HBM or packaged LPDDR serve different adaptive-processing designs. The memory technology alone does not identify the processor's role.

## 5.4 Helios and the three network roles

Helios brings EPYC, Instinct and Pensando into a rack design. Its significance is the co-design of compute, memory, interconnect, power, cooling and operations. The CPU/GPU generation details appear in Sections 1 and 2; the infrastructure view explains how the product families cooperate.

| Network role | Main traffic | AMD components and integration |
|---|---|---|
| Front end and storage access | Requests, ingestion, tenant services, storage and retained inference state | Salina DPU, host networking and storage software |
| Scale-up within the accelerator domain | Frequent tightly coupled GPU communication | Infinity Fabric in earlier platforms; UALoE in Helios |
| Scale-out beyond the domain | Distributed training and inference across systems | Pollara or Vulcano AI NICs and the Ethernet fabric |

AMD's detailed Helios description uses a single-hop, multiplane UALoE fabric connecting seventy-two GPUs through twelve switches in six switch trays. This is distinct from the Vulcano scale-out network. Combining their bandwidth figures into one undifferentiated “network bandwidth” number would obscure which traffic each fabric carries.

AMD Fabric Manager and Fabric OS provide the scale-up operational layer, including telemetry and recovery; vPods partition the accelerator domain into software-defined environments. ROCm and collective-communication software operate above the physical connectivity. These are necessary parts of turning connected hardware into a usable shared system.

The switch platforms are also an ecosystem story. AMD's HPE collaboration and joint Broadcom session at Advancing AI 2026 describe UALoE switch integration. Helios should therefore be understood as an AMD platform design implemented with system and networking partners, not as evidence that every switch chip, optical module, memory device or cooling component is an AMD product.

## 5.5 Software product lines complete the hardware picture

| Software or platform | Main hardware relationship | What it contributes |
|---|---|---|
| ROCm, HIP and optimized libraries | Instinct and supported Radeon platforms | GPU programming, runtimes, math, AI frameworks and profiling |
| RCCL and AI NIC integration | Multiple GPUs and scale-out adapters | Collective communication and transport integration |
| AMD Enterprise AI Reference Stack | AMD compute platforms | Kubernetes-based deployment, inference microservices, AI Workbench, resource management and solution blueprints |
| ROCm.AI and ROCm Hyperloom | AI development and optimization on supported AMD systems | Integrated workflows and profiling-driven application/kernel optimization |
| Pensando SSDK and PSM | Pensando DPUs | Service development, policy and fleet integration |
| Fabric Manager and Fabric OS | Helios scale-up fabric | Provisioning, observability and recovery |
| Vivado, Vitis, Vitis AI and XRT | FPGAs, Versal and supported Alveo platforms | Hardware design, acceleration, inference compilation and runtime support |
| Onload and related network software | Solarflare / Alveo Ethernet adapters | Low-latency host networking |
| Zen Software Studio / ZenDNN | EPYC and other supported Zen processors | CPU libraries, tools and inference optimization |
| Ryzen AI and robotics software | Ryzen AI, embedded and Kria platforms | Local inference and physical-AI application enablement |

The software history follows the hardware's expanding scope. ROCm began as a GPU-compute platform and grew with Instinct into a larger AI and HPC environment. By August 2026, AMD's ROCm 10 announcement emphasized ROCm.AI workflows, Hyperloom optimization and a preview unified CLI. The enterprise reference stack addresses a different layer: deploying and managing applications and resources above the compiler and runtime.

Adaptive-computing software remains a distinct development path. An FPGA design, a Versal AI Engine program, a Pensando P4 service and a CDNA GPU kernel are different artifacts even if they participate in one AI service. Historical Vitis AI documentation also uses “DPU” for **deep-learning processing unit** IP; that term must not be confused with a Pensando **data processing unit**.

## 5.6 The local and embedded branches

Radeon AI PRO R9700, announced at Computex 2025, brings RDNA 4 and 32 GB GDDR6 to local AI development and inference. Threadripper supplies workstation CPU capacity and I/O, while Ryzen AI and Ryzen AI Halo address compact local systems. These products connect development and smaller deployments to the broader AMD software ecosystem, but their memory, interconnect and deployment scale differ from Instinct systems.

EPYC Embedded extends server-class compute into network, storage and industrial appliances with long product lifecycles. The family spans Embedded 3000, 7002/7003, 8004/9004, and the Zen 5-era 2005, 4005 and 9005 branches. The smaller BGA and AM5 products serve different power and platform requirements from SP5 server-class devices. These CPUs may run the control and storage services around an AI installation without being its model accelerator.

At the physical-AI end, the portfolio includes Zynq UltraScale+ platforms, Versal adaptive SoCs and Kria modules. The older K26/K24 module families and the 2026 Kria AI SOM have different underlying architectures. The newer AI SOM uses Ryzen AI Embedded X100, bringing Zen 5 CPU cores, RDNA 3.5 graphics, an XDNA 2 NPU and unified memory to a COM-HPC module. It extends the product map to robotics and autonomous systems rather than adding another data-center GPU.

# 6. What the academic conferences contribute

## 6.1 ISCA: product architecture and the exascale design history

ISCA contains the most direct bridges between AMD research and these commercial product families. The 2021 EPYC/Ryzen industrial product paper explains the evolution from reusable complete SoCs to heterogeneous compute/I/O chiplets. It is the best conceptual companion to the Naples and Rome disclosures because it explains why the partition changed.

The 2023 exascale retrospective traces the research and co-design process leading to Frontier. It treats the machine as a node and system problem, rather than simply a GPU specification. The 2024 heterogeneous-processor paper then explains MI300A and how advances in integration made the original CPU–GPU concept practical.

These three papers should be read alongside Hot Chips and ISSCC. They provide design rationale and history; the other venues provide the contemporary block diagrams and implementation results. ISCA's tutorials also matter: AMD's gem5 APU tutorial in 2018 made an ISA-level CPU/GPU research model available to the architecture community.

## 6.2 MICRO: interconnect, front-end efficiency and GPU translation

The 2015 paper *Enabling Interposer-based Disintegration of Multi-core Processors* studies how splitting a processor into smaller dies affects manufacturing cost and the on-chip/interposer network. Its importance is conceptual: partitioning silicon introduces communication costs that must be addressed architecturally. It is research on the design space, rather than documentation of Naples' actual organic-substrate implementation.

The 2020 AMD Research paper on micro-operation caches investigates fragmentation and proposes ways to use those caches more effectively. It helps explain why front-end structures are important in the Zen family, but the paper's proposed mechanisms should not be assigned to a particular Zen generation without a product disclosure.

The 2021 GPU translation paper addresses another scaling constraint: large memory capacity is useful only if address translation can reach the working set efficiently. It explores using underutilized instruction-cache and local-data-share resources to extend translation reach. The connection to Instinct is the problem being solved, not a claim that every proposed structure ships in MI200 or MI300.

MICRO also includes independent research on AMD processors and GPUs. Such measurements can reveal behavior absent from vendor diagrams. They should be distinguished from AMD-authored product disclosures and from the similarly named IEEE Micro journal.

## 6.3 HPCA: the heterogeneous processor before it became MI300A

HPCA 2017's *Design and Analysis of an APU for Exascale Computing* proposed an integrated CPU/GPU processor using chiplets and in-package stacked memory. Its evaluation considered compute resources, memory bandwidth, communication and power together. The paper's projected capacities and organization describe the research design of that period; they are not specifications for the later MI300A.

The durable contribution is the design question: which mixture of CPU execution, GPU throughput and nearby memory gives useful application performance within a system power budget? MI300A eventually embodies that general direction, but the intervening Frontier design and later packaging advances explain the differences.

HPCA 2018's GPU-modeling paper, *Lost in Abstraction*, shows why analysis at an intermediate-language level can miss behavior that appears when real machine instructions and execution resources are modeled. This matters when interpreting GPU research as evidence about commercial GCN/CDNA products.

Other AMD-affiliated HPCA work covers chiplet network design and GPU caches. These papers broaden the engineering picture: core and matrix counts are only part of a system whose behavior depends on routing, buffering, caching, translation and workload structure.

## 6.4 ASPLOS: extracting performance from the hardware/software boundary

ASPLOS is particularly useful for connecting the hardware roadmap to software behavior. The 2024 *T3* paper proposes fine-grained overlap of computation and collective communication, using hardware/software cooperation to reduce serialized communication and contention. This is directly relevant to understanding why larger accelerator systems require more than faster links. It remains a research proposal, not a documented MI300 or Helios feature.

The 2025 recommendation-inference paper introduces the Balance scheduler, which accounts for memory-level parallelism, load imbalance and CPU-chiplet organization. Its relevance to EPYC is practical: additional cores and memory channels deliver their value only when tasks are distributed in a way that uses them effectively.

Independent ASPLOS 2024 work on explainable port-mapping inference studies AMD Zen processors through sparse performance counters. It complements vendor disclosures by helping characterize the execution resources seen by machine instructions. This is useful for compiler models and performance analysis, while remaining a different kind of source from AMD's own architecture presentations.

Together, the big four conferences show three layers of the product story: architectural ideas, engineering decisions that entered products, and the software behavior of the resulting systems. Reading across those layers connects the evolution of the hardware to the applications it ultimately serves.

## 6.5 Networking and adaptive computing extend the academic record

For Pensando, the direct systems bridge is NSDI 2023’s joint Microsoft–AMD paper on Sirius. Its contribution is placement and state management: a shared pool of programmable cards can decouple infrastructure-service capacity from tenant-server capacity. This complements the device architecture at Hot Chips.

The broad SmartNIC literature also appears at the big four conferences, but a paper that cites Pensando is not automatically a disclosure of a Pensando product. The similarly named IEEE Micro journal published Michael Galles and Francis Matus’s *Pensando Distributed Services Architecture* in 2021; that is the journal companion to the Hot Chips work, not a MICRO conference paper.

For the adaptive portfolio, Hot Chips 2019 and ISSCC 2020 provide a direct architecture/implementation pair for Versal. FPGA, FCCM, FPL and FPT add the mapping, compiler and hardware-design perspective. These venues matter because programming a spatial data path raises different questions from scheduling GPU threads.

## 6.6 Selected academic papers mapped to the product story

| Venue and year | Paper or topic | Why it belongs in this report |
|---|---|---|
| MICRO 2015 | Interposer-based disintegration of multicore processors | Early analysis of the economics/communication tradeoff in chiplets |
| HPCA 2017 | Design and Analysis of an APU for Exascale Computing | Research architecture preceding integrated CPU/GPU/HBM products |
| HPCA 2018 | Lost in Abstraction | Importance of ISA-level GPU modeling |
| ISCA 2018 | Modular Routing Design for Chiplet-based Systems | Interconnect organization across independently designed dies |
| HPCA 2020 | Experiences with ML-Driven Design: A NoC Case Study | Methods for exploring network design choices |
| MICRO 2020 | Improving the Utilization of Micro-operation Caches | Zen-relevant front-end efficiency research |
| ISCA 2021 | Pioneering Chiplet Technology and Design for EPYC and Ryzen | Direct industrial account of the CPU chiplet strategy |
| MICRO 2021 | Increasing GPU Translation Reach | Translation as a limit on large GPU working sets |
| ISCA 2023 | A Research Retrospective on AMD's Exascale Computing Journey | Frontier's design history and system co-design |
| ISCA 2024 | Realizing the AMD Exascale Heterogeneous Processor Vision | Direct account of MI300A's architecture and integration |
| ASPLOS 2024 | T3: overlap of compute and collectives | Research on communication efficiency in distributed AI |
| ASPLOS 2024 | Explainable Port Mapping Inference for AMD Zen | Independent characterization of CPU execution behavior |
| ASPLOS 2025 | Load and MLP-Aware Thread Orchestration | Software scheduling across CPU chiplets for recommendation inference |
| SCA/HPCAsia 2026 | Cloud-Hardware Co-Design for Azure HBv5 | Custom HBM-based EPYC/cloud architecture |
| NSDI 2023 | Disaggregating Stateful Network Functions | Joint Microsoft–AMD Pensando account of cloud services on shared DPU resources |

# 7. Conference and event map

## 7.1 Hot Chips and ISSCC: the most useful product pairings

| Product or technology | Hot Chips architectural disclosure | ISSCC implementation disclosure |
|---|---|---|
| Zen / Naples | Zen core, 2016; EPYC architecture, 2017 | Zen core, 2017; Zeppelin SoC, 2018 |
| Vega / MI25 ancestry | Vega architecture, 2017 | Use product/Vega material; no specific MI25 ISSCC paper is assumed here |
| Zen 2 / Rome | Zen 2, 2019 | Zen 2 core and chiplet architecture, 2020 |
| Zen 3 / Milan | Zen 3, 2021 | Zen 3 core, 2022 |
| 3D V-Cache / Milan-X | Advanced-packaging tutorial, 2021 | Hybrid-bonded 64 MB stacked cache, 2022 |
| MI200 | MI200 accelerator and node architectures, 2022 | VLSI 2023 supplies a complementary packaging disclosure |
| Zen 4 / Genoa | Zen 4 and EPYC 9004, 2023 | Zen 4, 2023 |
| Zen 4c / Bergamo | EPYC 9004 family discussion, 2023 | Area-optimized Zen 4c core, 2024 |
| MI300 | MI300X architecture, 2024 | MI300 modular chiplet package, 2024 |
| Zen 5 / Turin | Zen 5, 2024 | Zen 5 core, 2025 |
| MI350 / CDNA 4 | CDNA 4 / MI350 architecture and platforms, 2025 | MI350 stacked XCD/IOD implementation, 2026 |
| MI400 / CDNA 5 | GPU architecture and system architecture talks, 2026 | No MI400 ISSCC implementation paper is established in this review |
| Pensando Capri / Elba | Distributed Services Architecture, 2020 | Product briefs and the IEEE Micro 2021 article provide implementation context; no specific ISSCC pairing identified |
| Pensando Pollara 400 | AI NIC architecture and application, 2025 | Product and software documentation supply the device detail; no specific ISSCC pairing identified |
| Vulcano / Helios networking | MI400 system-architecture session, 2026 | Product briefs and rack disclosures establish the deployed organization |
| Versal / AI Engine | VC1902 and AI Engine, 2019 | 7 nm ACAP processor, 2020, paper 8.2 |
| Adaptive SmartNIC SoC | AMD 400G design, 2022 | Use its disclosed interfaces and architecture without assigning a Pensando product identity |

A conference year is a disclosure date, not necessarily a product introduction date. MI300's principal Hot Chips presentation was in 2024, after the 2023 launch. MI350's ISSCC paper was in 2026, after the 2025 product introduction. These distinctions prevent the conference chronology from distorting the product chronology. The DPU and NIC record has fewer direct circuit-paper pairings than Zen or Instinct; its complementary evidence is in device briefs, programming documentation and networking-systems papers.

## 7.2 The wider technical venues

| Venue group | Contribution to understanding AMD products | Concrete examples or use in this review |
|---|---|---|
| ISCA, MICRO, HPCA, ASPLOS | Architecture, research rationale, measurements and software interaction | Product papers and selected research mapped in Section 6 |
| Hot Chips | Core, SoC, accelerator and system organization | Zen/EPYC, Instinct, Pensando DSA, Pollara, adaptive SmartNIC and Versal talks |
| ISSCC | Circuits, physical design, SRAM, power and die integration | Zen, Zeppelin, V-Cache, MI300/MI350 and the Versal ACAP implementation |
| Symposium on VLSI Technology and Circuits | Packaging and architecture/implementation co-design | MI250X EFB, 2023; MI300X packaging co-optimization, 2024 |
| IEDM | Device, process and heterogeneous-integration direction | AMD multichip keynote, 2017; chiplet/cache coevolution, 2024 |
| DAC | Design methods, EDA and engineering strategy | Papermaster keynote, 2022; Blott keynote, 2025; AMD-affiliated integration research |
| DATE | Design and system-integration methodology | Chiplet opportunities/limits, 2021; next era of chiplet innovation, 2023 |
| ISPASS and IISWC | Measurement, workloads and performance interpretation | ISPASS 2022 Rome memory characterization |
| SC and ISC | Complete HPC systems, applications and deployments | Frontier and El Capitan milestones; EPYC/Instinct ecosystem announcements |
| SCA/HPCAsia | HPC architecture and deployment co-design | Azure HBv5 paper, 2026 |
| PACT, ICS, HPDC, CGO and PPoPP | Parallel execution, compilers, runtimes and heterogeneous systems | Relevant complementary literature; not separately audited as full proceedings here |
| ICCAD, ECTC and packaging workshops | Design automation, integration, test and manufacturability | Useful neighboring venues; not a substitute for verified product-specific disclosures |
| NSDI, SIGCOMM, OSDI and networking workshops | Network services, transport, state and operational systems | NSDI 2023 Sirius is a direct Pensando case; other venues supply complementary research |
| FPGA, FCCM, FPL and FPT | Reconfigurable architecture, compilation and workload mapping | Relevant to Alveo, Versal and FPGA-based network acceleration |
| SIGGRAPH, GDC and GPU developer events | Graphics architecture, rendering and software | Useful for Radeon/RDNA and shared technology, less direct for Instinct server architecture |

DAC deserves inclusion but plays a different role from Hot Chips or ISSCC. AMD's 2022 keynote on AI and HPC in EDA, its 2021 cross-disciplinary innovation talk and its 2025 AMD Research keynote show the design-methodology context. They should not be treated as a complete EPYC or Instinct microarchitecture disclosure.

## 7.3 Industry events and hyperscaler venues

| Venue | Verified AMD-related milestones | What the venue adds |
|---|---|---|
| AMD Financial Analyst Day | EPYC branding in 2017; chiplet, Zen and CDNA roadmaps in 2022 | Strategy and product-family direction |
| AMD Next Horizon, 2018 | Rome preview; MI50/MI60; early cloud adoption | CPU/GPU data-center positioning |
| AMD Accelerated Data Center Premiere, 2021 | MI200, Milan-X direction, Genoa/Bergamo roadmap | Workload-specific server portfolio |
| AMD Data Center and AI Technology Premiere, 2023 | Bergamo, Genoa-X and MI300X preview | Divergence of CPU branches and AI accelerator strategy |
| AMD Advancing AI, 2023–2026 | MI300 launch; Turin/MI325X; MI350; Venice/MI400/Helios | Product introductions, software and partner systems |
| Computex | V-Cache demonstration in 2021; Zen 5/Turin and accelerator roadmap in 2024 | Shared client/server technology and roadmaps |
| CES | MI300 preview in 2023; Helios/MI400 direction in 2026 | Broad product previews and client-to-server context |
| OCP Global Summit | Helios open-rack direction in 2025 | Mechanical, electrical, networking and ecosystem integration |
| MWC | Siena-based telco/edge demonstrations in 2024 and later EPYC telco platforms | Deployment constraints, vRAN and edge use cases |
| AWS re:Invent | M6a with Milan in 2021; EPYC deployment sessions | How the CPU becomes a cloud instance and service |
| Microsoft Ignite | MI300X Azure preview in 2023; HBv5 introduction in 2024 | Accelerator adoption and custom CPU/cloud co-design |
| Microsoft Build | Azure MI300X availability and services in 2024 | Software and production deployment milestone |
| Google Cloud Next | C4D and H4D with Turin in 2025 | Cloud general-purpose and HPC productization |
| NVIDIA GTC | DGX A100 in 2020 used two EPYC 7742 CPUs | EPYC's role as the host of another vendor's accelerators |
| SC / ISC | MI100-era announcements, Frontier and El Capitan | Application-scale evidence and complete HPC systems |


GTC belongs in an AMD report mainly through such host-CPU deployments, not as the principal venue for Instinct architecture. Likewise, a hyperscaler's conference can establish that a product is being offered in a service without revealing the internal details of the chip.

Some launches occurred outside the conference most commonly associated with the customer. For example, first-generation EPYC's AWS relationship was highlighted at AMD's Next Horizon event in 2018; it should not automatically be labeled a re:Invent announcement.

## 7.4 Networking, adaptive and media venues

| Venue | Verified AMD-related milestones | What the venue adds |
|---|---|---|
| VMware Explore | vSphere 8 and Pensando DSC support, 2022 | Infrastructure services and hypervisor integration |
| Cisco Live | N9300 Smart Switch announcement, 2025 | Pensando DPUs integrated with partner switching and security |
| Oracle CloudWorld / AI World | Pensando cloud deployment and later converged-networking partnerships | Cloud service and infrastructure integration |
| Xilinx developer events and adaptive-computing events | Versal, Alveo and their programming environment | FPGA and AI Engine productization |
| NAB and media-industry events | MA35D launch period and media ecosystem, 2023 | Specialized video acceleration around AI workflows |

For the added product lines, Advancing AI 2024 introduced Salina and Pollara; Hot Chips 2025 explained Pollara; Advancing AI 2026 connected Salina, Vulcano and UALoE to Helios. A launch occurring near a hyperscaler event is not, by itself, evidence that the provider uses that NIC.

# 8. Shared technology across desktop, mobile and server

## 8.1 CPU reuse is real, but the surrounding machine differs

| Core generation | Server products | Relevant client/workstation connection |
|---|---|---|
| Zen | Naples | Ryzen 1000 and first Threadripper reuse Zeppelin-based technology |
| Zen+ | No corresponding main EPYC generation | Client process/implementation refinement; not a missing Naples-to-Rome server generation |
| Zen 2 | Rome | Ryzen 3000 and Threadripper 3000 illustrate compute-chiplet reuse |
| Zen 3 | Milan / Milan-X | Ryzen 5000; 5800X3D illustrates stacked cache in a client product |
| Zen 4 | Genoa / Genoa-X; MI300A CPU chiplets | Ryzen 7000 and Threadripper 7000; Phoenix APUs show a different integration choice |
| Zen 4c | Bergamo / Siena | Dense-core concepts also appear in selected mobile products |
| Zen 5 / Zen 5c | Turin; Sorano; EPYC 4005 | Ryzen 9000 and Ryzen AI products share core-generation technology with different cache and SoC balances |
| Zen 6 / Zen 6c | Venice | This report anchors the generation to verified server disclosures at the cutoff |

An APU can use a related CPU core with different L3 capacity, memory controllers, power limits and integrated graphics. Hot Chips presentations on Raven Ridge in 2018, Ryzen 4000 in 2020, Ryzen 6000 in 2022 and Ryzen 7040 in 2023 show these distinct SoC integration choices. The shared core does not imply a shared server platform.

## 8.2 GPU reuse changes after Vega

Early Instinct products have direct graphics relatives: Fiji, Vega and Vega 20. From MI100 onward, CDNA is the dedicated compute branch, while RDNA serves graphics-oriented products. Shared packaging and design methods do not imply equivalent compute units.

Hot Chips' Vega disclosure, ISSCC 2020's RX 5700 implementation paper and Hot Chips 2025's RDNA 4 presentation form a useful adjacent reading line. Radeon graphics/memory chiplets use a different organization from MI300's stacked compute and I/O dies. XDNA NPUs and Xilinx adaptive devices form separate accelerator lineages.

# 9. Engineering conclusions across the generations

## 9.1 Chiplet economics and architecture must be read together

Smaller dies can improve manufacturing flexibility and enable reuse, but the architectural boundary determines whether the assembly performs well. Naples, Rome, MI250X, MI300 and MI350 each chose a different boundary. Treating them all as simply “chiplet products” hides the most important decisions.

For CPUs, moving memory control into an I/O die made compute scaling more modular. For GPUs, moving from two complete GCDs to compute chiplets over infrastructure dies changed the programming and memory organization. MI400 separates additional infrastructure functions while extending communication to a rack.

## 9.2 More cache, more HBM and more cores solve different problems

V-Cache reduces traffic when reused data remains in cache. HBM raises bandwidth and places substantial memory close to computation. More cores or matrix engines increase execution capacity. The useful combination depends on reuse, working-set size, parallelism and numerical requirements.

This is the reason for AMD's increasingly branched portfolio. Genoa-X, Bergamo, Siena and custom HBM EPYC systems address different constraints. MI300A, MI300X and later PCIe or rack-oriented Instinct products likewise represent different system balances rather than a single universal accelerator design.

## 9.3 Locality persists as integration increases

A coherent system is not necessarily uniform in access cost. A socket is not necessarily one cache-sharing domain. An accelerator package is not necessarily one logical GPU. A rack's aggregate memory is not necessarily a single local pool.

The practical reading of each generation should identify four boundaries: where caches are shared, where memory is physically attached, which compute resources form a logical device, and which links carry communication between those domains. Those boundaries explain many performance differences that process node and peak throughput cannot.

## 9.4 Infrastructure processing and communication are different workloads

The DPU and AI NIC histories clarify why a server portfolio needs more than fast CPUs and GPUs. A DPU can remove networking, security and storage work from application processors and place policy enforcement in a separate domain. An AI NIC improves communication among accelerators. FPGA-based platforms add custom data paths where the workload justifies hardware specialization.

Their performance measures differ. Stateful services depend on connections, table scale and packet processing. Collective communication depends on message delivery, congestion and the slowest participating endpoints. A product comparison must therefore start with the work being moved, then examine the memory and communication resources needed to execute it.

## 9.5 The platform boundary now extends across the rack

The expansion from EPYC and Instinct into networking and adaptive compute makes the system boundary explicit. HBM, host DDR, DPU memory and NVMe are separate tiers with different access costs. Scale-up and scale-out links serve different traffic. Management software decides how shared resources are partitioned and recovered.

The engineering implication is to evaluate an AI platform as a chain of execution and data movement: ingestion, preparation, model execution, communication, retained state and delivery. Improving the component that limits that chain matters more than maximizing every isolated specification.

## 9.6 The best source combination changes with the question

For **a core**, start with Hot Chips and the corresponding ISSCC paper. For **a package**, add the industrial product paper and VLSI/packaging material. For **an HPC node**, add the exascale papers and laboratory documentation. For **a cloud service**, add the provider's current VM documentation and deployment announcement. For **AI scaling**, add communication, software and rack-level disclosures.

AMD's strongest sustained advantage in this history is the ability to reuse technology while changing the product boundary. The report's product-by-product comparisons show how that capability grew from a reusable CPU SoC into a family of CPUs, GPUs, programmable network processors, adaptive accelerators and complete AI systems.

# References and further reading

References are grouped by the products and sections they support. Links point to original conference materials, AMD technical documents, author-hosted papers or the organization deploying the system. Conference programs establish the existence and timing of a presentation when the full slides are not publicly accessible. The lists are a selected research bibliography, not a claim to cover every paper at every venue.

## A. Naples, Rome and the CPU chiplet foundation

- **A1.** Michael Clark, *A New, High Performance x86 Core Design from AMD*, Hot Chips 28, 2016. [Presentation](https://old.hotchips.org/wp-content/uploads/hc_archives/hc28/HC28.23-Tuesday-Epub/HC28.23.90-High-Perform-Epub/HC28.23.930-X86-core-MikeClark-AMD-final_v2-28.pdf).
- **A2.** Kevin Lepak, *Next Generation AMD Enterprise Server Product Architecture*, Hot Chips 29, 2017. [Presentation](https://old.hotchips.org/wp-content/uploads/hc_archives/hc29/HC29.22-Tuesday-Pub/HC29.22.90-Server-Pub/HC29.22.921-EPYC-Lepak-AMD-v2.pdf).
- **A3.** Teja Singh et al., *Zen: A Next-Generation High-Performance x86 Core*, ISSCC 2017; expanded journal treatment, *Zen: An Energy-Efficient High-Performance x86 Core*, JSSC. [Journal DOI](https://doi.org/10.1109/JSSC.2017.2752839).
- **A4.** Noah Beck et al., *Zeppelin: An SoC for Multichip Architectures*, ISSCC 2018, paper 2.4. [DOI](https://doi.org/10.1109/ISSCC.2018.8310173); [AMD presentation](https://www.slideshare.net/slideshow/isscc-2018-zeppelin-an-soc-for-multichip-architectures/88327178).
- **A5.** AMD, *Zen 2*, Hot Chips 31, 2019. [Presentation](https://old.hotchips.org/hc31/HC31_1.1_AMD_ZEN2.pdf).
- **A6.** ISSCC 2020, papers 2.1 and 2.2: Zen 2 core and AMD chiplet architecture for server/desktop products. [Conference press material](https://www.isscc.org/s/2020-Press-Kit.pdf).
- **A7.** Samuel Naffziger et al., *Pioneering Chiplet Technology and Design for the AMD EPYC and Ryzen Processor Families*, ISCA 2021, industrial product paper. [DOI](https://doi.org/10.1109/ISCA52012.2021.00014).
- **A8.** AMD, second-generation EPYC launch, 7 August 2019. [Announcement](https://ir.amd.com/news-events/press-releases/detail/904/2nd-gen-amd-epyc-processors-set-new-standard-for-the-modern-datacenter-with-record-breaking-performance-and-significant-tco-savings).
- **A9.** AMD, *AMD EPYC 7002 Series Processors: HPC Tuning Guide*, publication 56827. [Technical guide](https://www.amd.com/content/dam/amd/en/documents/epyc-technical-docs/tuning-guides/amd-epyc-7002-tg-hpc-56827.pdf).
- **A10.** Velten et al., *Memory Performance of AMD EPYC Rome and Intel Cascade Lake SP Server Processors*, ISPASS 2022. [Author manuscript](https://arxiv.org/abs/2204.03290).

## B. Milan, V-Cache and Genoa-family products

- **B1.** Mark Evers, Zen 3 architecture presentation, Hot Chips 33, 2021. [Conference program](https://hc33.hotchips.org/program/).
- **B2.** Thomas Burd et al., *Zen 3: The AMD 2nd-Generation 7nm x86-64 Microprocessor Core*, ISSCC 2022, paper 2.7. [AMD slides](https://www.slideshare.net/AMD/zen-3-amd-2nd-generation-7nm-x8664-microprocessor-core).
- **B3.** AMD, *Overview of AMD EPYC 7003 Series Processors Microarchitecture*. [Technical document](https://docs.amd.com/v/u/en-US/overview-amd-epyc7003-series-processors-microarchitecture).
- **B4.** John Wuu et al., *3D V-Cache: The Implementation of a Hybrid-Bonded 64MB Stacked Cache for a 7nm x86-64 CPU*, ISSCC 2022, paper 26.4. [AMD slides](https://www.slideshare.net/AMD/3d-vcache).
- **B5.** Raja Swaminathan, advanced packaging tutorial, Hot Chips 33, 2021. [Presentation](https://hc33.hotchips.org/assets/program/tutorials/2021%20Hot%20Chips%20AMD%20Advanced%20Packaging%20Swaminathan%20Final%20%2020210820.pdf).
- **B6.** AMD, Milan-X / 3D V-Cache product brief. [Brief](https://www.amd.com/content/dam/amd/en/documents/epyc-business-docs/product-briefs/3d-vcache.pdf).
- **B7.** AMD, Computex 2021 technology announcement. [V-Cache demonstration](https://www.amd.com/en/newsroom/press-releases/2021-5-31-amd-showcases-industry-leading-innovation-across-t.html).
- **B8.** Kai Troester and Ravi Bhargava, Zen 4 and EPYC 9004, Hot Chips 2023. [Presentation](https://hc2023.hotchips.org/assets/program/conference/day1/CPU1/HC_Zen4_Epyc_Final_20230825%20-%20Embargoed%20until%20Aug%2029%202023.pdf).
- **B9.** Benjamin Munger et al., *Zen 4: The AMD 5nm 5.7GHz x86-64 Microprocessor Core*, ISSCC 2023. [Conference press material](https://www.isscc.org/s/ISSCC2023-PressKit.pdf).
- **B10.** Thomas Burd et al., *Zen 4c: The AMD 5nm Area-Optimized x86-64 Microprocessor Core*, ISSCC 2024, paper 2.2. [DOI](https://doi.org/10.1109/ISSCC49657.2024.10454507).
- **B11.** AMD, *4th Gen AMD EPYC Processor Architecture*. [White paper](https://www.amd.com/content/dam/amd/en/documents/products/epyc/4th-gen-amd-epyc-processor-architecture-whitepaper.pdf).
- **B12.** AMD, Genoa launch, 10 November 2022. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1100/offering-unmatched-performance-leadership-energy-efficiency-and-next-generation-architecture-amd-brings-4th-gen-amd-epyc-processors-to-the-modern-data-center).
- **B13.** AMD, Data Center and AI Technology Premiere, 13 June 2023. [Bergamo, Genoa-X and MI300X announcement](https://ir.amd.com/news-events/press-releases/detail/1136/amd-expands-leadership-data-center-portfolio-with-new-epyc-cpus-and-shares-details-on-next-generation-amd-instinct-accelerator-and-software-enablement-for-generative-ai).
- **B14.** AMD, EPYC 8004 launch, 18 September 2023. [Siena announcement](https://www.amd.com/en/newsroom/press-releases/2023-9-18-amd-completes-4th-gen-epyc-family-with-the-amd-epy.html).
- **B15.** AMD, Infinity Guard generation comparison. [Security feature overview](https://www.amd.com/en/products/processors/server/epyc/infinity-guard.html).

## C. Turin, Venice and specialized EPYC systems

- **C1.** Brad Cohen and Mahesh Subramony, Zen 5, Hot Chips 2024. [Presentation](https://hc2024.hotchips.org/assets/program/conference/day2/24_HC2024.AMD.Cohen.Subramony.final.pdf).
- **C2.** AMD, *Zen 5: The AMD High-Performance 4nm x86-64 Microprocessor Core*, ISSCC 2025, paper 2.1. [IEEE record](https://ieeexplore.ieee.org/abstract/document/10904529).
- **C3.** AMD, *EPYC 9005 Processor Architecture Overview*, publication 58462, April 2025. [Document record](https://docs.amd.com/v/u/en-US/58462_amd-epyc-9005-tg-architecture-overview); [PDF](https://docs.amd.com/api/khub/documents/iZ5eCtQ5v6PyPN7wEd8HQg/content).
- **C4.** AMD, fifth-generation EPYC launch, 10 October 2024. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1219/amd-launches-5th-gen-amd-epyc-cpus-maintaining-leadership-performance-and-features-for-the-modern-data-center).
- **C5.** AMD, *5th Gen AMD EPYC Processor Architecture*. [White paper](https://docs.amd.com/v/u/en-US/5th-gen-amd-epyc-processor-architecture-white-paper).
- **C6.** AMD, EPYC 9006 portfolio. [Product family](https://www.amd.com/en/products/processors/server/epyc/9006-series.html); [EPYC 9996 specifications](https://www.amd.com/en/products/processors/server/epyc/9006-series/amd-epyc-9996.html).
- **C7.** AMD, Taiwan ecosystem investments and Venice packaging, 21 May 2026. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1286/amd-announces-more-than-10-billion-in-taiwan-ecosystem-investments-to-accelerate-ai-infrastructure).
- **C8.** AMD, *AAI 2026: AMD Delivers Full-Stack Compute for the Agentic AI Era*, 23 July 2026. [Launch and roadmap](https://ir.amd.com/news-events/press-releases/detail/1294/aai-2026-amd-delivers-full-stack-compute-for-the-agentic-ai-era).
- **C9.** AMD, EPYC 4005 launch, 2025. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1249/amd-unveils-epyc-4005-series-processors-delivering-workload-optimized-solutions-for-entry-level-enterprise).
- **C10.** AMD, EPYC 8005 overview, 19 May 2026. [Product discussion](https://www.amd.com/en/blogs/2026/new-amd-epyc-8005-server-cpus-big-performance-low-power.html); [architecture document 72128](https://docs.amd.com/v/u/en-US/72128-amd-epyc-8005-processor-architecture-overview).
- **C11.** *Cloud-Hardware Co-Design for Memory Bandwidth-Bound HPC Workloads: Performance and Characteristics of Azure HBv5 Virtual Machines*, SCA/HPCAsia 2026. [DOI](https://doi.org/10.1145/3773656.3773684).
- **C12.** Microsoft, current Azure HBv5 VM specifications. [HBv5 documentation](https://learn.microsoft.com/en-us/azure/virtual-machines/sizes/high-performance-compute/hbv5-series).

## D. Early Instinct, CDNA and MI200

- **D1.** AMD, Radeon Instinct introduction, December 2016. [MI6/MI8/MI25 announcement](https://ir.amd.com/news-events/press-releases/detail/740/amd-introduces-radeon-instinct-accelerating-machine-intelligence).
- **D2.** Mike Mantor and Ben Sander, Vega architecture, Hot Chips 29, 2017. [Presentation](https://old.hotchips.org/wp-content/uploads/hc_archives/hc29/HC29.21-Monday-Pub/HC29.21.10-GPU-Gaming-Pub/HC29.21.120-Radeon-Vega10-Mantor-AMD-f1.pdf).
- **D3.** AMD, MI50/MI60 introduction, 6 November 2018. [Announcement](https://ir.amd.com/news-events/press-releases/detail/859/amd-unveils-worlds-first-7nm-datacenter-gpus----powering-the-next-era-of-artificial-intelligence-cloud-computing-and-high-performance-computing-hpc).
- **D4.** AMD, Next Horizon, 6 November 2018. [Event announcement](https://ir.amd.com/news-events/press-releases/detail/860/amd-takes-high-performance-datacenter-computing-to-the-next-horizon).
- **D5.** AMD, *CDNA Architecture*. [White paper](https://www.amd.com/content/dam/amd/en/documents/instinct-business-docs/white-papers/amd-cdna-white-paper.pdf).
- **D6.** AMD, MI100 introduction, 16 November 2020. [Announcement](https://ir.amd.com/news-events/press-releases/detail/981/amd-announces-worlds-fastest-hpc-accelerator-for-scientific-research); [product specifications](https://www.amd.com/en/products/accelerators/instinct/mi100.html).
- **D7.** AMD, *CDNA 2 Architecture*. [White paper](https://www.amd.com/content/dam/amd/en/documents/instinct-business-docs/white-papers/amd-cdna2-white-paper.pdf).
- **D8.** Alan Smith and Norman James, MI200 accelerator and node architectures, Hot Chips 34, 2022. [Presentation](https://hc34.hotchips.org/assets/program/conference/day1/GPU%20HPC/HC2022.AMD.AlanSmith.v14.Final.20220820.pdf).
- **D9.** AMD, MI200 launch, 8 November 2021. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1032/new-amd-instinct-mi200-series-accelerators-bring-leadership-hpc-and-ai-performance-to-power-exascale-systems-and-more).
- **D10.** Raja Swaminathan et al., *AMD Instinct MI250X Accelerator Enabled by Elevated Fanout Bridge Advanced Packaging Architecture*, VLSI 2023. [Author publication index](https://sites.google.com/site/lohgabe/pubs).

## E. MI300, MI325, MI350 and MI400

- **E1.** AMD, *CDNA 3 Architecture*. [White paper](https://www.amd.com/content/dam/amd/en/documents/instinct-tech-docs/white-papers/amd-cdna-3-white-paper.pdf).
- **E2.** AMD, *MI300 Series Modular Chiplet Package—HPC and AI Accelerator for Exa-Class Systems*, ISSCC 2024, paper 11.1. [IEEE record](https://ieeexplore.ieee.org/document/10454441/).
- **E3.** Alan Smith and Vamsi Alla, MI300X architecture, Hot Chips 2024. [Presentation](https://hc2024.hotchips.org/assets/program/conference/day1/23_HC2024.AMD.MI300X.ASmith(MI300X).v1.Final.20240817.pdf).
- **E4.** Alan Smith et al., MI300X packaging and architecture co-optimization, VLSI 2024. [Author publication index](https://sites.google.com/site/lohgabe/pubs).
- **E5.** *Interconnect Design for Heterogeneous Integration of Chiplets in AMD Instinct MI300X Accelerator*, IEEE Micro 45(1), 2025. [Author publication index](https://sites.google.com/site/lohgabe/pubs). This is a journal article.
- **E6.** AMD, MI300A/MI300X launch, 6 December 2023. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1173/amd-delivers-leadership-portfolio-of-data-center-ai-solutions-with-amd-instinct-mi300-series).
- **E7.** LLNL, El Capitan hardware. [Platform overview](https://hpc.llnl.gov/hardware/compute-platforms/el-capitan); [hardware guide](https://hpc.llnl.gov/documentation/user-guides/using-el-capitan-systems/hardware-overview).
- **E8.** LLNL, SC24 and El Capitan. [Conference account](https://www.llnl.gov/article/52166/GET).
- **E9.** AMD, MI325X launch, 10 October 2024. [Final product announcement](https://ir.amd.com/news-events/press-releases/detail/1220/amd-delivers-leadership-ai-performance-with-amd-instinct-mi325x-accelerators).
- **E10.** AMD, *CDNA 4 Architecture*. [White paper](https://www.amd.com/content/dam/amd/en/documents/instinct-tech-docs/white-papers/amd-cdna-4-architecture-whitepaper.pdf).
- **E11.** Michael Floyd and Michael Steffen, CDNA 4 / MI350 architecture and platforms, Hot Chips 2025. [Conference program](https://hc2025.hotchips.org/program/conference/).
- **E12.** Ramasamy Adaikkalavan et al., MI350 stacked 3 nm XCD / 6 nm IOD implementation, ISSCC 2026, paper 2.1. [DOI](https://doi.org/10.1109/ISSCC49663.2026.11409030); [conference program](https://www.isscc.org/s/ISSCC2026AdvanceProgram.pdf).
- **E13.** AMD, Advancing AI 2025, 12 June 2025. [MI350 and ecosystem announcement](https://ir.amd.com/news-events/press-releases/detail/1255/amd-unveils-vision-for-an-open-ai-ecosystem-detailing-new-silicon-software-and-systems-at-advancing-ai-2025).
- **E14.** AMD, MI350P. [Product page](https://www.amd.com/en/products/accelerators/instinct/mi350/mi350p.html); [technical deployment discussion](https://rocm.blogs.amd.com/artificial-intelligence/mlperf-inf-v6.1/README.html).
- **E15.** AMD, CDNA 5 architecture and enabled product features. [Architecture overview](https://www.amd.com/en/technologies/cdna.html).
- **E16.** AMD, MI455X. [Product specifications](https://www.amd.com/en/products/accelerators/instinct/mi400/mi455x.html); [MI400 family](https://www.amd.com/en/products/accelerators/instinct/mi400.html).
- **E17.** AMD, Helios. [Rack architecture and specifications](https://www.amd.com/en/products/rackscale-solutions/helios.html).
- **E18.** Alan Smith and Maiyuran Subramaniam, MI400 GPU architecture; Steve Scott, David Riddoch and Krishna Doddapaneni, MI400 system architecture, Hot Chips 2026. [Conference program](https://hc2026.hotchips.org/program/).
- **E19.** AMD ROCm, accelerator specifications and logical architecture resources. [GPU specification table](https://rocm.docs.amd.com/en/latest/reference/gpu-specs.html); [MI350 microarchitecture](https://rocm.docs.amd.com/en/docs-10.0.0/reference/gpu-arch/mi350.html).
- **E20.** AMD, accelerator product specification archive. [Product table](https://www.amd.com/en/products/specifications/accelerators.html).

## F. Academic research and design-methodology papers

- **F1.** Ajaykumar Kannan, Natalie Enright Jerger and Gabriel Loh, *Enabling Interposer-based Disintegration of Multi-core Processors*, MICRO 2015. [Author-hosted paper](https://www.eecg.toronto.edu/~enright/Kannan_MICRO48.pdf).
- **F2.** Akshay Vijayaraghavan et al., *Design and Analysis of an APU for Exascale Computing*, HPCA 2017. [Author-hosted paper](https://computermachines.org/joe/publications/pdfs/hpca2017_exascale_apu.pdf).
- **F3.** Anthony Gutierrez et al., *Lost in Abstraction: Pitfalls of Analyzing GPUs at the Intermediate Language Level*, HPCA 2018. [Author-hosted paper](https://www.mlebeane.com/files/papers/hpca_2017.pdf). The conference year is 2018 despite the PDF filename.
- **F4.** Jun Yin et al., *Modular Routing Design for Chiplet-based Systems*, ISCA 2018. [Author publication index](https://sites.google.com/site/lohgabe/pubs).
- **F5.** Jun Yin et al., *Experiences with ML-Driven Design: A NoC Case Study*, HPCA 2020, industrial track. [Author publication index](https://sites.google.com/site/lohgabe/pubs).
- **F6.** Jagadish Kotra and John Kalamatianos, *Improving the Utilization of Micro-operation Caches in x86 Processors*, MICRO 2020. [Author-hosted paper](https://jbk5155.github.io/publications/MICRO_2020.pdf).
- **F7.** Jagadish Kotra et al., *Increasing GPU Translation Reach by Leveraging Under-Utilized On-Chip Resources*, MICRO 2021. [Author-hosted paper](https://jbk5155.github.io/publications/MICRO_2021.pdf).
- **F8.** Gabriel Loh et al., *A Research Retrospective on AMD's Exascale Computing Journey*, ISCA 2023. [Author-hosted paper](https://computermachines.org/joe/publications/pdfs/isca2023_exascale.pdf).
- **F9.** Alan Smith et al., *Realizing the AMD Exascale Heterogeneous Processor Vision*, ISCA 2024, industry product paper. [Author-hosted paper](https://computermachines.org/joe/publications/pdfs/isca2024_exascale.pdf).
- **F10.** Suchita Pati et al., *T3: Transparent Tracking & Triggering for Fine-grained Overlap of Compute & Collectives*, ASPLOS 2024. [Author manuscript](https://arxiv.org/abs/2401.16677); [DOI](https://doi.org/10.1145/3620665.3640410).
- **F11.** Fabian Ritter and Sebastian Hack, *Explainable Port Mapping Inference with Sparse Performance Counters for AMD's Zen Architectures*, ASPLOS 2024. [Author-hosted paper](https://compilers.cs.uni-saarland.de/papers/ritter_port_mapping_zen.pdf).
- **F12.** Rishabh Jain et al., *Load and MLP-Aware Thread Orchestration for Recommendation Systems Inference on CPUs*, ASPLOS 2025. [Author institution record](https://pure.psu.edu/en/publications/load-and-mlp-aware-thread-orchestration-for-recommendation-system/); [conference program](https://www.asplos-conference.org/asplos2025/program.html).
- **F13.** AMD gem5 APU tutorial, ISCA 2018. [Tutorial archive](https://www.gem5.org/events/isca-2018).
- **F14.** Gabriel Loh et al., chiplet-integration studies at DATE 2021 and DATE 2023; AMD-affiliated integration research at DAC 2019. [Author publication index](https://sites.google.com/site/lohgabe/pubs).
- **F15.** John Wuu et al., *Coevolution of Chiplet Technology and Cache Architecture for AI and Compute*, IEDM 2024. [Author publication index](https://sites.google.com/site/lohgabe/pubs).

## G. Industry events, hyperscalers and adjacent product disclosures

- **G1.** AMD, EPYC branding at Financial Analyst Day, May 2017. [Announcement](https://ir.amd.com/news-events/press-releases/detail/766/amd-raises-expectations-for-server-performance-unveils-epyc-processor-brand-for-the-datacenter).
- **G2.** AMD, Financial Analyst Day 2022 strategy. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1078/amd-details-strategy-to-drive-next-phase-of-growth-across-300-billion-market-for-high-performance-and-adaptive-computing-solutions).
- **G3.** AMD, Accelerated Data Center Premiere, November 2021. [Event](https://ir.amd.com/news-events/press-releases/detail/1031/amd-unveils-workload-tailored-innovations-and-products-at-the-accelerated-data-center-premiere).
- **G4.** AMD, Computex 2024 keynote. [Presentation](https://www.amd.com/content/dam/amd/en/documents/corporate/events/computex-2024-keynote.pdf).
- **G5.** AMD, CES 2026. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1272/amd-and-its-partners-share-their-vision-for-ai-everywhere-for-everyone-at-ces-2026).
- **G6.** AMD, OCP 2025 Helios announcement. [Open-rack direction](https://ir.amd.com/news-events/press-releases/detail/1261/amd-showcases-helios-rack-scale-platform-built-on-the-open-compute-project-open-rack-for-ai-introduced-by-meta); [architecture discussion](https://www.amd.com/en/blogs/2025/how-amd-and-ocp-are-shaping-the-next-era-of-ai.html).
- **G7.** AMD, MWC 2024 ecosystem. [Telco and edge demonstrations](https://www.amd.com/en/blogs/2024/amd-expands-telco-partner-ecosystem-and-showcases-.html).
- **G8.** AWS, M6a launch at re:Invent, 29 November 2021. [Milan-based instances](https://aws.amazon.com/blogs/aws/new-amazon-ec2-m6a-instances-powered-by-3rd-gen-amd-epyc-processors/).
- **G9.** AWS re:Invent 2023, AMD-sponsored deployment session. [Presentation](https://d1.awsstatic.com/events/Summits/reinvent2023/BIZ210-S_Deploy-new-workloads-efficiently-without-additional-investments-sponsored-by-AMD.pdf).
- **G10.** AMD and Microsoft, Ignite 2023. [Azure CPU/GPU announcement](https://www.amd.com/en/newsroom/press-releases/2023-11-15-amd-brings-new-ai-and-compute-capabilities-to-micr.html).
- **G11.** Microsoft, Ignite 2024 Book of News. [HBv5 and other announcements](https://news.microsoft.com/ignite-2024-book-of-news/).
- **G12.** AMD, Microsoft Build 2024. [Azure MI300X availability](https://ir.amd.com/news-events/press-releases/detail/1198/amd-instinct-mi300x-accelerators-power-microsoft-azure-openai-service-workloads-and-new-azure-nd-mi300x-v5-vms).
- **G13.** AMD, Google Cloud Next, 9 April 2025. [Turin-powered C4D and H4D](https://ir.amd.com/news-events/press-releases/detail/1244/5th-gen-amd-epyc-processors-deliver-leadership-performance-for-google-cloud-c4d-and-h4d-virtual-machines).
- **G14.** NVIDIA, DGX A100 introduction at GTC 2020. [Announcement](https://nvidianews.nvidia.com/news/nvidia-ships-worlds-most-advanced-ai-system-nvidia-dgx-a100-to-fight-covid-19-third-generation-dgx-packs-record-5-petaflops-of-ai-performance); [system guide](https://docs.nvidia.com/dgx/dgxa100-user-guide/introduction-to-dgxa100.html).
- **G15.** DAC, keynote and technical-talk archive, including AMD's 2021, 2022 and 2025 speakers. [DACtv](https://archive.dac.com/media-center/dactv.html).
- **G16.** Hot Chips archives, including client APU and Radeon presentations. [Archive index](https://hotchips.org/archives/); [2020 program](https://hc32.hotchips.org/); [2022 program](https://hc34.hotchips.org/program/); [2023 program](https://hc2023.hotchips.org/program/).
- **G17.** ISSCC past-conference archive. [Programs and press materials](https://www.isscc.org/past-conferences). The 2020 program includes the RX 5700 implementation paper.
- **G18.** AMD, Zen architecture overview. [Core-generation context](https://www.amd.com/en/technologies/zen-core.html).

## H. Pensando DPU generations, software and deployments

- **H1.** AMD, completion of the Pensando acquisition, 26 May 2022. [Announcement](https://www.amd.com/en/newsroom/press-releases/2022-5-26-amd-expands-data-center-solutions-capabilities-wit.html).
- **H2.** Francis Matus, *Pensando Distributed Services Architecture*, Hot Chips 32, 18 August 2020. [Presentation](https://hc32.hotchips.org/assets/program/conference/day2/HotChips2020_Networking_Pensando_v3.pdf). Includes Capri/Elba process, memory, interfaces and processing organization.
- **H3.** Michael Galles and Francis Matus, *Pensando Distributed Services Architecture*, IEEE Micro 41(2), 43–49, 2021. [DOI](https://doi.org/10.1109/MM.2021.3058560). Journal companion, distinct from the MICRO conference.
- **H4.** AMD, *Second Generation Elba Data Processing Unit*, April 2024. [Product brief](https://www.amd.com/content/dam/amd/en/documents/pensando-technical-docs/product-briefs/pensando-elba-product-brief.pdf).
- **H5.** AMD, *Second Generation Plus Giglio Data Processing Unit*, April 2024. [Product brief](https://www.amd.com/content/dam/amd/en/documents/pensando-technical-docs/product-briefs/pensando-giglio-product-brief.pdf); [2023 roadmap announcement](https://ir.amd.com/news-events/press-releases/detail/1136/amd-expands-leadership-data-center-portfolio-with-new-epyc-cpus-and-shares-details-on-next-generation-amd-instinct-accelerator-and-software-enablement-for-generative-ai).
- **H6.** AMD, *Salina DPU*. [Product brief](https://www.amd.com/content/dam/amd/en/documents/pensando-technical-docs/product-briefs/pensando-salina-product-brief.pdf); [DPU portfolio and implementation footnotes](https://www.amd.com/en/products/data-processing-units/pensando.html).
- **H7.** AMD, *Pensando DPU Software*, 8 September 2023. [Software architecture](https://www.amd.com/en/blogs/2023/amd-pensando-dpu-software.html).
- **H8.** AMD, *Software-in-Silicon Development Kit*, November 2023. [SSDK brief](https://www.amd.com/content/dam/amd/en/documents/pensando-technical-docs/product-briefs/pensando-ssdk-product-brief.pdf); [Hello World guide](https://docs.amd.com/r/en-US/ug1669-amd-pensando-ssdk-hello-world-user-guide/Introduction).
- **H9.** AMD, *Architecture Matters: Performance of a Multi-Stage SDN Pipeline on Arm vs AMD Pensando Programmable Silicon*. [Architecture and performance report](https://www.amd.com/content/dam/amd/en/documents/pensando-technical-docs/white-papers/pensando-comparison-of-dpu-hardware-strategies.pdf). Vendor comparison; its benchmark claims are not used as general performance guarantees here.
- **H10.** Deepak Bansal et al., *Disaggregating Stateful Network Functions*, NSDI 2023. [Conference record](https://www.usenix.org/conference/nsdi23/presentation/bansal); [paper](https://www.usenix.org/system/files/nsdi23-bansal.pdf). Joint Microsoft–AMD Pensando Sirius design.
- **H11.** AMD, Pensando DSC and VMware vSphere 8, 30 August 2022. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1090/industry-leading-amd-pensando-dpus-enable-accelerated-data-centers-with-vmware-vsphere-8).
- **H12.** HPE, Pensando in distributed switch services. [CX 10000 deployment guide](https://www.hpe.com/psnow/doc/a50010559enw); [secure interconnect architecture](https://arubanetworking.hpe.com/techdocs/VSG/docs/040-dc-design/esp-dc-design-022-secure-dci/).
- **H13.** Cisco, N9300 Smart Switches, Cisco Live, February 2025. [Announcement](https://investor.cisco.com/files/doc_news/Cisco-Redefines-Data-Center-Architecture-with-New-Smart-Switches-Embedding-Services-Directly-into-the-Network-2025.pdf); [current data sheet](https://www.cisco.com/c/en/us/products/collateral/switches/9300-series-smart-switches/n9300-series-smart-switch-ds.html).
- **H14.** AMD and Oracle, AI and converged-networking partnership, 2025. [Announcement](https://newsroom.amd.com/news/oracle-and-amd-expand-partnership-to-help-customers-ach/).

## I. AI NICs, SmartNICs and Ethernet-adapter branches

- **I1.** AMD, *Pollara 400 AI NIC*. [Product brief](https://www.amd.com/content/dam/amd/en/documents/pensando-technical-docs/product-briefs/pollara-product-brief.pdf).
- **I2.** Kevin Chu, *AMD Pensando Pollara 400 AI NIC Architecture and Application*, Hot Chips 2025. [Presentation](https://hc2025.hotchips.org/assets/program/conference/day1/HC%20Pollara%20400%20Final%2020250824.pdf).
- **I3.** AMD, Pollara purchase availability, 9 April 2025. [Scale-out networking announcement](https://www.amd.com/en/blogs/2025/powering-next-gen-ai-infrastructure--a-new-era-of.html). The October 2024 introduction is also covered by reference E9.
- **I4.** AMD, *Vulcano 800 AI NIC*. [Product brief, including adapter and four-/six-NIC board configurations](https://www.amd.com/content/dam/amd/en/documents/pensando-business-docs/product-brief/amd-vulcano-ai-nic-networking-product-brief.pdf).
- **I5.** AMD, *Vulcano 800 AI NIC: Built to Scale-Out and Across*, 23 July 2026. [Architecture and deployment discussion](https://www.amd.com/en/blogs/2026/amd-pensando-vulcano-800-ai-nic-scale-out-and-across.html); [current AI NIC portfolio](https://www.amd.com/en/products/network-interface-cards/pensando.html).
- **I6.** AMD, *400G Adaptive SmartNIC SoC*, Hot Chips 34, 23 August 2022. [Presentation](https://www.hc34.hotchips.org/assets/program/conference/day2/Network%20and%20Switches/Hotchips2022%20AMD%20400G%20Adaptive%20SmartNIC%20SoC%20-%20Final%20for%20Distribution.pdf).
- **I7.** AMD, *Alveo SN1000 SmartNICs*. [Product brief](https://www.amd.com/content/dam/amd/en/documents/products/accelerators/alveo/sn1000/alveo-sn1000-product-brief.pdf); [product page and new-design guidance](https://www.amd.com/en/products/accelerators/alveo/sn1000/a-sn1022-p4.html).
- **I8.** AMD, *Alveo U45N Network Accelerator*. [Product and development resources](https://www.amd.com/en/products/accelerators/alveo/u45n/a-u45n-p08g-pq-g.html); [adaptive network-acceleration overview](https://www.amd.com/content/dam/amd/en/documents/products/accelerators/alveo/adaptive-smartnic-white-paper.pdf).
- **I9.** AMD, Solarflare/Alveo adapter lineage. [X3 product page](https://www.amd.com/en/products/ethernet-adapters/solarflare-x3.html); [X3 migration guide](https://docs.amd.com/r/en-US/ug1523-x3522-user/X3-Migration-Quickstart); [X4 migration guide](https://docs.amd.com/api/khub/documents/YUDpjop2UySM2YKb5ryPcA/content).
- **I10.** AMD, *Solarflare X4 Series*. [Product brief](https://www.amd.com/content/dam/amd/en/documents/products/ethernet-adapters/x4-series-product-brief.pdf); [product page](https://www.amd.com/en/products/ethernet-adapters/solarflare-x4.html).

## J. Alveo, Versal, media and embedded product lines

- **J1.** AMD, Alveo portfolio. [Current product map](https://www.amd.com/en/products/accelerators/alveo.html); [historical platform guide, UG1120](https://docs.amd.com/r/en-US/ug1120-alveo-platforms/Alveo-Platforms).
- **J2.** AMD, *Alveo V80 Compute Accelerator*, 2024. [Product brief](https://www.amd.com/content/dam/amd/en/documents/products/accelerators/alveo/v80/alveo-v80-product-brief.pdf); [development and product overview](https://www.amd.com/en/products/accelerators/alveo/v80.html).
- **J3.** AMD, Alveo V70. [Product specifications and discontinuation notice](https://www.amd.com/en/products/accelerators/alveo/v70/a-v70-p16g-pq-g.html); [CES 2023 introduction](https://ir.amd.com/news-events/press-releases/detail/1109/amd-highlights-future-of-high-performance-and-adaptive-computing-during-opening-keynote-of-ces-2023).
- **J4.** AMD, Alveo MA35D, 6 April 2023. [Launch](https://ir.amd.com/news-events/press-releases/detail/1122/amd-launches-first-5nm-asic-based-media-accelerator-card-to-power-new-era-of-interactive-media-services-at-scale); [product brief](https://www.amd.com/content/dam/amd/en/documents/products/accelerators/alveo/ma35d/1978700-alveo-ma35d-product-brief.pdf); [media portfolio](https://www.amd.com/en/solutions/media-and-entertainment/video-transcoding.html).
- **J5.** Sagheer Ahmad and Sridhar Subramanian, Xilinx Versal / AI Engine, Hot Chips 2019. [Presentation](https://old.hotchips.org/hc31/HC31_2.5_Xilinx_Versal_Hotchips31_Final_v2.pdf).
- **J6.** Prasun K. Raha et al., *A Versatile 7nm Adaptive Compute Acceleration Platform Processor*, ISSCC 2020, paper 8.2, pp. 146–148. [DOI](https://doi.org/10.1109/ISSCC19947.2020.9062974); [conference program](https://www.mics.caltech.edu/wp-content/uploads/2019/12/ISSCC2020AdvanceProgram.pdf).
- **J7.** Xilinx, Versal Premium at Hot Chips 2020 and AI Edge at Hot Chips 2021. [2020 program](https://www.hc32.hotchips.org/); [2021 presentation](https://hc33.hotchips.org/assets/program/conference/day2/XilinxHotChips2021-v0.90-final.pdf).
- **J8.** AMD, Versal series organization. [Family map](https://www.amd.com/en/products/adaptive-socs-and-fpgas/versal.html); [series comparison, UG1273](https://docs.amd.com/r/en-US/ug1273-versal-acap-design/Series-Comparison).
- **J9.** AMD, Versal Premium Gen 2. [Product architecture](https://www.amd.com/en/products/adaptive-socs-and-fpgas/versal/gen2/premium-series.html); [2024 introduction](https://www.amd.com/en/newsroom/press-releases/2024-11-12-amd-announces-versal-premium-series-gen-2-enabling.html); [Memory on Package announcement and schedules, June 2026](https://www.amd.com/en/blogs/2026/amd-packs-more-memory-capacity--performance-in-a-smalle.html).
- **J10.** AMD, EPYC Embedded. [Family and platform map](https://www.amd.com/en/products/embedded/epyc.html); [9005 announcement, March 2025](https://ir.amd.com/news-events/press-releases/detail/1239/amd-unveils-5th-gen-amd-epyc-embedded-processors-delivering-leadership-performance-efficiency-and-long-product-lifecycles-for-networking-storage-and-industrial-edge-markets).
- **J11.** AMD, Kria portfolio. [K24 introduction, September 2023](https://www.amd.com/en/newsroom/press-releases/2023-9-19-amd-accelerates-innovation-at-the-edge-with-kria-k.html); [Kria AI SOM and robotics platform, 2026](https://www.amd.com/en/products/system-on-modules/kria/ai.html).
- **J12.** AMD, Radeon AI PRO R9700 and workstation products, Computex 2025. [Announcement](https://ir.amd.com/news-events/press-releases/detail/1253/amd-introduces-new-radeon-graphics-cards-and-ryzen-threadripper-processors-at-computex-2025); [R9700 specifications](https://www.amd.com/en/products/graphics/workstations/radeon-ai-pro/ai-9000-series/amd-radeon-ai-pro-r9700.html).
- **J13.** AMD, completed Xilinx acquisition, February 2022. [Company filing recording the closing dates of Xilinx and Pensando](https://ir.amd.com/financial-information/sec-filings/content/0001193125-22-168907/0001193125-22-168907.pdf).

## K. Full-stack platforms, interconnect and software

- **K1.** AMD, Advancing AI 2026 portfolio launch, 23 July 2026. [EPYC, Instinct, Helios and physical-AI announcement](https://ir.amd.com/news-events/press-releases/detail/1294/aai-2026-amd-delivers-full-stack-compute-for-the-agentic-ai-era).
- **K2.** AMD, *AI Networking Built for Scale*, 23 July 2026. [Salina, UALoE, Vulcano and fabric software](https://www.amd.com/en/blogs/2026/ai-networking-built-for-scale.html).
- **K3.** AMD ROCm, *Introducing AMD CDNA 5 and the AMD Helios Rackscale Solution*, 4 August 2026. [Architecture and topology](https://rocm.blogs.amd.com/ecosystems-and-partners/cdna5-helios/README.html).
- **K4.** AMD and HPE, rack-scale collaboration, December 2025. [UALoE switch ecosystem](https://ir.amd.com/news-events/press-releases/detail/1269/amd-and-hpe-expand-collaboration-to-advance-open-rack-scale-ai-infrastructure); AMD/Broadcom, Advancing AI 2026, [Ethernet scale-up session](https://www.amd.com/en/corporate/events/advancing-ai/sessions-catalog/ethernet-scale-up-networking-for-next-generation-ai-workloads.html).
- **K5.** AMD, ROCm software and SDK. [Platform overview](https://www.amd.com/en/products/software/rocm.html); [technical documentation](https://rocm.docs.amd.com/en/latest/).
- **K6.** AMD, *ROCm 10: Bringing ROCm.AI's AI-Native Developer Experiences to AMD Platforms*, 27 August 2026. [Release discussion](https://newsroom.amd.com/news/rocm-10-software-ai-native-developer-experiences/).
- **K7.** AMD, Enterprise AI Reference Stack. [Platform components](https://www.amd.com/en/products/software/enterprise-ai-reference-stack.html); [solution-blueprint documentation](https://enterprise-ai.docs.amd.com/en/latest/solution-blueprints/overview.html).
- **K8.** AMD, Vitis AI. [Current documentation](https://vitisai.docs.amd.com/en/latest/index.html); [historical deep-learning processing unit architecture](https://xilinx.github.io/Vitis-AI/3.0/html/docs/workflow-system-integration.html); [NPU transition documentation](https://vitisai.docs.amd.com/en/5.1/).
- **K9.** AMD, Onload software. [Supported adapter families](https://docs.amd.com/r/en-US/ug1586-onload-user/Supported-Network-Adapters).

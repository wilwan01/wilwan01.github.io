"""Supplementary, source-keyed tables for the AMD framework revision."""
import json
from data import table,add,TABLES,ROOT
REFS=json.loads((ROOT/'references_original.json').read_text())
EXTRA={r['key']:r for r in json.loads((ROOT/'references_extra.json').read_text())}

table('Core_detail','Core | Front end and dispatch | Execution window | Load/store and vector | Local caches | Sources')
core_rows=[
('Zen','32 B fetch; 4 x86 decode; 6 micro-op dispatch','192-entry retire queue; SMT2; 72-load / 44-store queues','2 loads + 1 store resources; 128-bit FP','64 KB I; 32 KB D; 512 KB L2; 8 MB L3/4 cores','A1 A3'),
('Zen 2','Larger op cache and improved prediction; 6-wide dispatch','224-entry ROB in Zen 3 comparative disclosure','256-bit FP; baseline 2 loads/1 store per cycle','32 KB I; 32 KB D; 512 KB L2; 16 MB L3/4 cores','A5 A6 B2'),
('Zen 3','4-decode / up to 8 op-cache ops; 6 macro-op dispatch','256-entry ROB; larger integer/FP issue capacity','3 loads/2 stores; 256-bit FP; FMA latency 4 cycles','32 KB I; 32 KB D; 512 KB L2; 32 MB L3/8 cores','B1 B2 B3'),
('Zen 4 / 4c','Larger op cache; improved branch prediction and dispatch','Retire and load/store queues enlarged; numeric sizes n/d in reviewed slides','AVX-512 on 256-bit resources; BF16/VNNI','32 KB I; 32 KB D; 1 MB L2; L3 32/16 MB per 8-core CCX','B8 B9 B10'),
('Zen 5 server','2 x32 B fetch; 2 x4 decode; 6K op cache; 8-wide dispatch','ROB 448 entries 1T / 224 per thread 2T; 240 integer physical registers','6 ALU, 4 AGU; 4 memory addresses/cycle; 2 x512-bit loads or 1 x512-bit store capacity','32 KB I; 48 KB 12-way D, 4-cycle load-to-use; 1 MB 16-way L2','C1 C2 C3'),
('Zen 6 / 6c','n/d in reviewed public technical record','n/d','n/d; avoid deriving ISA from branding','9996 package L3 1024 MB; private caches and sharing topology n/d','C8 N30 N31'),
]
for r in core_rows:add('Core_detail',r,r[-1],'2016-2026','Widths describe the cited implementation; operations and x86 instructions are not interchangeable')

table('GPU_local_memory','Architecture | Execution and matrix change | LDS per CU | Vector L1 | L2 / memory-side cache | Sources')
for r in [
('CDNA / MI100','Wave64; MFMA matrix operations; BF16 peak differs from FP16','64 KB','16 KB','8 MB L2 per GPU','D5 N27 E19'),
('CDNA 2 / MI200','Wave64; adds FP64 matrix execution; MI250X has 2 GPU devices','64 KB','16 KB','8 MB L2 per GCD; 16 MB per MI250X package','D7 D8 N26 E19'),
('CDNA 3 / MI300','Wave64; FP8 E4M3/E5M2; one logical device can span XCDs','64 KB','32 KB','4 MB L2/XCD; 256 MB Infinity Cache/package','E1 E3 N25 E19'),
('CDNA 4 / MI350','Wave64; MXFP8/6/4; direct global-to-LDS path; native TF32 replaced by BF16-based software path','160 KB','32 KB','4 MB L2/XCD; 256 MB Infinity Cache for X, 128 MB for P','E10 N24 E19'),
('CDNA 5 / MI455X','Wave32 WGPs; Tensor Data Mover, L2 multicast and WGP cooperation','n/d here; WGP scope differs','n/d here','192 MB global L2 on two fabric/cache dies','E15 K3 N14'),
]:add('GPU_local_memory',r,r[-1],'2020-2026','Do not compare CU and WGP counts as identical structures')

table('Availability','Product | First material disclosure | Commercial / GA milestone | Status at cutoff | Sources')
for r in [
('EPYC 7001','Zen at HC2016; EPYC branding May 2017','2017-06-20 launch with partner systems','Shipping; historical GA','A1 G1 N4'),
('EPYC 7002','Next Horizon, 2018-11-06','2019-08-07 launch','Shipping; historical GA','D4 A8'),
('Milan / Milan-X','Zen 3 in 2020; Milan-X preview Nov 2021','Milan 2021-03-15; Milan-X 2022-03-21','Shipping; historical GA','B2 B3 B6 G3'),
('Genoa / Bergamo / Siena','FAD and launch disclosures 2022-2023','Genoa Nov 2022; Bergamo/Genoa-X Jun 2023; Siena Sep 2023','Shipping','G2 B12 B13 B14'),
('Turin','Computex preview, June 2024','2024-10-10 launch and availability','Shipping','G4 C4'),
('Sorano / EPYC 8005','2026 product disclosure','Launch 2026-05-19; exact independent GA day n/d','Shipping; current portfolio','C10 N45 N46'),
('Venice / EPYC 9006','Earlier roadmap; production ramp 2026-05-21','Launch 2026-07-23; broad GA date n/d','Sampling or limited availability','N23 C8 N30'),
('Radeon Instinct MI6/8/25','2016-12 announcement','2017 product generation','Shipping; historical GA','D1 D2'),
('MI50 / MI60','2018-11-06 Next Horizon','Late 2018-2019, SKU-dependent','Shipping; historical GA','D3 D4'),
('MI100','2020-11-16','November 2020 platform introduction','Shipping; historical GA','D6 N5'),
('MI250 / MI250X / MI210','MI200 launch 2021-11-08','MI200 in 2021 systems; MI210 2022-03-22','Shipping; system-specific availability','D9 N6 N7'),
('MI300A / MI300X','MI300 CES 2023; MI300X June 2023','2023-12-06 launch; Azure MI300X GA May 2024','Shipping','B13 E6 G12'),
('MI325X','Computex June 2024: 288 GB preview','Final 256 GB Oct 2024; Q4 production, OEM expansion Q1 2025','Shipping','N35 E9'),
('MI350X / MI355X','Roadmap 2024; product details 2025','Advancing AI 2025-06-12','Shipping','N35 E13'),
('MI350P','Detailed AMD blog 2026-05-07','2026 PCIe systems; exact GA day n/d; featured again July','Shipping','N40 N13 C8'),
('MI308','MI300 regional branch; earlier specifications not established here','Licensed shipments resumed end FY2025','Sampling or limited availability, license-dependent','N16'),
('MI455X / Helios','Helios preview Jun 2025; OCP Oct 2025','Production/launch announced Jul 2026; customer rollout varies','Sampling or limited availability','E13 G6 C8 N41'),
('Capri / Elba','First silicon 2018 / 2020; HC2020','Capri historical; Elba deployed commercially by 2022','Shipping; first GA dates n/d','H2 H11'),
('Giglio / Salina','June 2023 / October 2024','2023-2026 portfolio and partner deployments','Shipping; exact GA dates n/d','H5 H6 H13'),
('Pollara 400','Advancing AI, 2024-10-10','Purchase availability 2025-04-09','Shipping','E9 I3'),
('Vulcano 800','Helios roadmap 2025; detailed 2026','2026 introduction; broad adapter GA date n/d','Sampling or limited availability','E13 I4 I5'),
]:add('Availability',r,r[-1],'through 2026-09-27','Disclosure and launch are not automatically broad GA')

table('Acquisitions','Lineage | Transaction milestone | What is in scope | Sources')
for r in [
('Solarflare → Xilinx → AMD','Xilinx acquired Solarflare in July 2019','Low-latency NIC and Onload ancestry, including pre-AMD generations','N44 I9 I10'),
('Xilinx → AMD','AMD completed acquisition 2022-02-14','UltraScale+, Versal, Alveo, Zynq, Kria and adaptive tools','J13'),
('Pensando → AMD','AMD completed acquisition 2022-05-26','Pre-acquisition Capri/Elba and AMD-era DPU/AI NIC successors','H1 H2'),
('Nod.ai / Silo AI → AMD','Nod.ai completed Oct 2023; Silo AI completed Aug 2024','Compiler/software expertise and model development/deployment capability','N51 N52'),
('ZT Systems → AMD / Sanmina','AMD close 2025-03-31; manufacturing sale closed 2025-10-27','AMD retained system design; Sanmina took manufacturing operations','N43 N21'),
]:add('Acquisitions',r,r[-1],'2019-2025','Transaction completion, not announcement, determines ownership boundary')

table('Conference_index','Venue | Year | Paper or talk | Presenters (if known) | Product/generation | Disclosure type (architecture / circuit and implementation / packaging / system / related research) | Link')
conf=[
('Hot Chips','2016','A New, High Performance x86 Core Design from AMD','Michael Clark','Zen / Naples','architecture','A1'),
('Hot Chips','2017','Next Generation AMD Enterprise Server Product Architecture','Kevin Lepak','EPYC 7001 / Naples','architecture','A2'),
('Hot Chips','2017','Radeon Vega architecture','Mike Mantor; Ben Sander','Vega / MI25 ancestry','architecture','D2'),
('Hot Chips','2019','Zen 2','AMD','Rome; Ryzen chiplets','architecture','A5'),
('Hot Chips','2019','Versal and AI Engine architecture','Sagheer Ahmad; Sridhar Subramanian','Versal VC1902','architecture','J5'),
('Hot Chips','2020','Pensando Distributed Services Architecture','Francis Matus','Capri / Elba','architecture','H2'),
('Hot Chips','2020','Versal Premium','Xilinx','Versal Premium','architecture','J7'),
('Hot Chips','2021','Zen 3 architecture','Mark Evers','Milan','architecture','B1'),
('Hot Chips','2021','Advanced packaging tutorial','Raja Swaminathan','Chiplets / V-Cache','packaging','B5'),
('Hot Chips','2021','Versal AI Edge','Xilinx','Versal AI Edge','architecture','J7'),
('Hot Chips','2022','MI200 accelerator and node architectures','Alan Smith; Norman James','MI250X / Frontier','architecture / system','D8'),
('Hot Chips','2022','400G Adaptive SmartNIC SoC','AMD','Adaptive SmartNIC research/product SoC','architecture','I6'),
('Hot Chips','2023','Zen 4 EPYC family processor architecture','Kai Troester; Ravi Bhargava','Genoa / Bergamo / Siena','architecture','B8'),
('Hot Chips','2024','Next Generation Zen 5 Core','Brad Cohen; Mahesh Subramony','Turin and shared client cores','architecture','C1'),
('Hot Chips','2024','MI300X architecture','Alan Smith; Vamsi Alla','MI300X','architecture / packaging','E3'),
('Hot Chips','2025','CDNA 4 / MI350 architecture and platforms','Michael Floyd; Michael Steffen','MI350X / MI355X','architecture / system','E11'),
('Hot Chips','2025','Pollara 400 AI NIC Architecture and Application','Kevin Chu','Pollara 400','architecture','I2'),
('Hot Chips','2026','MI400 GPU architecture','Alan Smith; Maiyuran Subramaniam','MI455X / CDNA 5','architecture','E18'),
('Hot Chips','2026','MI400 system architecture','Steve Scott; David Riddoch; Krishna Doddapaneni','Helios','system','E18'),
('ISSCC / JSSC','2017','Zen core implementation; expanded JSSC treatment','Teja Singh et al.','Zen','circuit and implementation','A3'),
('ISSCC','2018','Zeppelin: An SoC for Multichip Architectures, 2.4','Noah Beck et al.','Naples / Ryzen / Threadripper','circuit and implementation','A4'),
('ISSCC','2020','Zen 2 core and chiplet architecture, 2.1 / 2.2','AMD','Rome / Ryzen','circuit and implementation / packaging','A6'),
('ISSCC','2020','A Versatile 7nm Adaptive Compute Acceleration Platform Processor, 8.2','Prasun K. Raha et al.','Versal','circuit and implementation','J6'),
('ISSCC','2022','Zen 3: AMD 2nd-Generation 7nm x86-64 Microprocessor Core, 2.7','Thomas Burd et al.','Milan / Ryzen 5000','circuit and implementation','B2'),
('ISSCC','2022','3D V-Cache: Hybrid-Bonded 64MB Stacked Cache, 26.4','John Wuu et al.','Milan-X / Ryzen X3D','packaging','B4'),
('ISSCC','2023','Zen 4: AMD 5nm 5.7GHz x86-64 Microprocessor Core','Benjamin Munger et al.','Zen 4 core implementation','circuit and implementation','B9'),
('ISSCC','2024','Zen 4c: AMD 5nm Area-Optimized x86-64 Microprocessor Core, 2.2','Thomas Burd et al.','Bergamo / Siena','circuit and implementation','B10'),
('ISSCC','2024','MI300 Series Modular Chiplet Package, 11.1','AMD','MI300A / MI300X','packaging','E2'),
('ISSCC','2025','Zen 5: AMD High-Performance 4nm x86-64 Microprocessor Core, 2.1','AMD','Zen 5 / Turin','circuit and implementation','C2'),
('ISSCC','2026','MI350 GPUs: CDNA 4-Based 3D-Stacked 3nm XCDs and 6nm IODs, 2.1','Ramasamy Adaikkalavan et al.','MI350','circuit and implementation / packaging','E12'),
('ISCA','2018','Modular Routing Design for Chiplet-based Systems','Jun Yin et al.','Chiplet networks; no SKU attribution','related research','F4'),
('ISCA','2018','gem5 APU tutorial','AMD','GPU/CPU simulation','related research','F13'),
('ISCA','2021','Pioneering Chiplet Technology and Design for EPYC and Ryzen','Samuel Naffziger et al.','Naples / Rome / Ryzen','architecture / packaging','A7'),
('ISCA','2023',"A Research Retrospective on AMD's Exascale Computing Journey",'Gabriel Loh et al.','Frontier / exascale co-design','system','F8'),
('ISCA','2024','Realizing the AMD Exascale Heterogeneous Processor Vision','Alan Smith et al.','MI300A','architecture / packaging','F9'),
('ISCA','2026','SPEC CPU: The Next Generation','Mahesh Madhav et al.; AMD coauthors','Cross-industry benchmark methodology','related research','N53'),
('ISCA','2026','PowerGrad: Hierarchical Power Management for Power-Limited ML Inference Clusters','Hyoungwook Nam et al.; Aporva Amarnath (AMD)','Power-management research; no SKU attribution','related research','N53'),
('ISCA','2026','Lit Silicon: A Case Where Thermal Imbalance Couples Concurrent Execution in Multiple GPUs','Marco Kurzynski; Shaizeen Aga; Di Wu','Thermal-coupling research; program record','related research','N53'),
('HPCA','2026','Architecting Resilience at Scale: From Research to Practice','Sudhanva Gurumurthi (AMD)','Resilience keynote; no new SKU implied','related research','N54'),
('MICRO','2015','Enabling Interposer-based Disintegration of Multi-core Processors','Ajaykumar Kannan; Natalie Enright Jerger; Gabriel Loh','Chiplet design space','related research','F1'),
('MICRO','2020','Improving the Utilization of Micro-operation Caches in x86 Processors','Jagadish Kotra; John Kalamatianos','Zen-relevant research; no SKU attribution','related research','F6'),
('MICRO','2021','Increasing GPU Translation Reach by Leveraging Under-Utilized On-Chip Resources','Jagadish Kotra et al.','GPU translation; no SKU attribution','related research','F7'),
('HPCA','2017','Design and Analysis of an APU for Exascale Computing','Akshay Vijayaraghavan et al.','Research predecessor to integrated APU','related research','F2'),
('HPCA','2018','Lost in Abstraction: Pitfalls of Analyzing GPUs at the Intermediate Language Level','Anthony Gutierrez et al.','GPU simulation methodology','related research','F3'),
('HPCA','2020','Experiences with ML-Driven Design: A NoC Case Study','Jun Yin et al.','Network design exploration','related research','F5'),
('ASPLOS','2024','T3: Transparent Tracking & Triggering for Fine-grained Overlap of Compute & Collectives','Suchita Pati et al.','Compute/collective overlap; no SKU attribution','related research','F10'),
('ASPLOS','2024','Explainable Port Mapping Inference with Sparse Performance Counters for AMD Zen','Fabian Ritter; Sebastian Hack','Independent Zen characterization','related research','F11'),
('ASPLOS','2025','Load and MLP-Aware Thread Orchestration for Recommendation Systems Inference on CPUs','Rishabh Jain et al.','Chiplet CPU workload scheduling','related research','F12'),
('VLSI','2023','MI250X Enabled by Elevated Fanout Bridge Advanced Packaging Architecture','Raja Swaminathan et al.','MI250X','packaging','D10'),
('VLSI','2024','MI300X packaging and architecture co-optimization','Alan Smith et al.','MI300X','packaging','E4'),
('IEDM','2024','Coevolution of Chiplet Technology and Cache Architecture for AI and Compute','John Wuu et al.','CPU/GPU integration','packaging','F15'),
('ISPASS','2022','Memory Performance of AMD EPYC Rome and Intel Cascade Lake SP','Velten et al.','Independent Rome measurements','related research','A10'),
('NSDI','2023','Disaggregating Stateful Network Functions','Deepak Bansal et al.','Sirius / Pensando DSC','system','H10'),
('SCA/HPCAsia','2026','Cloud-Hardware Co-Design for Memory Bandwidth-Bound HPC: Azure HBv5','Microsoft/AMD collaboration','Custom EPYC with HBM','system','C11'),
('DAC / DATE','2019-2025','Chiplet-integration research and design-methodology keynotes','AMD-affiliated authors; Mark Papermaster; Michaela Blott','Cross-portfolio; archive-level leads','related research','F14 G15'),
('AMD FAD','2017 / 2022','EPYC branding; CPU/GPU/adaptive strategy','AMD','EPYC / CDNA roadmap','architecture / system','G1 G2'),
('Next Horizon','2018','Rome preview and MI50/MI60 launch','AMD','Rome / Vega 20','architecture / system','D4'),
('AMD Data Center Premiere','2021','MI200 launch and Milan-X direction','AMD','MI200 / Milan-X','architecture / system','G3'),
('AMD Data Center and AI Premiere','2023','Bergamo, Genoa-X and MI300X preview','AMD','EPYC 9004 / MI300X','architecture / system','B13'),
('Advancing AI','2023','MI300 launch','AMD','MI300A/X / ROCm 6','architecture / system','E6 N36'),
('Advancing AI','2024','Turin, MI325X, Salina and Pollara introduction','AMD','CPU / accelerator / network','architecture / system','C4 E9'),
('Advancing AI','2025','MI350 and open ecosystem; Helios preview','AMD','MI350 / Helios roadmap','architecture / system','E13'),
('Advancing AI','2026','Full-stack compute for agentic AI','AMD and partners','Venice / MI455X / Helios / Vulcano','architecture / system','C8'),
('Computex','2021 / 2024 / 2025','V-Cache demo; Zen 5 and Instinct roadmap; Radeon AI PRO','AMD','Shared technology and product branches','architecture / system','B7 G4 J12'),
('CES','2026','AI everywhere and Helios preview','AMD and partners','MI400 and client/edge platforms','system','G5'),
('OCP Global Summit','2025','Helios and Open Rack for AI','AMD / Meta ecosystem','Helios mechanical/electrical integration','system','G6'),
('MWC','2024','Telco and edge demonstrations','AMD and partners','Siena / adaptive edge','system','G7'),
('AWS re:Invent','2021 / 2023','M6a launch; workload deployment session','AWS / AMD','Milan and EPYC cloud systems','system','G8 G9'),
('Microsoft Ignite / Build','2023 / 2024','MI300X preview and GA; HBv5 announcement','Microsoft / AMD','MI300X / custom EPYC','system','G10 G11 G12'),
('Google Cloud Next','2025','C4D and H4D','Google / AMD','Turin cloud deployment','system','G13'),
('NVIDIA GTC','2020','DGX A100 introduction','NVIDIA','EPYC 7742 as accelerator host','system','G14'),
('SC / ISC','2020-2024','MI100 launch period; Frontier and El Capitan milestones','AMD / ORNL / LLNL / HPE','Complete HPC systems','system','D6 F8 E8'),
('VMware Explore','2022','vSphere 8 and Distributed Services Engine','VMware / AMD','Pensando DSC','system','H11'),
('Cisco Live','2025','N9300 Smart Switches','Cisco','Pensando-enabled switch services','system','H13'),
('Oracle cloud events','2025','AI and converged-networking partnership','Oracle / AMD','Pensando and cloud infrastructure','system','H14'),
]
for venue,year,title,presenter,product,kind,keys in conf:
    urls=[]
    for key in keys.split():
        u=REFS[key]['urls'][0] if key in REFS else EXTRA[key]['url']
        urls.append(f'[{key}]({u})')
    add('Conference_index',[venue,year,title,presenter,product,kind,'; '.join(urls)],keys,year,'Source version identified in bibliography; research rows do not assert product implementation')

table('Codename_crosswalk','Codename | Marketing family / example product | Architecture / role | Sources')
for r in [
('Zeppelin / Naples','EPYC 7001; 7601','Zen; die name / server platform','A2 A4'),
('Rome','EPYC 7002; 7742 / 7H12','Zen 2','A8 A9'),
('Milan / Milan-X','EPYC 7003; 7763 / 7773X','Zen 3 / stacked-cache branch','B3 B6'),
('Genoa / Genoa-X','EPYC 9004; 9654 / 9684X','Zen 4 / stacked-cache branch','B11 B12 B13'),
('Bergamo','EPYC 97x4; 9754','Zen 4c cloud density','B8 B13'),
('Siena','EPYC 8004; 8534P','Zen 4c on SP6','B14'),
('Turin / Turin Dense','EPYC 9005; 9755 / 9965','Zen 5 / Zen 5c','C3 N1 N2'),
('Grado','EPYC 4005; 4565P / 4585PX','Zen 5 on AM5','C9 N50'),
('Sorano','EPYC 8005; 8635P','Zen 5-based on SP6','N39 N45'),
('Venice','EPYC 9006; 9996 reference','Zen 6/6c family; SP7/SP8 branches','C8 N30 N31'),
('Verano','Future EPYC / Helios 500 host','2027 LPDDR-integrated host roadmap','N22 N23 C8'),
('Florence / Ferrara / Fidenza','Future EPYC roadmap','Zen 7 generation announced for 2028; Ferrara in Helios 600','C8'),
('Ravenna','Future EPYC roadmap','Zen 8 roadmap, 2030','C8'),
('Polaris / Fiji / Vega 10','Radeon Instinct MI6 / MI8 / MI25','GCN graphics-derived compute','D1 D2'),
('Vega 20','Radeon Instinct MI50 / MI60','7nm GCN compute','D3'),
('Arcturus','Instinct MI100','CDNA; gfx908','D5 E19'),
('Aldebaran','Instinct MI210 / MI250 / MI250X','CDNA 2; gfx90a','D7 E19'),
('MI300 series','Instinct MI300A / MI300X / MI325X','CDNA 3; gfx942; A adds Zen 4','E1 E19'),
('MI350 series','Instinct MI350X / MI355X / MI350P','CDNA 4; gfx950','E10 E19'),
('MI400 series','Instinct MI455X; future MI430X','CDNA 5; AI and HPC branches','E15 E16'),
('Capri / Elba / Giglio / Salina','Pensando DPU generations','Infrastructure services processors','H2 H4 H5 H6'),
('Pollara','Pensando Pollara 400','400G AI NIC','I1 I2'),
('Vulcano','Pensando Vulcano 800','800G AI NIC','I4 I5'),
('Como / Monza','Future Helios 500 networking','2027 roadmap; product details n/d','C8'),
('Palma / Levanzo','Future Helios 600 networking','2028 roadmap; product details n/d','C8'),
('Helios / Helios 500 / Helios 600','Rack platform generations','MI400 / MI500 / MI600 platforms','C8 E17'),
('XCU26','Alveo SN1022 / U45N','16nm UltraScale+ FPGA with discrete Arm complex','I7 I8'),
('XCUX35','Alveo X3522 / X3522PV','UltraScale+ low-latency NIC / programmable variant','N49'),
('VC1902','Versal AI Core','7nm adaptive SoC and AI Engine array','J5 J6'),
('Versal HBM','Alveo V80','Adaptive accelerator with HBM2e','J2 J8'),
]:add('Codename_crosswalk',r,r[-1],'through 2026-09-27','Chip, architecture, package and system names are kept distinct')

table('Bandwidth_hierarchy','Era / configuration | On-die or package interior | Local memory per accelerator | CPU–accelerator | Scale-up per accelerator, one direction | Scale-out per accelerator, one direction | Sources')
for r in [
('2017: EPYC + MI25','Monolithic GPU; L2 4 MB; internal data rate n/d','HBM2 484 GB/s','PCIe 3 x16: 15.75 GB/s encoding ceiling','No dedicated peer IF in this card','OEM-dependent; n/d','D1 D2 E19'),
('2021-2022: Frontier / MI250X','2 GCDs: 200 GB/s aggregate each direction between them','3200 GB/s/package; 1600 per GCD (vendor rounded)','Coherent IF in Frontier; exact dedicated CPU path not inferred from aggregate','50 GB/s per external link; 8 links/package cover node connections','25 GB/s per physical package from node network total','D7 D8 F8'),
('2023-2024: MI300X UBB','4 MB L2/XCD; 256 MB Infinity Cache; cited on-package bisections use different scopes','5300 GB/s/GPU','PCIe 5 x16: ~63 GB/s encoding ceiling','448 GB/s total: 7 x64; 8-GPU domain','50 GB/s if 1 x400G NIC/GPU is configured','E1 E3 N9 I2'),
('2023-2024: MI300A / El Capitan','CPU/GPU share coherent package HBM through four IODs','5300 GB/s/APU','On-package coherent memory; no mandatory host-copy stage','64 GB/s per link; 4 APUs/node, link allocation system-specific','25 GB/s/APU from node network total','E1 E7 F9'),
('2025: MI355X UBB','160 KB LDS/CU; 4 MB L2/XCD; 256 MB Infinity Cache','8000 GB/s/GPU','PCIe 5 x16: ~63 GB/s encoding ceiling','537.6 GB/s total: 7 x76.8; 8-GPU domain','50 GB/s if 1 x400G Pollara/GPU is configured','E10 N12 N24 I2'),
('2026: MI455X / Helios','192 MB global L2; 2 fabric/cache dies; interior bandwidth n/d here','23300 GB/s/GPU','128 GB/s/GPU (256 bidirectional vendor figure)','1800 GB/s total/GPU; 72-GPU switched domain','Up to 300 GB/s/GPU: 3 x800G Vulcano','N14 N15 K3 I4'),
]:add('Bandwidth_hierarchy',r,r[-1],'2017-2026','Decimal GB/s. Network rates are line-rate equivalents, not measured application payload. PCIe ceilings exclude transaction overhead.')
